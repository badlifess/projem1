﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace FPSMACROx.Properties
{
	// Token: 0x02000077 RID: 119
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "17.10.0.0")]
	internal sealed partial class Settings : ApplicationSettingsBase
	{
		// Token: 0x170000AA RID: 170
		// (get) Token: 0x06000A1D RID: 2589
		public static extern Settings Default { get; }

		// Token: 0x06000A1E RID: 2590
		public extern Settings();

		// Token: 0x06000A20 RID: 2592
		static extern SettingsBase \u202D\u206C\u206B\u200C\u200F\u206F\u200C\u200C\u206A\u200B\u202C\u206E\u202E\u206C\u202D\u206C\u202A\u200D\u202E\u202E\u206E\u202E\u202C\u206A\u206C\u200C\u202E\u206B\u200F\u200E\u200E\u202C\u202A\u202A\u206E\u202A\u202D\u200D\u202E\u206F\u202E(SettingsBase);

		// Token: 0x04000381 RID: 897
		private static Settings defaultInstance;
	}
}
