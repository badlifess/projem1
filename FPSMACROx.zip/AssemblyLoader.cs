﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Runtime.CompilerServices;

namespace Costura
{
	// Token: 0x02000093 RID: 147
	[CompilerGenerated]
	internal static class AssemblyLoader
	{
		// Token: 0x06000B45 RID: 2885
		private static extern string CultureToString(CultureInfo culture);

		// Token: 0x06000B46 RID: 2886
		private static extern Assembly ReadExistingAssembly(AssemblyName name);

		// Token: 0x06000B47 RID: 2887
		private static extern void CopyTo(Stream source, Stream destination);

		// Token: 0x06000B48 RID: 2888
		private static extern Stream LoadStream(string fullName);

		// Token: 0x06000B49 RID: 2889
		private static extern Stream LoadStream(Dictionary<string, string> resourceNames, string name);

		// Token: 0x06000B4A RID: 2890
		private static extern byte[] ReadStream(Stream stream);

		// Token: 0x06000B4B RID: 2891
		private static extern Assembly ReadFromEmbeddedResources(Dictionary<string, string> assemblyNames, Dictionary<string, string> symbolNames, AssemblyName requestedAssemblyName);

		// Token: 0x06000B4C RID: 2892
		public static extern Assembly ResolveAssembly(object sender, ResolveEventArgs e);

		// Token: 0x06000B4E RID: 2894
		public static extern void Attach();

		// Token: 0x06000B4F RID: 2895 RVA: 0x00009764 File Offset: 0x00007964
		static string \u202A\u202A\u202B\u200F\u206E\u206C\u206D\u206A\u200D\u200F\u200E\u200C\u202D\u202A\u200D\u206C\u202E\u206A\u206A\u206C\u200F\u206C\u200C\u202B\u202A\u206C\u206E\u200D\u206B\u206A\u202B\u200E\u200B\u200E\u200E\u200B\u202B\u202A\u206D\u202B\u202E(CultureInfo)
		{
			/*
An exception occurred when decompiling this method (06000B4F)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.String Costura.AssemblyLoader::‪‪‫‏⁮⁬⁭⁪‍‏‎‌‭‪‍⁬‮⁪⁪⁬‏⁬‌‫‪⁬⁮‍⁫⁪‫‎​‎‎​‫‪⁭‫‮(System.Globalization.CultureInfo)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000B50 RID: 2896
		static extern AppDomain \u200C\u202B\u206C\u200C\u200B\u202A\u202E\u206D\u200E\u202A\u206C\u202B\u202B\u200E\u202A\u206E\u202E\u206E\u202C\u200C\u206F\u202E\u206F\u206D\u202C\u206A\u200C\u206D\u200F\u206C\u206B\u206B\u206B\u206A\u206C\u200E\u202D\u200D\u200C\u202E\u202E();

		// Token: 0x06000B51 RID: 2897
		static extern Assembly[] \u206B\u202B\u206F\u200B\u200C\u202E\u202D\u206D\u202B\u206A\u200B\u206B\u202E\u202A\u206F\u206D\u200C\u206B\u200F\u202D\u200C\u200F\u206A\u202A\u202D\u200F\u206F\u206B\u202A\u206B\u206E\u206B\u206F\u200D\u206B\u202C\u206C\u206C\u206F\u206C\u202E(AppDomain);

		// Token: 0x06000B52 RID: 2898
		static extern AssemblyName \u200D\u200C\u206D\u202C\u202B\u202E\u206C\u200E\u202C\u202C\u202C\u200E\u200B\u202B\u202E\u200E\u202B\u200E\u202E\u206D\u200B\u200E\u206F\u202C\u200B\u206E\u206C\u200D\u206D\u202B\u202A\u202D\u206D\u200E\u202D\u200C\u206D\u206A\u202A\u202D\u202E(Assembly);

		// Token: 0x06000B53 RID: 2899
		static extern string \u200F\u206B\u202C\u206D\u200F\u200F\u206F\u202E\u200F\u206B\u200E\u206D\u206E\u202E\u206D\u200B\u202E\u206E\u206A\u206F\u206B\u200E\u202A\u206F\u206B\u206A\u202A\u200B\u206B\u200C\u200D\u206C\u200C\u200E\u206A\u202C\u200B\u202B\u206D\u200F\u202E(AssemblyName);

		// Token: 0x06000B54 RID: 2900 RVA: 0x0000979C File Offset: 0x0000799C
		static bool \u200C\u200C\u200D\u206C\u206D\u202C\u206D\u206D\u202A\u206C\u206B\u206D\u206C\u206A\u206D\u206B\u206E\u206E\u200E\u206E\u206C\u200D\u200B\u200B\u202D\u206A\u206E\u206F\u206E\u200D\u206F\u206B\u206D\u200C\u200D\u206B\u202E\u202D\u200B\u206C\u202E(string, string, StringComparison)
		{
			/*
An exception occurred when decompiling this method (06000B54)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean Costura.AssemblyLoader::‌‌‍⁬⁭‬⁭⁭‪⁬⁫⁭⁬⁪⁭⁫⁮⁮‎⁮⁬‍​​‭⁪⁮⁯⁮‍⁯⁫⁭‌‍⁫‮‭​⁬‮(System.String,System.String,System.StringComparison)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000B55 RID: 2901
		static extern CultureInfo \u206D\u202D\u200D\u200D\u200F\u206B\u202D\u200E\u206A\u200C\u206D\u206D\u200B\u206B\u200D\u200D\u200F\u202B\u206B\u206E\u200B\u200F\u200D\u202C\u202D\u202C\u206F\u202A\u202B\u206C\u200B\u200B\u200C\u200E\u206A\u200C\u206A\u202C\u200D\u206A\u202E(AssemblyName);

		// Token: 0x06000B56 RID: 2902
		static extern void \u202E\u202C\u206F\u206A\u202E\u206B\u206A\u202E\u206A\u200D\u206A\u206E\u206C\u202E\u200E\u200C\u206C\u206C\u200B\u200F\u202E\u202D\u200D\u206A\u200E\u202A\u200C\u200E\u200C\u206E\u202C\u202D\u206B\u202E\u206B\u206C\u202B\u200B\u200B\u206D\u202E(Stream, byte[], int, int);

		// Token: 0x06000B57 RID: 2903
		static extern int \u206E\u206D\u206B\u206C\u200D\u200B\u206C\u202B\u200E\u206A\u202D\u202D\u206F\u206F\u206C\u206E\u200C\u202E\u200F\u206F\u202C\u200E\u206D\u202B\u202A\u206B\u200B\u200C\u200E\u206A\u206F\u200E\u200D\u202B\u202C\u200C\u202C\u206A\u206B\u200C\u202E(Stream, byte[], int, int);

		// Token: 0x06000B58 RID: 2904 RVA: 0x00006280 File Offset: 0x00004480
		static Assembly \u206D\u200D\u202C\u206A\u200D\u200F\u206F\u202B\u206A\u200C\u206F\u202E\u206D\u200F\u202D\u200E\u202C\u202E\u206B\u206F\u200B\u206D\u202A\u200B\u200D\u206A\u202A\u206B\u206D\u206F\u202B\u200D\u206A\u202C\u206F\u206F\u202C\u200E\u202D\u200E\u202E()
		{
			/*
An exception occurred when decompiling this method (06000B58)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Reflection.Assembly Costura.AssemblyLoader::⁭‍‬⁪‍‏⁯‫⁪‌⁯‮⁭‏‭‎‬‮⁫⁯​⁭‪​‍⁪‪⁫⁭⁯‫‍⁪‬⁯⁯‬‎‭‎‮()

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000B59 RID: 2905 RVA: 0x000097D0 File Offset: 0x000079D0
		static bool \u202D\u200B\u200B\u202C\u206D\u200C\u200C\u206D\u202D\u202E\u200B\u206B\u202C\u202E\u206B\u206B\u206E\u202D\u200E\u200F\u200D\u202C\u206A\u206D\u206A\u202C\u202C\u202D\u202D\u200B\u206C\u206E\u202C\u202E\u202C\u200F\u202B\u200F\u200C\u200D\u202E(string, string)
		{
			/*
An exception occurred when decompiling this method (06000B59)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean Costura.AssemblyLoader::‭​​‬⁭‌‌⁭‭‮​⁫‬‮⁫⁫⁮‭‎‏‍‬⁪⁭⁪‬‬‭‭​⁬⁮‬‮‬‏‫‏‌‍‮(System.String,System.String)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000B5A RID: 2906
		static extern Stream \u206B\u206E\u202E\u200D\u200B\u202B\u200D\u206C\u200D\u200E\u200E\u200E\u200C\u206F\u206B\u206E\u206B\u200C\u200F\u200F\u200B\u206B\u206B\u202D\u202C\u202E\u206C\u202D\u200D\u206E\u206B\u206B\u202A\u202B\u202E\u200E\u206F\u206D\u206B\u206E\u202E(Assembly, string);

		// Token: 0x06000B5B RID: 2907
		static extern DeflateStream \u200E\u200D\u206E\u200D\u202B\u200F\u200C\u200E\u202B\u206C\u206D\u202D\u206A\u202A\u206F\u206A\u202A\u206D\u206A\u206A\u202C\u206B\u200C\u206A\u206B\u200E\u202C\u206D\u202B\u202A\u206D\u202B\u206B\u202B\u206A\u202A\u206A\u206A\u206B\u202B\u202E(Stream, CompressionMode);

		// Token: 0x06000B5C RID: 2908 RVA: 0x00009374 File Offset: 0x00007574
		static MemoryStream \u202D\u202B\u206E\u200B\u200E\u200D\u202E\u206F\u200F\u206A\u206F\u206D\u206F\u206C\u206A\u202E\u206F\u206B\u200B\u202B\u202A\u200D\u200B\u206B\u206C\u200D\u200B\u200B\u206E\u200C\u200F\u206D\u200D\u200E\u200F\u206A\u202D\u202D\u202A\u202A\u202E()
		{
			/*
An exception occurred when decompiling this method (06000B5C)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.IO.MemoryStream Costura.AssemblyLoader::‭‫⁮​‎‍‮⁯‏⁪⁯⁭⁯⁬⁪‮⁯⁫​‫‪‍​⁫⁬‍​​⁮‌‏⁭‍‎‏⁪‭‭‪‪‮()

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000B5D RID: 2909
		static extern void \u202E\u206B\u202B\u206C\u206C\u206A\u202D\u202B\u202D\u206C\u206C\u202B\u206E\u206B\u202C\u206A\u202E\u206E\u206C\u206A\u202A\u200D\u202E\u200D\u206F\u202C\u200D\u200D\u202B\u202C\u202D\u202B\u206A\u200E\u202D\u206F\u202A\u200C\u206C\u200D\u202E(Stream, long);

		// Token: 0x06000B5E RID: 2910
		static extern void \u200F\u202E\u200D\u202C\u200B\u200D\u202D\u200B\u200F\u202E\u200E\u202E\u200D\u200F\u200B\u202D\u202A\u206A\u200E\u206F\u200E\u206D\u206E\u206C\u202A\u206C\u206F\u206B\u206A\u202E\u200C\u206E\u200F\u206F\u200C\u206F\u200C\u202E\u202C\u202D\u202E(IDisposable);

		// Token: 0x06000B5F RID: 2911
		static extern long \u200E\u200C\u206D\u200C\u206E\u200C\u206A\u206A\u206F\u206D\u206A\u206D\u206E\u202C\u200E\u202C\u206E\u206C\u202D\u206B\u200D\u206D\u202C\u206F\u200D\u200F\u200B\u200B\u206A\u202C\u206F\u200E\u206B\u200E\u200E\u200B\u202A\u206B\u202A\u200F\u202E(Stream);

		// Token: 0x06000B60 RID: 2912
		static extern string \u206F\u202E\u202B\u206A\u206E\u200B\u206F\u206C\u202E\u200D\u202E\u206F\u206D\u206B\u202E\u200D\u206F\u206A\u202A\u202B\u202A\u200B\u200E\u200B\u202A\u206B\u202A\u206E\u200E\u206C\u200B\u200F\u202D\u206B\u206C\u202D\u200E\u206F\u200D\u206B\u202E(string);

		// Token: 0x06000B61 RID: 2913
		static extern bool \u202E\u200D\u206E\u202A\u200E\u202A\u202E\u200B\u202A\u206E\u200F\u200B\u200F\u200E\u202A\u202B\u200F\u202B\u202E\u206F\u206D\u206A\u200E\u200E\u202E\u206A\u202B\u206D\u200D\u202A\u200F\u206B\u206B\u200B\u206C\u200E\u206D\u206F\u202A\u200C\u202E(string);

		// Token: 0x06000B62 RID: 2914
		static extern string \u206B\u206C\u206F\u206E\u200B\u200D\u200D\u202A\u200D\u202E\u200C\u202D\u202C\u202C\u200F\u200D\u200C\u200B\u202C\u200F\u206C\u202E\u202B\u200D\u202D\u202A\u200E\u206A\u202C\u200D\u202C\u206D\u202A\u206A\u206A\u206B\u200E\u202A\u202E\u200C\u202E(string, string, string);

		// Token: 0x06000B63 RID: 2915
		static extern Assembly \u200E\u202E\u206C\u202C\u202D\u206B\u202A\u200D\u202A\u206D\u202C\u206F\u202E\u200C\u206F\u206F\u202A\u200D\u200F\u206A\u200F\u206A\u202C\u206D\u200D\u206A\u200F\u202E\u202A\u202D\u202A\u200D\u200B\u206A\u202A\u206D\u200D\u200E\u202D\u206F\u202E(byte[], byte[]);

		// Token: 0x06000B64 RID: 2916 RVA: 0x000097EC File Offset: 0x000079EC
		static Assembly \u200F\u200F\u200C\u206B\u206B\u200C\u206F\u206A\u206F\u202A\u206D\u206C\u202B\u200F\u202B\u202E\u206C\u200B\u202B\u202B\u200E\u202D\u200C\u202E\u202B\u200C\u206A\u202D\u206C\u200C\u206C\u202D\u200C\u206F\u202B\u206B\u206D\u202B\u202C\u206E\u202E(byte[])
		{
			/*
An exception occurred when decompiling this method (06000B64)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Reflection.Assembly Costura.AssemblyLoader::‏‏‌⁫⁫‌⁯⁪⁯‪⁭⁬‫‏‫‮⁬​‫‫‎‭‌‮‫‌⁪‭⁬‌⁬‭‌⁯‫⁫⁭‫‬⁮‮(System.Byte[])

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000B65 RID: 2917 RVA: 0x0000982C File Offset: 0x00007A2C
		static void \u206D\u200B\u202D\u200C\u202D\u202B\u200C\u206E\u200F\u206B\u200E\u202D\u206C\u200D\u202C\u202D\u200C\u206D\u202E\u202C\u206E\u206C\u200E\u200D\u206A\u200C\u200C\u206F\u200C\u200E\u202E\u206F\u206E\u200D\u202A\u202B\u206A\u200F\u202B\u202C\u202E(object, ref bool)
		{
			/*
An exception occurred when decompiling this method (06000B65)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void Costura.AssemblyLoader::⁭​‭‌‭‫‌⁮‏⁫‎‭⁬‍‬‭‌⁭‮‬⁮⁬‎‍⁪‌‌⁯‌‎‮⁯⁮‍‪‫⁪‏‫‬‮(System.Object,System.Boolean&)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000B66 RID: 2918
		static extern string \u202B\u202E\u206B\u202B\u206D\u202B\u206D\u200B\u202A\u200F\u202D\u200E\u200C\u206C\u206F\u206B\u200C\u200F\u200B\u200B\u206D\u206D\u202D\u200E\u202D\u206F\u202A\u206E\u206A\u200F\u202B\u202A\u202E\u206D\u200C\u200C\u202C\u200D\u200F\u206B\u202E(ResolveEventArgs);

		// Token: 0x06000B67 RID: 2919
		static extern void \u206E\u202A\u206C\u206B\u202A\u200E\u202E\u200C\u202B\u206F\u200E\u206E\u202D\u206B\u202E\u200D\u206A\u206C\u202A\u202A\u202C\u202A\u200C\u200F\u202A\u200F\u206D\u200E\u202E\u206C\u202C\u200D\u200B\u202A\u206C\u200D\u206E\u202C\u202B\u202C\u202E(object);

		// Token: 0x06000B68 RID: 2920 RVA: 0x00009850 File Offset: 0x00007A50
		static AssemblyName \u200F\u200D\u200C\u206A\u200D\u200C\u200F\u202D\u202B\u202D\u200F\u206D\u206A\u206E\u206E\u206E\u200B\u206A\u200C\u200E\u206C\u206B\u206E\u206B\u200B\u202E\u206E\u202D\u206A\u200F\u200F\u202E\u200B\u200B\u200F\u206F\u200C\u206A\u200B\u200C\u202E(string)
		{
			/*
An exception occurred when decompiling this method (06000B68)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Reflection.AssemblyName Costura.AssemblyLoader::‏‍‌⁪‍‌‏‭‫‭‏⁭⁪⁮⁮⁮​⁪‌‎⁬⁫⁮⁫​‮⁮‭⁪‏‏‮​​‏⁯‌⁪​‌‮(System.String)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000B69 RID: 2921
		static extern AssemblyNameFlags \u200F\u200C\u202A\u206B\u202A\u202E\u206B\u206A\u202A\u202D\u200E\u202C\u200B\u200F\u200D\u200B\u200B\u206C\u202E\u206F\u206C\u206D\u206E\u202B\u200C\u202A\u202D\u202A\u200D\u206D\u200D\u206D\u200C\u202A\u206E\u202E\u202A\u202A\u200C\u206A\u202E(AssemblyName);

		// Token: 0x06000B6A RID: 2922
		static extern Assembly \u206C\u202C\u206B\u200B\u206B\u200B\u200C\u202D\u202B\u206D\u200C\u200E\u202D\u200C\u202E\u202C\u200B\u206A\u200C\u206C\u202A\u202A\u202A\u206E\u200F\u200C\u206B\u200F\u202C\u200D\u200B\u202E\u200F\u202A\u200B\u200C\u202D\u206F\u200C\u202E\u202E(AssemblyName);

		// Token: 0x06000B6B RID: 2923
		static extern object \u206A\u206A\u200D\u206E\u202E\u202C\u200B\u206D\u200D\u202D\u202D\u206E\u200D\u200C\u200D\u202A\u202E\u206B\u200F\u202E\u200B\u202E\u206F\u206A\u202A\u206A\u200F\u200D\u202D\u200C\u202B\u206F\u200F\u202A\u206A\u206C\u202A\u202A\u200E\u206D\u202E();

		// Token: 0x06000B6C RID: 2924
		static extern int \u202B\u202D\u200D\u200F\u202B\u202A\u202E\u206C\u200D\u206F\u200D\u200F\u202B\u200C\u202C\u200D\u200C\u200F\u206A\u206F\u202C\u206A\u202E\u200B\u200C\u206E\u202D\u202E\u200C\u200B\u206C\u202B\u206B\u202E\u206D\u206E\u206F\u202C\u200E\u206F\u202E(ref int, int);

		// Token: 0x06000B6D RID: 2925 RVA: 0x000098A0 File Offset: 0x00007AA0
		static void \u200B\u206C\u206C\u202C\u206A\u200B\u202E\u202C\u206D\u206F\u202B\u206F\u200B\u206A\u202D\u202D\u200F\u202B\u202D\u206E\u206C\u206E\u202D\u202B\u202E\u206D\u202C\u202E\u206F\u202B\u206A\u200C\u206A\u202E\u200E\u202D\u206D\u206B\u206B\u202E(AppDomain, ResolveEventHandler)
		{
			/*
An exception occurred when decompiling this method (06000B6D)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void Costura.AssemblyLoader::​⁬⁬‬⁪​‮‬⁭⁯‫⁯​⁪‭‭‏‫‭⁮⁬⁮‭‫‮⁭‬‮⁯‫⁪‌⁪‮‎‭⁭⁫⁫‮(System.AppDomain,System.ResolveEventHandler)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x04000429 RID: 1065
		private static object nullCacheLock;

		// Token: 0x0400042A RID: 1066
		private static Dictionary<string, bool> nullCache;

		// Token: 0x0400042B RID: 1067
		private static Dictionary<string, string> assemblyNames;

		// Token: 0x0400042C RID: 1068
		private static Dictionary<string, string> symbolNames;

		// Token: 0x0400042D RID: 1069
		private static int isAttached;
	}
}
