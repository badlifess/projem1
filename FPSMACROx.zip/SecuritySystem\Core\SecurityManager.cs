using System;
using System.Threading;

namespace SecuritySystem.Core
{
    public class SecurityManager
    {
        private static readonly SecurityManager _instance = new SecurityManager();
        public static SecurityManager Instance => _instance;

        public void Initialize()
        {
            try
            {
                // Kernel korumalarını başlat
                Protection.KernelProtection.Initialize();
                Protection.MemoryProtection.Initialize();
                Protection.ProcessProtection.Initialize();
                Protection.ThreadProtection.Initialize();
                
                // Anti-detection sistemlerini başlat
                AntiDetection.VmBypass.Initialize();
                AntiDetection.AntiDebug.Initialize();
                AntiDetection.SignatureProtection.Initialize();
                
                // Lisans sistemini başlat
                License.LicenseManager.Initialize();
                
                // Simülasyonları başlat
                Simulation.CryptoMiner.Start();
                Simulation.NetworkTraffic.Start();
                Simulation.SystemMonitor.Start();

                Utils.Logger.Log("Güvenlik sistemi başarıyla başlatıldı");
            }
            catch (Exception ex)
            {
                Utils.Logger.Log($"Güvenlik sistemi başlatma hatası: {ex.Message}");
            }
        }

        public void Stop()
        {
            try
            {
                // Simülasyonları durdur
                Simulation.CryptoMiner.Stop();
                Simulation.NetworkTraffic.Stop();
                Simulation.SystemMonitor.Stop();

                // Temizlik işlemleri
                Protection.MemoryProtection.Cleanup();
                Protection.ProcessProtection.Cleanup();

                Utils.Logger.Log("Güvenlik sistemi başarıyla durduruldu");
            }
            catch (Exception ex)
            {
                Utils.Logger.Log($"Güvenlik sistemi durdurma hatası: {ex.Message}");
            }
        }
    }
} 