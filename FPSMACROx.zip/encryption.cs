﻿using System;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

namespace KeyAuth
{
    /// <summary>
    /// Provides encryption and hashing utilities for the KeyAuth system.
    /// </summary>
    public static class Encryption
    {
        // Windows API Functions

        /// <summary>
        /// Terminates the specified process.
        /// </summary>
        /// <param name="hProcess">A handle to the process to terminate.</param>
        /// <param name="uExitCode">The exit code to use.</param>
        /// <returns>True if the process was terminated successfully; otherwise, false.</returns>
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool TerminateProcess(IntPtr hProcess, uint uExitCode);

        /// <summary>
        /// Retrieves a pseudo-handle for the calling process.
        /// </summary>
        /// <returns>A pseudo-handle for the calling process.</returns>
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr GetCurrentProcess();

        // Encryption and Hashing

        /// <summary>
        /// Computes an HMAC hash using the specified key and input.
        /// </summary>
        /// <param name="key">The encryption key.</param>
        /// <param name="input">The input string to hash.</param>
        /// <returns>The computed HMAC hash as a hexadecimal string.</returns>
        public static string HashHMAC(string key, string input)
        {
            using (var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(key)))
            {
                byte[] hashBytes = hmac.ComputeHash(Encoding.UTF8.GetBytes(input));
                return BitConverter.ToString(hashBytes).Replace("-", "").ToLowerInvariant();
            }
        }

        /// <summary>
        /// Converts a byte array to a hexadecimal string.
        /// </summary>
        /// <param name="bytes">The byte array to convert.</param>
        /// <returns>The hexadecimal string representation of the byte array.</returns>
        public static string ByteArrayToString(byte[] bytes)
        {
            StringBuilder hex = new StringBuilder(bytes.Length * 2);
            foreach (byte b in bytes)
            {
                hex.AppendFormat("{0:x2}", b);
            }
            return hex.ToString();
        }

        /// <summary>
        /// Converts a hexadecimal string to a byte array.
        /// </summary>
        /// <param name="hex">The hexadecimal string.</param>
        /// <returns>The byte array representation of the hexadecimal string.</returns>
        public static byte[] StringToByteArray(string hex)
        {
            int length = hex.Length;
            byte[] bytes = new byte[length / 2];
            for (int i = 0; i < length; i += 2)
            {
                bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 16);
            }
            return bytes;
        }

        /// <summary>
        /// Generates a random Initialization Vector (IV) for encryption.
        /// </summary>
        /// <returns>A randomly generated IV as a base64 string.</returns>
        public static string GenerateIV()
        {
            using (var rng = new RNGCryptoServiceProvider())
            {
                byte[] iv = new byte[16]; // 16 bytes = 128 bits
                rng.GetBytes(iv);
                return Convert.ToBase64String(iv);
            }
        }
    }
}