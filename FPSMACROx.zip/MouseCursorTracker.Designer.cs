﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace DijitalCyrpto
{
    partial class MouseCursorTracker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
                if (bitmap != null)
                {
                    bitmap.Dispose();
                }
                if (redDotImage != null)
                {
                    redDotImage.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        // Constructor
        public MouseCursorTracker()
        {
            InitializeComponent();
            this.Text = "Mouse Cursor Tracker"; // Set the form title
            this.MouseMove += MouseCursorTracker_MouseMove; // Attach event handler
        }

        // Event handler to track mouse movement
        private void MouseCursorTracker_MouseMove(object sender, MouseEventArgs e)
        {
            // Display the current mouse coordinates in the form's title bar
            this.Text = $"Mouse Position: X = {e.X}, Y = {e.Y}";
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            
            // MouseCursorTracker
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MouseTracker";
            this.Text = "Fare İzleyici";
            this.WindowState = FormWindowState.Maximized;
            this.TopMost = true;
            this.TransparencyKey = Color.Black;
            this.BackColor = Color.Black;
            
            this.ResumeLayout(false);
        }
    }
}