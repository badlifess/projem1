using System;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace FPSMACROx
{
    public class InputController
    {
        [DllImport("user32.dll")]
        private static extern void mouse_event(uint dwFlags, int dx, int dy, uint dwData, int dwExtraInfo);

        [DllImport("user32.dll")]
        private static extern short GetAsyncKeyState(Keys vKey);

        private const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
        private const uint MOUSEEVENTF_LEFTUP = 0x0004;
        private const uint MOUSEEVENTF_RIGHTDOWN = 0x0008;
        private const uint MOUSEEVENTF_RIGHTUP = 0x0010;
        private const uint MOUSEEVENTF_MIDDLEDOWN = 0x0020;
        private const uint MOUSEEVENTF_MIDDLEUP = 0x0040;
        private const uint MOUSEEVENTF_ABSOLUTE = 0x8000;

        private bool isRunning;
        private Thread inputThread;
        private readonly object lockObject = new object();

        public InputController()
        {
            isRunning = false;
        }

        public void Start()
        {
            if (!isRunning)
            {
                lock (lockObject)
                {
                    if (!isRunning)
                    {
                        isRunning = true;
                        inputThread = new Thread(InputLoop)
                        {
                            IsBackground = true
                        };
                        inputThread.Start();
                    }
                }
            }
        }

        public void Stop()
        {
            if (isRunning)
            {
                lock (lockObject)
                {
                    if (isRunning)
                    {
                        isRunning = false;
                        inputThread?.Join();
                    }
                }
            }
        }

        private void InputLoop()
        {
            while (isRunning)
            {
                try
                {
                    // Mouse kontrolü
                    if (IsKeyPressed(Keys.LButton))
                    {
                        // Sol tık işlemleri
                    }

                    if (IsKeyPressed(Keys.RButton))
                    {
                        // Sağ tık işlemleri
                    }

                    // Klavye kontrolü
                    if (IsKeyPressed(Keys.Space))
                    {
                        // Boşluk tuşu işlemleri
                    }

                    Thread.Sleep(1);
                }
                catch (Exception)
                {
                    // Hata durumunda sessizce devam et
                }
            }
        }

        public void MoveMouse(int x, int y)
        {
            try
            {
                mouse_event(MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_MOVE, x, y, 0, 0);
            }
            catch (Exception)
            {
                // Hata durumunda sessizce devam et
            }
        }

        public void LeftClick()
        {
            try
            {
                mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
                Thread.Sleep(10);
                mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
            }
            catch (Exception)
            {
                // Hata durumunda sessizce devam et
            }
        }

        public void RightClick()
        {
            try
            {
                mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0);
                Thread.Sleep(10);
                mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0);
            }
            catch (Exception)
            {
                // Hata durumunda sessizce devam et
            }
        }

        public bool IsKeyPressed(Keys key)
        {
            try
            {
                return (GetAsyncKeyState(key) & 0x8000) != 0;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public void Dispose()
        {
            Stop();
        }
    }
} 