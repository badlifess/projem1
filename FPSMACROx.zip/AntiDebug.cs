﻿using System;
using System.Collections;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.Win32.SafeHandles;
using System.Threading;

namespace AntiCrack_DotNet
{
    /// <summary>
    /// A class implementing various anti-debugging techniques.
    /// </summary>
    internal sealed class AntiDebug
    {
        // DLL Imports for Windows API calls
        [DllImport("kernelbase.dll", SetLastError = true)]
        private static extern bool NtClose(IntPtr Handle);

        [DllImport("kernelbase.dll", SetLastError = true)]
        private static extern bool IsDebuggerPresent();

        [DllImport("ntdll.dll", SetLastError = true)]
        private static extern uint NtQueryInformationProcess(
            SafeHandle hProcess,
            uint ProcessInfoClass,
            out uint ProcessInfo,
            uint nSize,
            uint ReturnLength
        );

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool CheckRemoteDebuggerPresent(IntPtr hProcess, ref bool isDebuggerPresent);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern uint GetTickCount();

        private static DateTime _lastCheck = DateTime.MinValue;
        private static readonly object _lockObject = new object();

        /// <summary>
        /// Performs all available debug checks
        /// </summary>
        public static bool PerformAllChecks()
        {
            lock (_lockObject)
            {
                // Prevent too frequent checks
                if ((DateTime.Now - _lastCheck).TotalSeconds < 2)
                    return false;

                _lastCheck = DateTime.Now;

                try
                {
                    return DebuggerIsAttached() ||
                           IsDebuggerPresentCheck() ||
                           CheckRemoteDebugger() ||
                           NtCloseAntiDebug_InvalidHandle() ||
                           NtQueryInformationProcessCheck_ProcessDebugFlags() ||
                           CheckDebuggerTime();
                }
                catch
                {
                    // If any check throws an exception, assume debugging
                    return true;
                }
            }
        }

        /// <summary>
        /// Checks if a debugger is attached using the Debugger class.
        /// </summary>
        public static bool DebuggerIsAttached()
        {
            try
            {
                return Debugger.IsAttached;
            }
            catch
            {
                return true;
            }
        }

        /// <summary>
        /// Checks if a debugger is present using IsDebuggerPresent API.
        /// </summary>
        public static bool IsDebuggerPresentCheck()
        {
            try
            {
                return IsDebuggerPresent();
            }
            catch
            {
                return true;
            }
        }

        /// <summary>
        /// Checks for remote debugger
        /// </summary>
        public static bool CheckRemoteDebugger()
        {
            try
            {
                bool isDebuggerPresent = false;
                CheckRemoteDebuggerPresent(Process.GetCurrentProcess().Handle, ref isDebuggerPresent);
                return isDebuggerPresent;
            }
            catch
            {
                return true;
            }
        }

        /// <summary>
        /// Checks for debugging by measuring time between operations
        /// </summary>
        private static bool CheckDebuggerTime()
        {
            try
            {
                uint tick1 = GetTickCount();
                Thread.Sleep(10);
                uint tick2 = GetTickCount();

                return (tick2 - tick1) > 100;
            }
            catch
            {
                return true;
            }
        }

        /// <summary>
        /// Anti-debugging with invalid handle close.
        /// </summary>
        public static bool NtCloseAntiDebug_InvalidHandle()
        {
            try
            {
                IntPtr invalidHandle = new IntPtr(-1);
                return NtClose(invalidHandle);
            }
            catch
            {
                return true;
            }
        }

        /// <summary>
        /// Detects debugging using NtQueryInformationProcess.
        /// </summary>
        public static bool NtQueryInformationProcessCheck_ProcessDebugFlags()
        {
            try
            {
                uint debugFlags;
                uint status = NtQueryInformationProcess(Process.GetCurrentProcess().SafeHandle, 0x1F, out debugFlags, 4, 0);
                return status == 0 && debugFlags == 0;
            }
            catch
            {
                return true;
            }
        }
    }
}