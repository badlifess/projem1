using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace SecuritySystem.Protection
{
    public static class ScreenProtection
    {
        [DllImport("user32.dll")]
        private static extern bool SetWindowDisplayAffinity(IntPtr hwnd, uint dwAffinity);

        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        private const uint WDA_MONITOR = 1;
        private const uint WDA_EXCLUDEFROMCAPTURE = 0x11;

        public static void Initialize()
        {
            try
            {
                ProtectScreen();
                Utils.Logger.Log("Ekran koruması başarıyla başlatıldı");
            }
            catch (Exception ex)
            {
                Utils.Logger.Log($"Ekran koruma hatası: {ex.Message}");
            }
        }

        private static void ProtectScreen()
        {
            try
            {
                // Ana pencereyi koru
                foreach (Form form in Application.OpenForms)
                {
                    SetWindowDisplayAffinity(form.Handle, WDA_EXCLUDEFROMCAPTURE);
                }

                // Aktif pencereyi koru
                IntPtr hwnd = GetForegroundWindow();
                if (hwnd != IntPtr.Zero)
                {
                    SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE);
                }
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        public static void Cleanup()
        {
            try
            {
                // Koruma kaldırılıyor
                foreach (Form form in Application.OpenForms)
                {
                    SetWindowDisplayAffinity(form.Handle, WDA_MONITOR);
                }
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }
    }
} 