using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using Siticone.UI.WinForms;

namespace FPSMACROx
{
    public partial class Form1
    {
        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                // Form yüklenirken yapılacak işlemler
                InitializeGameSettings();
                UpdateUI();
            }
            catch (Exception ex)
            {
                this.ShowMessageBox("Form yüklenirken bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                // Form kapatılırken yapılacak işlemler
                gameLogic.Stop();
                if (yenibirparca != null && yenibirparca.IsAlive)
                {
                    yenibirparca.Abort();
                }
            }
            catch (Exception ex)
            {
                // Hata durumunda sessizce kapat
            }
        }

        private void siticoneToggleSwitch1_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (siticoneToggleSwitch1.Checked)
                {
                    gameLogic.Start();
                }
                else
                {
                    gameLogic.Stop();
                }
            }
            catch (Exception ex)
            {
                this.ShowMessageBox("Anahtar değiştirilirken bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void siticoneButton1_Click(object sender, EventArgs e)
        {
            try
            {
                // Buton tıklama işlemleri
                if (colorDialog1.ShowDialog() == DialogResult.OK)
                {
                    // Renk seçimi işlemleri
                }
            }
            catch (Exception ex)
            {
                this.ShowMessageBox("Buton tıklamasında bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                if (gameLogic.IsRunning())
                {
                    // Timer işlemleri
                }
            }
            catch (Exception ex)
            {
                // Timer hatası durumunda sessizce devam et
            }
        }

        private void UpdateUI()
        {
            try
            {
                // UI güncelleme işlemleri
                this.UpdateLabel(label1, "Durum: " + (gameLogic.IsRunning() ? "Çalışıyor" : "Durduruldu"));
            }
            catch (Exception ex)
            {
                // UI güncelleme hatası durumunda sessizce devam et
            }
        }
    }
} 