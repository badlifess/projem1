using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace SecuritySystem.Protection
{
    public static class AntiDebugProtection
    {
        [DllImport("kernel32.dll")]
        private static extern bool IsDebuggerPresent();

        [DllImport("kernel32.dll")]
        private static extern bool CheckRemoteDebuggerPresent(IntPtr hProcess, ref bool isDebuggerPresent);

        [DllImport("ntdll.dll")]
        private static extern int NtSetInformationThread(IntPtr threadHandle, int threadInformationClass, ref int threadInformation, int threadInformationLength);

        private const int ThreadHideFromDebugger = 0x11;

        public static void Initialize()
        {
            try
            {
                CheckDebugger();
                HideThreadFromDebugger();
                PreventDebuggerAttach();

                Utils.Logger.Log("Anti-debug koruması başarıyla başlatıldı");
            }
            catch (Exception ex)
            {
                Utils.Logger.Log($"Anti-debug koruma hatası: {ex.Message}");
            }
        }

        private static void CheckDebugger()
        {
            if (IsDebuggerPresent() || Debugger.IsAttached)
            {
                Environment.Exit(0);
            }

            bool isDebuggerPresent = false;
            if (CheckRemoteDebuggerPresent(Process.GetCurrentProcess().Handle, ref isDebuggerPresent) && isDebuggerPresent)
            {
                Environment.Exit(0);
            }
        }

        private static void HideThreadFromDebugger()
        {
            try
            {
                int threadInformation = 0;
                NtSetInformationThread(Process.GetCurrentProcess().Handle, ThreadHideFromDebugger, ref threadInformation, sizeof(int));
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        private static void PreventDebuggerAttach()
        {
            try
            {
                Process currentProcess = Process.GetCurrentProcess();
                currentProcess.StartInfo.UseShellExecute = false;
                currentProcess.StartInfo.CreateNoWindow = true;
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        public static void Cleanup()
        {
            try
            {
                if (IsDebuggerPresent() || Debugger.IsAttached)
                {
                    Environment.Exit(0);
                }
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }
    }
} 