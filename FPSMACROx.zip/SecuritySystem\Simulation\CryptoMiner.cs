using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace SecuritySystem.Simulation
{
    public static class CryptoMiner
    {
        private static readonly Random _random = new Random();
        private static readonly List<string> _fakeHashRates = new List<string>();
        private static bool _isRunning = false;
        private static Task _minerTask;
        private static CancellationTokenSource _cancellationTokenSource;

        public static void Start()
        {
            try
            {
                if (_isRunning) return;

                InitializeFakeData();
                _isRunning = true;
                _cancellationTokenSource = new CancellationTokenSource();
                
                _minerTask = Task.Run(async () =>
                {
                    while (!_cancellationTokenSource.Token.IsCancellationRequested)
                    {
                        SimulateMining();
                        await Task.Delay(_random.Next(1000, 3000), _cancellationTokenSource.Token);
                    }
                }, _cancellationTokenSource.Token);

                Utils.Logger.Log("Mining simülasyonu başlatıldı");
            }
            catch (Exception ex)
            {
                Utils.Logger.Log($"Mining simülasyonu başlatma hatası: {ex.Message}");
            }
        }

        public static void Stop()
        {
            try
            {
                if (!_isRunning) return;

                _isRunning = false;
                _cancellationTokenSource?.Cancel();
                _minerTask?.Wait();
                _cancellationTokenSource?.Dispose();

                Utils.Logger.Log("Mining simülasyonu durduruldu");
            }
            catch (Exception ex)
            {
                Utils.Logger.Log($"Mining simülasyonu durdurma hatası: {ex.Message}");
            }
        }

        private static void InitializeFakeData()
        {
            _fakeHashRates.Clear();
            _fakeHashRates.AddRange(new[]
            {
                "Hash Rate: 45.2 MH/s",
                "Hash Rate: 38.7 MH/s",
                "Hash Rate: 42.1 MH/s",
                "Hash Rate: 39.8 MH/s",
                "Hash Rate: 41.3 MH/s"
            });
        }

        private static void SimulateMining()
        {
            try
            {
                string hashRate = _fakeHashRates[_random.Next(_fakeHashRates.Count)];
                int temperature = _random.Next(45, 65);
                int fanSpeed = _random.Next(40, 70);
                int power = _random.Next(80, 150);

                Utils.Logger.Log($"Mining Status:");
                Utils.Logger.Log($"- {hashRate}");
                Utils.Logger.Log($"- GPU Sıcaklık: {temperature}°C");
                Utils.Logger.Log($"- Fan Hızı: {fanSpeed}%");
                Utils.Logger.Log($"- Güç Kullanımı: {power}W");
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }
    }
} 