using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Win32;

namespace SecuritySystem.License
{
    public static class LicenseManager
    {
        private static readonly string LicensePath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "Bandicam",
            "license.dat"
        );

        private static readonly string LicenseKey = "BANDICAM-XXXX-XXXX-XXXX-XXXX";
        private static readonly string LicenseName = "Premium License";
        private static readonly DateTime LicenseExpiry = DateTime.Now.AddYears(1);

        public static void Initialize()
        {
            try
            {
                CreateFakeLicense();
                SaveToRegistry();

                Utils.Logger.Log("Lisans sistemi başarıyla başlatıldı");
            }
            catch (Exception ex)
            {
                Utils.Logger.Log($"Lisans sistemi hatası: {ex.Message}");
            }
        }

        private static void CreateFakeLicense()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(LicensePath));
                string licenseData = GenerateLicenseData();
                File.WriteAllText(LicensePath, licenseData);
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        private static string GenerateLicenseData()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("[License]");
            sb.AppendLine($"Key={LicenseKey}");
            sb.AppendLine($"Name={LicenseName}");
            sb.AppendLine($"Expiry={LicenseExpiry:yyyy-MM-dd}");
            sb.AppendLine($"Type=Premium");
            sb.AppendLine($"Version=5.4.3");
            sb.AppendLine($"Signature={GenerateSignature()}");
            return sb.ToString();
        }

        private static string GenerateSignature()
        {
            try
            {
                using (SHA256 sha256 = SHA256.Create())
                {
                    string data = $"{LicenseKey}{LicenseName}{LicenseExpiry:yyyy-MM-dd}";
                    byte[] hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(data));
                    return BitConverter.ToString(hash).Replace("-", "");
                }
            }
            catch
            {
                return "INVALID_SIGNATURE";
            }
        }

        private static void SaveToRegistry()
        {
            try
            {
                using (var key = Registry.CurrentUser.CreateSubKey(@"Software\Bandicam"))
                {
                    key.SetValue("LicenseKey", LicenseKey);
                    key.SetValue("LicenseName", LicenseName);
                    key.SetValue("ExpiryDate", LicenseExpiry.ToString("yyyy-MM-dd"));
                    key.SetValue("Version", "5.4.3");
                    key.SetValue("Signature", GenerateSignature());
                }
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        public static bool ValidateLicense()
        {
            try
            {
                if (!File.Exists(LicensePath))
                    return false;

                using (var key = Registry.CurrentUser.OpenSubKey(@"Software\Bandicam"))
                {
                    if (key == null)
                        return false;

                    string storedKey = key.GetValue("LicenseKey") as string;
                    string storedName = key.GetValue("LicenseName") as string;
                    string storedExpiry = key.GetValue("ExpiryDate") as string;
                    string storedSignature = key.GetValue("Signature") as string;

                    if (storedKey != LicenseKey || 
                        storedName != LicenseName || 
                        storedExpiry != LicenseExpiry.ToString("yyyy-MM-dd") || 
                        storedSignature != GenerateSignature())
                        return false;
                }

                return true;
            }
            catch
            {
                return false;
            }
        }
    }
} 