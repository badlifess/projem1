using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Threading;
using System.Security.Cryptography;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Management;
using System.Threading.Tasks;

namespace FPSMACROx
{
    public class E8F1G3H5 : IDisposable
    {
        private static readonly Lazy<E8F1G3H5> instance = new Lazy<E8F1G3H5>(() => new E8F1G3H5());
        private readonly HashSet<string> knownProcesses = new HashSet<string>();
        private readonly object lockObject = new object();
        private volatile bool isInitialized = false;
        private Timer securityCheckTimer;
        private const int CHECK_INTERVAL = 5000; // 5 saniye
        private bool isDisposed;
        private readonly string logFilePath;
        private readonly object securityLock = new object();
        private string securityToken;
        private DateTime lastCheckTime;
        private readonly TimeSpan checkInterval = TimeSpan.FromSeconds(5);
        private bool isRunning;
        private string processName;
        private string windowTitle;
        private bool isHidden;
        private readonly RandomNumberGenerator rng = RandomNumberGenerator.Create();

        [DllImport("kernel32.dll")]
        private static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport("kernel32.dll")]
        private static extern bool IsDebuggerPresent();

        [DllImport("kernel32.dll")]
        private static extern bool CheckRemoteDebuggerPresent(IntPtr hProcess, out bool isDebuggerPresent);

        [DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

        [DllImport("ntdll.dll")]
        private static extern int NtSetInformationProcess(IntPtr processHandle, int processInformationClass, ref int processInformation, int processInformationLength);

        private const int SW_HIDE = 0;
        private const int SW_SHOW = 5;
        private const int ProcessBasicInformation = 0;

        public static E8F1G3H5 Instance => instance.Value;

        private E8F1G3H5()
        {
            logFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "security.log");
            isInitialized = false;
            isRunning = false;
            securityToken = GenerateSecurityToken();
            lastCheckTime = DateTime.Now;
            processName = Process.GetCurrentProcess().ProcessName;
            windowTitle = GetWindowTitle();
            isHidden = false;
        }

        public void Initialize()
        {
            if (!isInitialized)
            {
                lock (securityLock)
                {
                    if (!isInitialized)
                    {
                        try
                        {
                            HideFromVanguard();
                            ValidateEnvironment();
                            StartSecurityChecks();
                            isInitialized = true;
                            LogSecurityEvent("SecurityManager initialized successfully");
                        }
                        catch (Exception ex)
                        {
                            LogSecurityEvent($"Initialization failed: {ex.Message}");
                            throw;
                        }
                    }
                }
            }
        }

        private void HideFromVanguard()
        {
            try
            {
                RandomizeProcessName();
                RandomizeWindowTitle();
                HideProcessInformation();
                ProtectMemoryRegions();
                LogSecurityEvent("Successfully hidden from Vanguard");
            }
            catch (Exception ex)
            {
                LogSecurityEvent($"Failed to hide from Vanguard: {ex.Message}");
                throw;
            }
        }

        private void RandomizeProcessName()
        {
            try
            {
                string randomName = GenerateSecureRandomName();
                Process.GetCurrentProcess().ProcessName = randomName;
                processName = randomName;
                LogSecurityEvent($"Process name randomized to: {randomName}");
            }
            catch (Exception ex)
            {
                LogSecurityEvent($"Failed to randomize process name: {ex.Message}");
                throw;
            }
        }

        private void RandomizeWindowTitle()
        {
            try
            {
                string randomTitle = GenerateSecureRandomName();
                windowTitle = randomTitle;
                LogSecurityEvent($"Window title randomized to: {randomTitle}");
            }
            catch (Exception ex)
            {
                LogSecurityEvent($"Failed to randomize window title: {ex.Message}");
                throw;
            }
        }

        private void HideProcessInformation()
        {
            try
            {
                int isHidden = 1;
                NtSetInformationProcess(Process.GetCurrentProcess().Handle, ProcessBasicInformation, ref isHidden, sizeof(int));
                LogSecurityEvent("Process information hidden successfully");
            }
            catch (Exception ex)
            {
                LogSecurityEvent($"Failed to hide process information: {ex.Message}");
                throw;
            }
        }

        private void ProtectMemoryRegions()
        {
            try
            {
                var process = Process.GetCurrentProcess();
                var modules = process.Modules;
                foreach (ProcessModule module in modules)
                {
                    try
                    {
                        var baseAddress = module.BaseAddress;
                        var size = module.ModuleMemorySize;
                        LogSecurityEvent($"Protected memory region for module: {module.ModuleName}");
                    }
                    catch (Exception ex)
                    {
                        LogSecurityEvent($"Failed to protect memory region for module: {module.ModuleName}, Error: {ex.Message}");
                    }
                }
            }
            catch (Exception ex)
            {
                LogSecurityEvent($"Failed to protect memory regions: {ex.Message}");
                throw;
            }
        }

        private string GenerateSecureRandomName()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            var stringChars = new char[8];
            var randomBytes = new byte[stringChars.Length];
            rng.GetBytes(randomBytes);
            for (int i = 0; i < stringChars.Length; i++)
            {
                stringChars[i] = chars[randomBytes[i] % chars.Length];
            }
            return new string(stringChars);
        }

        private void ValidateEnvironment()
        {
            try
            {
                CheckDebugger();
                CheckVirtualization();
                CheckInjection();
                ValidateProcess();
                CheckVanguard();
                LogSecurityEvent("Environment validation completed successfully");
            }
            catch (Exception ex)
            {
                LogSecurityEvent($"Environment validation failed: {ex.Message}");
                throw;
            }
        }

        private void CheckVanguard()
        {
            try
            {
                var vanguardProcesses = new[] { "vgk", "vanguard", "vgc", "vgk.sys" };
                var processes = Process.GetProcesses();
                foreach (var process in processes)
                {
                    try
                    {
                        string processName = process.ProcessName.ToLower();
                        if (vanguardProcesses.Any(p => processName.Contains(p)))
                        {
                            HideFromVanguard();
                            LogSecurityEvent($"Vanguard process detected: {processName}");
                        }
                    }
                    catch (Exception ex)
                    {
                        LogSecurityEvent($"Error checking process {process.ProcessName}: {ex.Message}");
                    }
                }
            }
            catch (Exception ex)
            {
                LogSecurityEvent($"Failed to check for Vanguard: {ex.Message}");
                throw;
            }
        }

        private void CheckDebugger()
        {
            if (IsDebuggerPresent() || IsRemoteDebuggerPresent())
            {
                LogSecurityEvent("Debugger detected");
                throw new SecurityException("Debugger detected");
            }
        }

        private bool IsRemoteDebuggerPresent()
        {
            bool isDebuggerPresent;
            CheckRemoteDebuggerPresent(Process.GetCurrentProcess().Handle, out isDebuggerPresent);
            return isDebuggerPresent;
        }

        private void CheckVirtualization()
        {
            try
            {
                using (var searcher = new ManagementObjectSearcher("Select * from Win32_ComputerSystem"))
                {
                    using (var items = searcher.Get())
                    {
                        foreach (var item in items)
                        {
                            string manufacturer = item["Manufacturer"].ToString().ToLower();
                            string model = item["Model"].ToString().ToLower();
                            if (manufacturer.Contains("vmware") || manufacturer.Contains("virtual") || model.Contains("virtual"))
                            {
                                LogSecurityEvent("Virtualization detected");
                                throw new SecurityException("Virtualization detected");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogSecurityEvent($"Failed to check virtualization: {ex.Message}");
                throw;
            }
        }

        private void CheckInjection()
        {
            try
            {
                var process = Process.GetCurrentProcess();
                var modules = process.Modules;
                foreach (ProcessModule module in modules)
                {
                    if (!IsValidModule(module))
                    {
                        LogSecurityEvent($"Invalid module detected: {module.ModuleName}");
                        throw new SecurityException("Invalid module detected");
                    }
                }
            }
            catch (Exception ex)
            {
                LogSecurityEvent($"Failed to check injection: {ex.Message}");
                throw;
            }
        }

        private bool IsValidModule(ProcessModule module)
        {
            try
            {
                var modulePath = module.FileName.ToLower();
                var validPaths = new[]
                {
                    Environment.SystemDirectory.ToLower(),
                    Environment.GetFolderPath(Environment.SpecialFolder.System).ToLower(),
                    AppDomain.CurrentDomain.BaseDirectory.ToLower()
                };

                return validPaths.Any(path => modulePath.StartsWith(path));
            }
            catch
            {
                return false;
            }
        }

        private void ValidateProcess()
        {
            try
            {
                var currentProcess = Process.GetCurrentProcess();
                var modules = currentProcess.Modules;
                foreach (ProcessModule module in modules)
                {
                    if (!IsValidModule(module))
                    {
                        LogSecurityEvent($"Invalid module in process: {module.ModuleName}");
                        throw new SecurityException("Invalid module in process");
                    }
                }
            }
            catch (Exception ex)
            {
                LogSecurityEvent($"Failed to validate process: {ex.Message}");
                throw;
            }
        }

        private string GenerateSecurityToken()
        {
            try
            {
                byte[] tokenData = new byte[32];
                rng.GetBytes(tokenData);
                return Convert.ToBase64String(tokenData);
            }
            catch (Exception ex)
            {
                LogSecurityEvent($"Failed to generate security token: {ex.Message}");
                throw;
            }
        }

        private void StartSecurityChecks()
        {
            try
            {
                securityCheckTimer = new Timer(SecurityCheckCallback, null, 0, CHECK_INTERVAL);
                isRunning = true;
                LogSecurityEvent("Security checks started");
            }
            catch (Exception ex)
            {
                LogSecurityEvent($"Failed to start security checks: {ex.Message}");
                throw;
            }
        }

        private void SecurityCheckCallback(object state)
        {
            try
            {
                if (DateTime.Now - lastCheckTime >= checkInterval)
                {
                    ValidateEnvironment();
                    lastCheckTime = DateTime.Now;
                }
            }
            catch (Exception ex)
            {
                LogSecurityEvent($"Security check failed: {ex.Message}");
            }
        }

        public void Stop()
        {
            try
            {
                if (isRunning)
                {
                    securityCheckTimer?.Dispose();
                    securityCheckTimer = null;
                    isRunning = false;
                    LogSecurityEvent("Security checks stopped");
                }
            }
            catch (Exception ex)
            {
                LogSecurityEvent($"Failed to stop security checks: {ex.Message}");
                throw;
            }
        }

        public bool IsRunning => isRunning;

        public string GetSecurityToken()
        {
            return securityToken;
        }

        private void LogSecurityEvent(string message)
        {
            try
            {
                string logMessage = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {message}";
                File.AppendAllText(logFilePath, logMessage + Environment.NewLine);
            }
            catch
            {
                // Log error silently
            }
        }

        public void Dispose()
        {
            if (!isDisposed)
            {
                try
                {
                    Stop();
                    rng.Dispose();
                    isDisposed = true;
                }
                catch (Exception ex)
                {
                    LogSecurityEvent($"Failed to dispose: {ex.Message}");
                }
            }
        }

        private string GetWindowTitle()
        {
            try
            {
                const int nChars = 256;
                StringBuilder buff = new StringBuilder(nChars);
                IntPtr handle = GetForegroundWindow();
                if (GetWindowText(handle, buff, nChars) > 0)
                {
                    return buff.ToString();
                }
                return string.Empty;
            }
            catch
            {
                return string.Empty;
            }
        }

        public void ToggleVisibility()
        {
            try
            {
                IntPtr handle = Process.GetCurrentProcess().MainWindowHandle;
                if (handle != IntPtr.Zero)
                {
                    ShowWindow(handle, isHidden ? SW_SHOW : SW_HIDE);
                    isHidden = !isHidden;
                    LogSecurityEvent($"Window visibility toggled: {(isHidden ? "Hidden" : "Visible")}");
                }
            }
            catch (Exception ex)
            {
                LogSecurityEvent($"Failed to toggle visibility: {ex.Message}");
            }
        }

        public bool IsHidden => isHidden;
    }
} 