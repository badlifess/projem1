﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FPSMACROx
{
	// Token: 0x0200005F RID: 95
	public partial class Form5 : Form
	{
		private readonly GameController gameController;
		private readonly InputController inputController;
		private bool isRunning;

		public Form5()
		{
			InitializeComponent();
			gameController = new GameController();
			inputController = new InputController();
			isRunning = false;
			SetupEventHandlers();
		}

		private void SetupEventHandlers()
		{
			// Başlat butonu
			startButton.Click += (s, e) =>
			{
				if (!isRunning)
				{
					gameController.Start();
					inputController.Start();
					isRunning = true;
					UpdateUI();
				}
			};

			// Durdur butonu
			stopButton.Click += (s, e) =>
			{
				if (isRunning)
				{
					gameController.Stop();
					inputController.Stop();
					isRunning = false;
					UpdateUI();
				}
			};

			// Form kapatıldığında
			this.FormClosing += (s, e) =>
			{
				if (isRunning)
				{
					gameController.Stop();
					inputController.Stop();
				}
			};
		}

		private void UpdateUI()
		{
			startButton.Enabled = !isRunning;
			stopButton.Enabled = isRunning;
			statusLabel.Text = isRunning ? "Status: Running" : "Status: Stopped";
		}

		protected override void OnFormClosing(FormClosingEventArgs e)
		{
			if (isRunning)
			{
				gameController.Stop();
				inputController.Stop();
			}
			base.OnFormClosing(e);
		}

		// Token: 0x06000814 RID: 2068
		public extern Form5();

		// Token: 0x06000815 RID: 2069 RVA: 0x000064DC File Offset: 0x000046DC
		private void Form5_Load(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (06000815)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form5::Form5_Load(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000816 RID: 2070
		private extern Image CreateCircularImage(Image img);

		// Token: 0x06000817 RID: 2071
		public extern Task UpdateZoomedImage(Image zoomedImage);

		// Token: 0x06000819 RID: 2073
		private extern void InitializeComponent();

		// Token: 0x0600081A RID: 2074
		static extern void \u200E\u202C\u200C\u206D\u202B\u206D\u206E\u206B\u202A\u206B\u202D\u206E\u202B\u200F\u200B\u206B\u206A\u202C\u202A\u200B\u206C\u202E\u206F\u200D\u202D\u206E\u206B\u202A\u202D\u206C\u202E\u206C\u202A\u202D\u200F\u202A\u206F\u202B\u202C\u200D\u202E(Form, FormStartPosition);

		// Token: 0x0600081B RID: 2075
		static extern void \u202E\u206E\u200C\u200E\u206E\u206C\u206A\u202C\u206C\u200F\u200D\u202D\u206B\u200F\u200D\u206B\u202A\u206A\u202C\u200D\u202A\u202A\u206C\u206C\u200B\u202B\u200F\u202D\u202D\u202E\u202C\u200C\u200E\u206C\u206C\u202D\u200C\u206F\u202B\u202B\u202E(Form, Point);

		// Token: 0x0600081C RID: 2076
		static extern void \u206A\u202B\u206C\u200F\u202B\u200C\u200E\u202E\u202B\u206F\u202E\u206B\u202E\u200B\u200E\u200D\u200D\u200D\u206C\u200B\u202E\u206F\u200B\u206D\u206E\u200C\u202A\u202C\u200F\u206F\u202E\u200E\u206A\u202A\u206E\u200D\u206F\u200F\u200B\u200F\u202E(Form, FormBorderStyle);

		// Token: 0x0600081D RID: 2077
		static extern void \u200D\u206A\u200E\u202C\u202A\u200B\u206F\u202E\u206D\u206A\u206D\u200B\u202B\u200D\u206D\u202B\u202B\u206D\u206A\u200E\u202E\u200B\u202A\u200C\u202A\u202A\u206F\u202E\u200C\u200D\u200F\u202D\u206F\u206A\u202B\u206F\u202D\u200C\u206D\u200C\u202E(Control, Color);

		// Token: 0x0600081E RID: 2078
		static extern void \u206B\u200C\u206A\u206F\u202A\u200F\u202B\u200F\u200B\u200B\u200B\u200E\u206D\u200F\u202E\u200D\u200D\u202C\u206D\u202B\u206C\u200F\u202C\u202D\u202B\u200F\u206D\u202C\u200C\u202E\u202C\u206C\u202D\u206B\u206E\u206D\u202B\u200F\u202C\u206F\u202E(Form, bool);

		// Token: 0x0600081F RID: 2079 RVA: 0x00005464 File Offset: 0x00003664
		static void \u206C\u202C\u206B\u202D\u202A\u200F\u206B\u202C\u206C\u206C\u206E\u200C\u206E\u202A\u206C\u202A\u202C\u202D\u200F\u206A\u200F\u206B\u206E\u206E\u206C\u202B\u206D\u206B\u200C\u200F\u202B\u206C\u206B\u202A\u206D\u200D\u206B\u200B\u202A\u206D\u202E(Form, Color)
		{
			/*
An exception occurred when decompiling this method (0600081F)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form5::⁬‬⁫‭‪‏⁫‬⁬⁬⁮‌⁮‪⁬‪‬‭‏⁪‏⁫⁮⁮⁬‫⁭⁫‌‏‫⁬⁫‪⁭‍⁫​‪⁭‮(System.Windows.Forms.Form,System.Drawing.Color)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000820 RID: 2080
		static extern PictureBox \u202E\u200D\u200B\u202B\u202C\u206B\u206B\u206E\u202C\u202B\u206E\u202C\u202B\u206A\u200F\u206F\u200D\u206D\u202A\u206E\u206D\u202A\u202C\u202D\u200E\u202D\u206A\u200D\u202E\u202B\u202E\u206C\u200B\u200D\u206C\u200D\u202E\u206F\u202D\u200F\u202E();

		// Token: 0x06000821 RID: 2081 RVA: 0x000054C4 File Offset: 0x000036C4
		static void \u200C\u206D\u202E\u202D\u200B\u200D\u200F\u202C\u206A\u206D\u202D\u206D\u206F\u200F\u206F\u200F\u202B\u202B\u206A\u206C\u206F\u206B\u200D\u202D\u202A\u202C\u206D\u200D\u200D\u202D\u206C\u206F\u200D\u206C\u200F\u200F\u206D\u202E\u206E\u202A\u202E(PictureBox, PictureBoxSizeMode)
		{
			/*
An exception occurred when decompiling this method (06000821)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form5::‌⁭‮‭​‍‏‬⁪⁭‭⁭⁯‏⁯‏‫‫⁪⁬⁯⁫‍‭‪‬⁭‍‍‭⁬⁯‍⁬‏‏⁭‮⁮‪‮(System.Windows.Forms.PictureBox,System.Windows.Forms.PictureBoxSizeMode)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000822 RID: 2082 RVA: 0x0000548C File Offset: 0x0000368C
		static void \u202C\u202C\u200D\u206A\u200C\u200B\u206E\u200F\u200D\u206B\u206B\u202B\u206D\u200D\u206A\u206F\u200F\u200E\u200D\u206C\u200F\u202D\u206E\u202D\u206F\u202B\u200D\u200B\u202C\u200F\u206C\u202A\u200F\u200C\u206C\u200D\u202C\u202B\u206D\u202C\u202E(Control, DockStyle)
		{
			/*
An exception occurred when decompiling this method (06000822)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form5::‬‬‍⁪‌​⁮‏‍⁫⁫‫⁭‍⁪⁯‏‎‍⁬‏‭⁮‭⁯‫‍​‬‏⁬‪‏‌⁬‍‬‫⁭‬‮(System.Windows.Forms.Control,System.Windows.Forms.DockStyle)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000823 RID: 2083
		static extern Control.ControlCollection \u200B\u206A\u202C\u206B\u202B\u206C\u206F\u202C\u206C\u200C\u200D\u202E\u206E\u202C\u206E\u202A\u202C\u200C\u206B\u200F\u206A\u206E\u202B\u206B\u202A\u200F\u200B\u200C\u200C\u206E\u202B\u202B\u202A\u200F\u200B\u202D\u200B\u202E\u200B\u206C\u202E(Control);

		// Token: 0x06000824 RID: 2084
		static extern void \u202B\u200B\u202C\u200D\u206D\u202A\u206E\u206F\u200F\u200B\u202D\u206E\u202E\u202E\u200C\u202D\u200B\u202C\u206B\u206A\u206C\u200F\u200E\u206D\u202B\u202A\u206D\u206A\u206D\u206A\u200D\u206F\u206A\u200E\u200D\u200B\u202D\u202E\u206B\u206D\u202E(Control.ControlCollection, Control);

		// Token: 0x06000825 RID: 2085
		static extern int \u206E\u202E\u200F\u202A\u200C\u206E\u202A\u206A\u200C\u200F\u200B\u206B\u206A\u202A\u206E\u206E\u206E\u200E\u206F\u206A\u202A\u206D\u206C\u206F\u202A\u200C\u202D\u202A\u206D\u200E\u206C\u200E\u206A\u200C\u202A\u200E\u206B\u202C\u202A\u202D\u202E(Image);

		// Token: 0x06000826 RID: 2086
		static extern int \u206F\u206A\u200B\u200E\u202C\u206A\u202A\u200B\u200B\u206A\u200D\u206E\u200F\u200C\u200C\u200F\u202D\u206F\u206D\u202B\u200C\u202B\u202C\u202C\u200E\u206A\u202A\u200F\u202E\u202D\u206A\u200D\u202A\u206B\u200D\u206D\u202B\u202E\u206C\u200F\u202E(Image);

		// Token: 0x06000827 RID: 2087
		static extern int \u200E\u206F\u200B\u206C\u206C\u202D\u202A\u202D\u200F\u200F\u202B\u200F\u200C\u206D\u200C\u206B\u200E\u202A\u206A\u200B\u202A\u206D\u206F\u206A\u200F\u206E\u202D\u200C\u202A\u200E\u202D\u206A\u200C\u200E\u202A\u206F\u202D\u202B\u206C\u202C\u202E(int, int);

		// Token: 0x06000828 RID: 2088
		static extern Bitmap \u202A\u202C\u206A\u200B\u200C\u206B\u206C\u200C\u200F\u206B\u202B\u206F\u206C\u202B\u202E\u202C\u200C\u206A\u206F\u200C\u206E\u206A\u206E\u200F\u206B\u200B\u202C\u202D\u200C\u206B\u200C\u206B\u200C\u206B\u200C\u202C\u200C\u200D\u206D\u202E(int, int);

		// Token: 0x06000829 RID: 2089
		static extern Graphics \u202C\u200B\u206E\u206A\u200D\u206E\u206D\u206F\u202E\u200B\u200F\u202D\u200C\u202A\u200B\u206B\u202C\u200D\u200B\u206B\u206C\u206E\u202A\u202B\u200F\u206A\u206F\u200C\u202E\u206C\u206F\u200F\u206F\u206C\u202A\u200E\u202D\u202A\u202B\u200E\u202E(Image);

		// Token: 0x0600082A RID: 2090
		static extern GraphicsPath \u206F\u202E\u200B\u206B\u200D\u202E\u206F\u200B\u202A\u202C\u206A\u206F\u206C\u206D\u200F\u202A\u200F\u202C\u202C\u206F\u202C\u200D\u202D\u206D\u206D\u202C\u202D\u200C\u202D\u200D\u202B\u202B\u202A\u200B\u200D\u206F\u202A\u206D\u206F\u200D\u202E();

		// Token: 0x0600082B RID: 2091
		static extern void \u202E\u200D\u206E\u202E\u206E\u206F\u202A\u200E\u206C\u200B\u206F\u202D\u202A\u202A\u206E\u202C\u200E\u200D\u206B\u202D\u202D\u200C\u202C\u202C\u200B\u206F\u202E\u200E\u202C\u202A\u200B\u206E\u206D\u202C\u202E\u206B\u200F\u206F\u200E\u200D\u202E(GraphicsPath, int, int, int, int);

		// Token: 0x0600082C RID: 2092
		static extern void \u200C\u206D\u202C\u206A\u200E\u206C\u202B\u202E\u206E\u202E\u206A\u202D\u206A\u200E\u200F\u200F\u202B\u202D\u206E\u202E\u202D\u200C\u200E\u206B\u200E\u206A\u200D\u202E\u202A\u206B\u206A\u202B\u206E\u200E\u202E\u206A\u202A\u206B\u200D\u206A\u202E(Graphics, GraphicsPath);

		// Token: 0x0600082D RID: 2093
		static extern void \u206D\u202E\u200E\u200D\u200B\u200D\u200F\u202D\u200B\u206B\u200D\u206E\u202C\u200E\u202B\u206B\u206E\u206C\u200C\u206D\u200B\u206E\u202A\u200E\u200F\u202D\u202A\u202C\u206C\u202A\u200B\u206D\u202C\u200F\u206B\u200F\u206A\u206B\u206B\u200C\u202E(Graphics, Image, int, int, int, int);

		// Token: 0x0600082E RID: 2094
		static extern void \u206B\u200B\u202A\u202D\u206F\u200F\u202E\u206D\u200F\u206A\u206E\u202A\u202C\u206C\u200D\u206F\u202B\u202A\u200F\u206C\u200D\u200E\u200F\u200D\u206E\u206F\u202D\u200C\u206A\u206D\u202C\u200E\u206F\u202D\u200D\u200D\u206D\u206E\u202C\u202C\u202E(IDisposable);

		// Token: 0x0600082F RID: 2095 RVA: 0x00007878 File Offset: 0x00005A78
		static void \u206B\u202B\u202B\u206E\u202E\u202D\u200E\u206E\u200C\u202A\u200D\u202A\u202E\u202A\u200F\u202A\u200C\u206D\u206F\u206E\u206A\u202B\u202B\u202A\u202A\u200E\u200E\u200D\u206E\u202A\u200D\u200C\u206B\u200C\u200F\u202A\u202A\u200B\u206A\u202A\u202E(Control)
		{
			/*
An exception occurred when decompiling this method (0600082F)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form5::⁫‫‫⁮‮‭‎⁮‌‪‍‪‮‪‏‪‌⁭⁯⁮⁪‫‫‪‪‎‎‍⁮‪‍‌⁫‌‏‪‪​⁪‪‮(System.Windows.Forms.Control)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000830 RID: 2096
		static extern void \u202C\u200D\u202A\u206C\u202D\u202A\u206D\u202B\u202C\u200E\u206D\u200B\u206A\u202A\u202A\u206F\u200E\u200C\u206B\u202D\u202E\u206C\u206B\u202B\u206E\u200D\u206C\u206A\u206F\u202D\u200E\u206A\u202B\u206E\u206A\u200B\u200F\u200F\u202C\u202D\u202E(ContainerControl, SizeF);

		// Token: 0x06000831 RID: 2097
		static extern void \u200E\u206E\u206E\u202C\u206B\u202D\u206D\u206C\u206F\u202D\u200D\u200F\u206A\u202C\u200D\u202A\u202E\u206A\u206A\u200F\u206D\u206F\u206D\u206C\u200F\u202E\u202A\u200E\u200B\u202E\u202B\u202D\u200E\u202A\u200D\u202E\u206C\u206F\u200F\u206B\u202E(ContainerControl, AutoScaleMode);

		// Token: 0x06000832 RID: 2098
		static extern void \u200B\u200D\u206A\u200B\u206F\u200C\u200D\u202C\u200C\u202D\u200E\u206F\u202A\u202A\u206E\u206E\u206C\u200D\u200B\u206E\u206F\u200C\u206B\u206F\u202B\u202A\u206A\u206F\u206F\u202E\u202C\u200B\u200F\u202E\u200C\u206C\u200F\u206F\u200D\u200C\u202E(Form, Size);

		// Token: 0x06000833 RID: 2099
		static extern void \u206D\u202B\u206E\u202B\u200E\u202C\u202E\u202B\u200F\u202A\u200B\u202A\u200D\u200E\u206E\u202A\u202A\u202B\u200B\u206F\u206F\u202C\u206C\u202A\u200E\u206C\u202D\u200D\u200F\u200E\u206B\u206C\u200D\u206B\u202B\u200F\u200C\u202E\u206A\u206E\u202E(Control, string);

		// Token: 0x06000834 RID: 2100
		static extern void \u202B\u202D\u200E\u206C\u200F\u200E\u206B\u202C\u202E\u200C\u202B\u202A\u202C\u202B\u202A\u202E\u202B\u200E\u202E\u206A\u206A\u206C\u206C\u206E\u200F\u202A\u200D\u200F\u206A\u202E\u200C\u206F\u202B\u200C\u206C\u202E\u206D\u206F\u206A\u206E\u202E(Form, bool);

		// Token: 0x06000835 RID: 2101
		static extern void \u202D\u202D\u202E\u206A\u202E\u200F\u206F\u202C\u202E\u206D\u200D\u200B\u202E\u206D\u206B\u206C\u200D\u202B\u200C\u200F\u206E\u202B\u206B\u200F\u200F\u206F\u206C\u206C\u202A\u206D\u200E\u206A\u206B\u200E\u202C\u200C\u206F\u202D\u206B\u202C\u202E(Form, bool);

		// Token: 0x06000836 RID: 2102 RVA: 0x00006564 File Offset: 0x00004764
		static void \u200B\u202C\u200B\u206C\u202B\u206B\u206F\u206E\u206D\u202B\u206C\u202C\u202A\u206A\u202E\u202D\u202B\u206F\u202E\u206A\u200E\u200C\u200D\u206A\u202C\u206F\u202C\u202C\u200F\u206A\u202B\u206D\u202C\u206B\u202D\u206D\u206C\u206E\u206E\u206A\u202E(Control, string)
		{
			/*
An exception occurred when decompiling this method (06000836)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form5::​‬​⁬‫⁫⁯⁮⁭‫⁬‬‪⁪‮‭‫⁯‮⁪‎‌‍⁪‬⁯‬‬‏⁪‫⁭‬⁫‭⁭⁬⁮⁮⁪‮(System.Windows.Forms.Control,System.String)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000837 RID: 2103
		static extern Color \u200B\u206B\u206A\u200B\u202A\u200E\u206C\u206C\u202B\u206C\u206B\u206C\u202C\u206B\u206C\u202E\u206F\u206D\u200C\u202D\u202D\u200F\u206A\u200F\u206C\u202A\u202B\u206C\u206B\u200B\u202E\u200E\u206E\u206D\u206D\u206E\u206E\u200C\u202B\u202A\u202E();

		// Token: 0x06000838 RID: 2104
		static extern void \u200D\u202D\u200F\u206C\u202A\u200B\u206A\u206B\u206D\u202D\u202B\u200D\u202E\u206A\u202E\u206D\u200D\u206C\u206B\u200C\u206A\u206B\u206F\u206B\u206E\u200E\u206D\u206A\u200D\u206A\u200C\u200B\u206F\u202A\u206C\u206D\u206D\u202E\u206E\u202C\u202E(Form, EventHandler);

		// Token: 0x06000839 RID: 2105
		static extern void \u202E\u200D\u200C\u200D\u202A\u200F\u200C\u206B\u206D\u206F\u206C\u200F\u200B\u200F\u206A\u202E\u202E\u202B\u206D\u200D\u206A\u200D\u206C\u206F\u202A\u202E\u202A\u200C\u200D\u200D\u202A\u206B\u206F\u200F\u202B\u206F\u202A\u200C\u202E\u202E\u202E(Control, bool);

		// Token: 0x040002CB RID: 715
		private PictureBox pictureBox;

		// Token: 0x040002CC RID: 716
		private IContainer components;
	}
}
