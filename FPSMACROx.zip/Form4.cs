﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using AutoItX3Lib;
using Guna.UI2.WinForms;
using Siticone.UI.WinForms;
using Siticone.UI.WinForms.Enums;
using Siticone.UI.WinForms.Suite;

namespace FPSMACROx
{
	// Token: 0x0200003F RID: 63
	public partial class Form4 : Form
	{
		// Token: 0x060003D9 RID: 985 RVA: 0x0000746C File Offset: 0x0000566C
		public Form4()
		{
			/*
An exception occurred when decompiling this method (060003D9)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::.ctor()

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003DA RID: 986 RVA: 0x000064DC File Offset: 0x000046DC
		private void AimBotTimer_Tick(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060003DA)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::AimBotTimer_Tick(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003DB RID: 987 RVA: 0x000074B8 File Offset: 0x000056B8
		private void arkaplandacalısanxd()
		{
			/*
An exception occurred when decompiling this method (060003DB)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::arkaplandacalısanxd()

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003DC RID: 988
		private extern Point? GetHeadPosition(Point enemyPosition, Bitmap screenshot);

		// Token: 0x060003DD RID: 989
		private extern bool IsColorMatch(Color pixelColor, Color targetColor);

		// Token: 0x060003DE RID: 990 RVA: 0x000074D8 File Offset: 0x000056D8
		private int GetHeadAverageX(int x, int y, Bitmap screenshot)
		{
			jmp();
		}

		// Token: 0x060003DF RID: 991
		private extern int GetHeadAverageY(int x, int y, Bitmap screenshot);

		// Token: 0x060003E0 RID: 992
		private static extern bool is_colora(Color ada);

		// Token: 0x060003E1 RID: 993 RVA: 0x00007504 File Offset: 0x00005704
		private static int adsada(int x, int y, Bitmap objec)
		{
			/*
An exception occurred when decompiling this method (060003E1)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Int32 FPSMACROx.Form4::adsada(System.Int32,System.Int32,System.Drawing.Bitmap)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003E2 RID: 994
		private extern void Form4_Load(object sender, EventArgs e);

		// Token: 0x060003E3 RID: 995
		private extern void siticoneControlBox1_Click(object sender, EventArgs e);

		// Token: 0x060003E4 RID: 996 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneMetroTrackBar4_Scroll(object sender, ScrollEventArgs e)
		{
			/*
An exception occurred when decompiling this method (060003E4)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneMetroTrackBar4_Scroll(System.Object,System.Windows.Forms.ScrollEventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003E5 RID: 997 RVA: 0x000064DC File Offset: 0x000046DC
		private void label2_Click(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060003E5)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::label2_Click(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003E6 RID: 998 RVA: 0x000064DC File Offset: 0x000046DC
		private void label4_Click(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060003E6)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::label4_Click(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003E7 RID: 999
		private extern void siticoneMetroTrackBar1_Scroll(object sender, ScrollEventArgs e);

		// Token: 0x060003E8 RID: 1000 RVA: 0x00007518 File Offset: 0x00005718
		private void siticoneToggleSwitch1_CheckedChanged(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060003E8)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneToggleSwitch1_CheckedChanged(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003E9 RID: 1001 RVA: 0x00007558 File Offset: 0x00005758
		private void siticoneButton4_KeyDown(object sender, KeyEventArgs e)
		{
			/*
An exception occurred when decompiling this method (060003E9)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneButton4_KeyDown(System.Object,System.Windows.Forms.KeyEventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003EA RID: 1002
		private extern void siticoneButton4_MouseDown(object sender, MouseEventArgs e);

		// Token: 0x060003EB RID: 1003 RVA: 0x00007580 File Offset: 0x00005780
		public static Keys ConvertStringToKey(string keyString)
		{
			/*
An exception occurred when decompiling this method (060003EB)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Windows.Forms.Keys FPSMACROx.Form4::ConvertStringToKey(System.String)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003EC RID: 1004 RVA: 0x000075B8 File Offset: 0x000057B8
		private void siticoneButton4_TextChanged(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060003EC)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneButton4_TextChanged(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003ED RID: 1005
		private extern void siticoneMetroTrackBar3_Scroll(object sender, ScrollEventArgs e);

		// Token: 0x060003EE RID: 1006
		private extern double ConvertTrackBarValueToDouble(int trackbarValue, int minTrackbar, int maxTrackbar, double minDouble, double maxDouble);

		// Token: 0x060003EF RID: 1007 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneMetroTrackBar2_Scroll(object sender, ScrollEventArgs e)
		{
			/*
An exception occurred when decompiling this method (060003EF)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneMetroTrackBar2_Scroll(System.Object,System.Windows.Forms.ScrollEventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003F0 RID: 1008 RVA: 0x000075CC File Offset: 0x000057CC
		private void siticoneTextBox2_TextChanged(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060003F0)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneTextBox2_TextChanged(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003F1 RID: 1009 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneTextBox3_TextChanged(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060003F1)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneTextBox3_TextChanged(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003F2 RID: 1010 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneTextBox1_TextChanged(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060003F2)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneTextBox1_TextChanged(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003F3 RID: 1011 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneTextBox4_TextChanged(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060003F3)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneTextBox4_TextChanged(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003F4 RID: 1012
		private extern void siticoneImageButton1_Click(object sender, EventArgs e);

		// Token: 0x060003F5 RID: 1013 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneButton3_Click(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060003F5)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneButton3_Click(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003F6 RID: 1014
		private extern void siticoneMetroTrackBar2_Scroll_1(object sender, ScrollEventArgs e);

		// Token: 0x060003F7 RID: 1015 RVA: 0x0000760C File Offset: 0x0000580C
		private void siticoneTextBox1_TextChanged_1(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060003F7)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneTextBox1_TextChanged_1(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003F8 RID: 1016 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneButton4_Click(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060003F8)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneButton4_Click(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003F9 RID: 1017 RVA: 0x00007644 File Offset: 0x00005844
		private void siticoneTextBox3_TextChanged_1(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060003F9)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneTextBox3_TextChanged_1(System.Object,System.EventArgs)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003FA RID: 1018 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneButton1_Click(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060003FA)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneButton1_Click(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003FB RID: 1019 RVA: 0x000064DC File Offset: 0x000046DC
		private void yenithread()
		{
			/*
An exception occurred when decompiling this method (060003FB)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::yenithread()

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060003FC RID: 1020
		[DllImport("gdi32.dll")]
		private static extern bool BitBlt(IntPtr hdcDest, int nxDest, int nyDest, int nWidth, int nHeight, IntPtr hdcSrc, int nXSrc, int nYSrc, int dwRop);

		// Token: 0x060003FD RID: 1021
		[DllImport("gdi32.dll")]
		private static extern IntPtr CreateCompatibleBitmap(IntPtr hdc, int width, int nHeight);

		// Token: 0x060003FE RID: 1022
		[DllImport("gdi32.dll")]
		private static extern IntPtr CreateCompatibleDC(IntPtr hdc);

		// Token: 0x060003FF RID: 1023
		[DllImport("gdi32.dll")]
		private static extern IntPtr DeleteDC(IntPtr hdc);

		// Token: 0x06000400 RID: 1024
		[DllImport("gdi32.dll")]
		private static extern IntPtr DeleteObject(IntPtr hObject);

		// Token: 0x06000401 RID: 1025
		[DllImport("user32.dll")]
		private static extern IntPtr GetDesktopWindow();

		// Token: 0x06000402 RID: 1026
		[DllImport("user32.dll")]
		private static extern IntPtr GetWindowDC(IntPtr hWnd);

		// Token: 0x06000403 RID: 1027
		[DllImport("user32.dll")]
		private static extern bool ReleaseDC(IntPtr hWnd, IntPtr hDc);

		// Token: 0x06000404 RID: 1028
		[DllImport("gdi32.dll")]
		private static extern IntPtr SelectObject(IntPtr hdc, IntPtr hObject);

		// Token: 0x06000405 RID: 1029
		public extern Bitmap CaptureRegion(Rectangle region);

		// Token: 0x06000406 RID: 1030 RVA: 0x0000766C File Offset: 0x0000586C
		private static bool scolor(Color pixelcolor)
		{
			/*
An exception occurred when decompiling this method (06000406)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean FPSMACROx.Form4::scolor(System.Drawing.Color)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000407 RID: 1031
		private extern void baslama();

		// Token: 0x06000408 RID: 1032
		[DllImport("user32.dll")]
		public static extern short GetAsyncKeyState(Keys vKey);

		// Token: 0x06000409 RID: 1033
		private extern bool hasan();

		// Token: 0x0600040A RID: 1034
		public extern int kafanin_ortalamasini_al(int x, int y, Bitmap selam);

		// Token: 0x0600040B RID: 1035
		public extern int KafaninOrtalamasiAl(int x, int y, Bitmap selam, bool isFar);

		// Token: 0x0600040C RID: 1036 RVA: 0x000064DC File Offset: 0x000046DC
		private void saldr(int st, int sty)
		{
			/*
An exception occurred when decompiling this method (0600040C)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::saldr(System.Int32,System.Int32)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600040D RID: 1037 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneButton2_Click(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (0600040D)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneButton2_Click(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600040E RID: 1038
		private extern void textBox1_TextChanged(object sender, EventArgs e);

		// Token: 0x0600040F RID: 1039
		private extern void textBox2_TextChanged(object sender, EventArgs e);

		// Token: 0x06000410 RID: 1040 RVA: 0x000076A4 File Offset: 0x000058A4
		private void textBox3_TextChanged(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (06000410)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::textBox3_TextChanged(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000411 RID: 1041 RVA: 0x000064DC File Offset: 0x000046DC
		private void textBox6_TextChanged(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (06000411)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::textBox6_TextChanged(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000412 RID: 1042 RVA: 0x000064DC File Offset: 0x000046DC
		private void textBox5_TextChanged(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (06000412)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::textBox5_TextChanged(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000413 RID: 1043 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneButton3_KeyDown(object sender, KeyEventArgs e)
		{
			/*
An exception occurred when decompiling this method (06000413)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneButton3_KeyDown(System.Object,System.Windows.Forms.KeyEventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000414 RID: 1044 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneButton5_MouseDown(object sender, MouseEventArgs e)
		{
			/*
An exception occurred when decompiling this method (06000414)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneButton5_MouseDown(System.Object,System.Windows.Forms.MouseEventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000415 RID: 1045 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneButton3_Click_1(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (06000415)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneButton3_Click_1(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000416 RID: 1046
		private extern void siticoneCustomCheckBox4_CheckedChanged(object sender, EventArgs e);

		// Token: 0x06000417 RID: 1047 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneButton5_Click(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (06000417)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneButton5_Click(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000418 RID: 1048 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneButton5_KeyDown(object sender, KeyEventArgs e)
		{
			/*
An exception occurred when decompiling this method (06000418)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneButton5_KeyDown(System.Object,System.Windows.Forms.KeyEventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000419 RID: 1049 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneButton5_MouseDown_1(object sender, MouseEventArgs e)
		{
			/*
An exception occurred when decompiling this method (06000419)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneButton5_MouseDown_1(System.Object,System.Windows.Forms.MouseEventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600041A RID: 1050
		private extern void siticoneCustomCheckBox1_CheckedChanged(object sender, EventArgs e);

		// Token: 0x0600041B RID: 1051 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneButton3_Click_2(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (0600041B)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneButton3_Click_2(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600041C RID: 1052 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneButton7_Click(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (0600041C)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneButton7_Click(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600041D RID: 1053
		private extern void siticoneButton7_KeyDown(object sender, KeyEventArgs e);

		// Token: 0x0600041E RID: 1054
		private extern void siticoneButton7_MouseDown(object sender, MouseEventArgs e);

		// Token: 0x0600041F RID: 1055
		private extern void siticoneCustomCheckBox5_CheckedChanged(object sender, EventArgs e);

		// Token: 0x06000420 RID: 1056
		private extern void arkanidon();

		// Token: 0x06000421 RID: 1057
		private extern void siticoneButton7_TextChanged(object sender, EventArgs e);

		// Token: 0x06000422 RID: 1058 RVA: 0x000076E0 File Offset: 0x000058E0
		private void siticoneToggleSwitch4_CheckedChanged(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (06000422)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::siticoneToggleSwitch4_CheckedChanged(System.Object,System.EventArgs)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000423 RID: 1059
		private extern void siticoneToggleSwitch3_CheckedChanged(object sender, EventArgs e);

		// Token: 0x06000424 RID: 1060
		protected override extern void Dispose(bool disposing);

		// Token: 0x06000425 RID: 1061
		private extern void InitializeComponent();

		// Token: 0x06000426 RID: 1062 RVA: 0x000076FC File Offset: 0x000058FC
		// Note: this type is marked as 'beforefieldinit'.
		static Form4()
		{
			/*
An exception occurred when decompiling this method (06000426)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::.cctor()

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000427 RID: 1063
		static extern Type \u200F\u206B\u202A\u206D\u202C\u202E\u200F\u202D\u202E\u202E\u206B\u202D\u202E\u202B\u200C\u202B\u202B\u202C\u206D\u206F\u202B\u202B\u200D\u206D\u206A\u206D\u206E\u206F\u202C\u206F\u206E\u206C\u206D\u202A\u200B\u206D\u202B\u200C\u202E\u206D\u202E(Guid);

		// Token: 0x06000428 RID: 1064
		static extern object \u200F\u202C\u206D\u202D\u206D\u206B\u202D\u200F\u200E\u200C\u206F\u200E\u202B\u206C\u202B\u200B\u206C\u202D\u202B\u202C\u206D\u202A\u202C\u206A\u202A\u202C\u200E\u206D\u200E\u202C\u206E\u206E\u206E\u202C\u202A\u200E\u202A\u206D\u202D\u200F\u202E(Type);

		// Token: 0x06000429 RID: 1065
		static extern Screen \u206F\u200E\u200C\u200D\u202D\u206A\u202D\u206F\u202C\u206B\u206B\u202E\u200D\u200E\u202B\u202E\u200F\u206C\u206B\u206D\u200E\u206E\u200B\u200D\u200E\u206D\u202E\u202B\u206C\u206B\u206F\u202C\u206D\u202B\u202B\u200B\u200F\u206F\u200E\u206A\u202E();

		// Token: 0x0600042A RID: 1066
		static extern Rectangle \u202E\u200E\u200B\u202E\u200C\u206C\u206A\u200B\u202C\u202E\u202C\u200F\u206C\u202E\u200D\u200D\u206A\u206C\u206D\u200D\u206C\u206F\u200F\u200B\u202E\u206D\u202C\u202D\u200F\u202C\u200B\u206B\u206C\u200E\u206E\u206E\u206E\u206B\u200B\u200F\u202E(Screen);

		// Token: 0x0600042B RID: 1067
		static extern int \u200F\u200B\u206E\u206D\u202D\u200C\u202B\u206D\u206D\u200F\u206E\u200F\u202D\u206C\u200F\u202D\u206A\u200D\u200C\u206F\u200D\u206A\u202B\u200F\u200F\u202E\u206A\u206E\u202D\u206A\u206C\u206F\u206B\u206B\u202B\u200D\u200B\u202E\u206A\u200D\u202E(Image);

		// Token: 0x0600042C RID: 1068
		static extern int \u202C\u202A\u202E\u200F\u206B\u202D\u200B\u200C\u206A\u202E\u202B\u206F\u200F\u206E\u206A\u202B\u206F\u206B\u206E\u202A\u202B\u200E\u200C\u202A\u206C\u200F\u202E\u202A\u200E\u206D\u200E\u206E\u206A\u200D\u200D\u206A\u202C\u206F\u206E\u206C\u202E(Image);

		// Token: 0x0600042D RID: 1069
		static extern Color \u202B\u202A\u200E\u206A\u202E\u200F\u206E\u200C\u206A\u206E\u202C\u200E\u200B\u202B\u200C\u200E\u202C\u200E\u206B\u200F\u202C\u206F\u206D\u200E\u202D\u200C\u202D\u202B\u202B\u206F\u200B\u202A\u200B\u206E\u200E\u200C\u206D\u202B\u200B\u200F\u202E(Bitmap, int, int);

		// Token: 0x0600042E RID: 1070
		static extern int \u200B\u206E\u202E\u200B\u200F\u202D\u202A\u206C\u200F\u206E\u206A\u206B\u206B\u206A\u206A\u202D\u206F\u202E\u202B\u200B\u206D\u206E\u202C\u202C\u200D\u200B\u202B\u200E\u206C\u206D\u200F\u202E\u202E\u200B\u202E\u200F\u202D\u200D\u202A\u206A\u202E(int);

		// Token: 0x0600042F RID: 1071 RVA: 0x00006564 File Offset: 0x00004764
		static void \u202A\u206F\u202B\u200E\u202E\u202D\u206D\u206A\u200E\u206F\u202B\u206E\u206C\u202B\u200E\u202B\u202D\u202B\u202E\u206C\u206F\u200D\u202B\u202C\u200D\u202E\u206E\u202A\u200B\u200E\u202D\u202A\u200D\u206D\u200E\u206A\u202E\u206B\u206B\u206B\u202E(Control, string)
		{
			/*
An exception occurred when decompiling this method (0600042F)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::‪⁯‫‎‮‭⁭⁪‎⁯‫⁮⁬‫‎‫‭‫‮⁬⁯‍‫‬‍‮⁮‪​‎‭‪‍⁭‎⁪‮⁫⁫⁫‮(System.Windows.Forms.Control,System.String)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000430 RID: 1072
		static extern void \u206C\u202C\u200B\u200B\u202B\u200B\u202A\u202B\u206F\u206C\u200E\u206A\u200E\u206C\u202B\u200E\u206E\u206C\u206C\u202C\u200B\u202A\u206B\u206B\u206C\u200B\u202C\u206D\u202D\u200C\u200F\u202D\u202E\u206F\u200D\u202E\u202A\u202E\u202D\u202A\u202E(Control, Color);

		// Token: 0x06000431 RID: 1073 RVA: 0x00007740 File Offset: 0x00005940
		static void \u200E\u200D\u200C\u200B\u206A\u202A\u206C\u206F\u200E\u206D\u202D\u200E\u206E\u206F\u202B\u202D\u206D\u200D\u206F\u202C\u206B\u202B\u202B\u206A\u202C\u200D\u206A\u202A\u202D\u200C\u206A\u202E\u202B\u206E\u202C\u206C\u202D\u202B\u202D\u206E\u202E(bool)
		{
			/*
An exception occurred when decompiling this method (06000431)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::‎‍‌​⁪‪⁬⁯‎⁭‭‎⁮⁯‫‭⁭‍⁯‬⁫‫‫⁪‬‍⁪‪‭‌⁪‮‫⁮‬⁬‭‫‭⁮‮(System.Boolean)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000432 RID: 1074
		static extern string \u202E\u200C\u202C\u206E\u202B\u202D\u202A\u200D\u200D\u202D\u202C\u206D\u206E\u200E\u200E\u206D\u206E\u206D\u200D\u206D\u206D\u206B\u202D\u206E\u206F\u206F\u200D\u202B\u202B\u200D\u202C\u200F\u202B\u202A\u200D\u202C\u202A\u206A\u206B\u206C\u202E(Control);

		// Token: 0x06000433 RID: 1075
		static extern short \u206F\u202E\u200E\u202C\u200E\u200F\u206D\u202E\u202D\u206F\u202B\u202D\u202A\u202B\u200D\u202C\u206E\u202E\u202C\u206D\u206D\u200F\u200D\u206F\u200F\u206F\u200D\u200B\u206C\u206F\u200F\u200D\u206F\u206C\u202A\u202A\u206B\u200F\u206B\u202E\u202E(string);

		// Token: 0x06000434 RID: 1076
		static extern void \u206B\u200C\u202B\u206D\u202B\u202E\u202C\u206D\u202A\u200C\u206B\u206A\u206D\u206C\u202B\u200D\u202E\u206B\u200B\u202B\u200F\u202B\u200F\u200B\u202D\u202C\u206C\u200E\u202C\u202D\u200D\u206C\u200C\u202D\u200F\u202C\u202D\u206B\u200F\u206C\u202E(Control);

		// Token: 0x06000435 RID: 1077
		static extern int \u200E\u202B\u200E\u200E\u202B\u202D\u206C\u206D\u200B\u206F\u200F\u206E\u200C\u202E\u200D\u206F\u202C\u202B\u202C\u206B\u200D\u202C\u202B\u206F\u202E\u202B\u206A\u202E\u202E\u202A\u206F\u202E\u200C\u202B\u200E\u206D\u200F\u206F\u200F\u202A\u202E(SiticoneTrackBar);

		// Token: 0x06000436 RID: 1078 RVA: 0x0000659C File Offset: 0x0000479C
		static void \u200B\u200B\u200B\u200B\u200D\u206B\u202C\u202B\u206F\u206E\u202E\u202C\u206F\u206D\u206E\u200B\u206D\u206D\u206E\u202D\u202D\u200F\u206C\u202D\u206A\u206F\u206F\u206A\u202D\u200B\u206D\u206C\u202C\u200C\u202A\u200C\u206E\u200C\u206A\u202E\u202E(Control, Point)
		{
			/*
An exception occurred when decompiling this method (06000436)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::​​​​‍⁫‬‫⁯⁮‮‬⁯⁭⁮​⁭⁭⁮‭‭‏⁬‭⁪⁯⁯⁪‭​⁭⁬‬‌‪‌⁮‌⁪‮‮(System.Windows.Forms.Control,System.Drawing.Point)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000437 RID: 1079
		static extern string \u206F\u206D\u206C\u206A\u202E\u202B\u202A\u200B\u206B\u200B\u202A\u202B\u200C\u206D\u200F\u206B\u202B\u202E\u206E\u200C\u202A\u206D\u206D\u206C\u202A\u200B\u200E\u200B\u202B\u200B\u206B\u206B\u206D\u206F\u200B\u206E\u200B\u206D\u202C\u200E\u202E(int);

		// Token: 0x06000438 RID: 1080
		static extern bool \u200F\u200E\u206D\u200F\u202E\u202C\u206B\u206B\u200B\u200D\u202A\u202D\u202C\u200B\u202B\u200F\u206C\u206E\u200F\u202E\u206C\u206C\u206A\u206F\u202C\u206F\u206E\u200B\u202C\u202C\u200D\u202E\u200F\u200D\u202A\u206D\u206D\u206C\u200C\u200C\u202E(SiticoneToggleSwitch);

		// Token: 0x06000439 RID: 1081
		static extern Thread \u200C\u200D\u206A\u202D\u200D\u206C\u206C\u202E\u202E\u202A\u200F\u206E\u206A\u206E\u202C\u200E\u200E\u202B\u202B\u200B\u206F\u206F\u202D\u202D\u200C\u200C\u202D\u200C\u206E\u200D\u206E\u202B\u202E\u206C\u200D\u206F\u202A\u206A\u206F\u200D\u202E(ThreadStart);

		// Token: 0x0600043A RID: 1082 RVA: 0x00005AE4 File Offset: 0x00003CE4
		static void \u206C\u206B\u200E\u206A\u206B\u206B\u202B\u202A\u206C\u202E\u206D\u206F\u202E\u206B\u206E\u206B\u200B\u202B\u200C\u202D\u200C\u200F\u202C\u200C\u206B\u206C\u202E\u206C\u202C\u206B\u206E\u206A\u202B\u206C\u200C\u206D\u200E\u202A\u200F\u206A\u202E(Thread)
		{
			/*
An exception occurred when decompiling this method (0600043A)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::⁬⁫‎⁪⁫⁫‫‪⁬‮⁭⁯‮⁫⁮⁫​‫‌‭‌‏‬‌⁫⁬‮⁬‬⁫⁮⁪‫⁬‌⁭‎‪‏⁪‮(System.Threading.Thread)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600043B RID: 1083
		static extern bool \u200B\u202E\u202B\u206E\u200B\u206B\u202E\u200C\u202C\u200F\u206E\u206D\u202E\u206A\u206C\u202D\u206D\u206E\u206E\u206F\u200C\u200F\u206B\u200C\u200D\u206E\u206F\u202E\u202B\u206A\u202B\u200F\u200F\u202E\u202B\u206D\u206F\u202E\u206E\u206B\u202E(SiticoneButton);

		// Token: 0x0600043C RID: 1084
		static extern Keys \u206C\u200F\u206D\u206B\u200C\u202D\u206F\u200E\u200E\u200D\u200D\u200D\u200C\u202E\u206A\u200D\u200F\u206C\u200D\u200D\u200D\u200E\u202B\u206B\u202C\u200C\u200F\u206F\u202C\u200B\u206C\u200E\u200C\u206C\u206E\u202D\u200D\u206E\u206A\u206A\u202E(KeyEventArgs);

		// Token: 0x0600043D RID: 1085
		static extern string \u200D\u200B\u202A\u202E\u206F\u202C\u202A\u206C\u200D\u206F\u200F\u200F\u200F\u206F\u202E\u206F\u200C\u200B\u200E\u202E\u202E\u200D\u206F\u202D\u202D\u200E\u206A\u200F\u200B\u202B\u206E\u202B\u202E\u202D\u206F\u206E\u202D\u200D\u202A\u206E\u202E(object);

		// Token: 0x0600043E RID: 1086 RVA: 0x0000539C File Offset: 0x0000359C
		static bool \u200C\u202A\u206E\u200D\u200D\u200B\u206F\u206B\u206B\u202D\u206D\u206C\u202C\u200C\u202D\u206E\u200D\u200E\u202A\u202B\u206E\u202D\u206C\u206B\u206F\u200D\u200E\u200E\u206C\u200F\u200B\u202E\u206A\u202D\u200B\u200E\u202C\u200D\u206B\u202C\u202E(string, string)
		{
			/*
An exception occurred when decompiling this method (0600043E)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean FPSMACROx.Form4::‌‪⁮‍‍​⁯⁫⁫‭⁭⁬‬‌‭⁮‍‎‪‫⁮‭⁬⁫⁯‍‎‎⁬‏​‮⁪‭​‎‬‍⁫‬‮(System.String,System.String)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600043F RID: 1087
		static extern bool \u202D\u200F\u202C\u206D\u206C\u206F\u202D\u206A\u202A\u206D\u200E\u202D\u202C\u202B\u200C\u200C\u200F\u206A\u200C\u200C\u200E\u202D\u206D\u202C\u200E\u202D\u200B\u202E\u206A\u206F\u206C\u202C\u202D\u206E\u200F\u206A\u206C\u202E\u206C\u202D\u202E(string, string);

		// Token: 0x06000440 RID: 1088
		static extern void \u200C\u206D\u202A\u202D\u200C\u202B\u200E\u206C\u202A\u202A\u200F\u206D\u202E\u206A\u206E\u200D\u202A\u206B\u200F\u202E\u206F\u200D\u202D\u200B\u206B\u200D\u206E\u206D\u206B\u200C\u200C\u200E\u202A\u200C\u206C\u206A\u206A\u202B\u200D\u202A\u202E(SiticoneButton, bool);

		// Token: 0x06000441 RID: 1089 RVA: 0x0000692C File Offset: 0x00004B2C
		static MouseButtons \u206D\u206C\u202D\u206A\u206C\u200F\u206A\u200D\u202B\u202C\u206E\u200C\u206E\u202B\u206B\u200B\u202D\u200B\u202D\u202D\u200D\u202B\u206B\u200D\u202E\u200D\u202A\u200D\u202D\u206F\u206F\u200B\u200B\u200F\u206D\u200D\u200E\u202E\u202E\u206C\u202E(MouseEventArgs)
		{
			/*
An exception occurred when decompiling this method (06000441)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Windows.Forms.MouseButtons FPSMACROx.Form4::⁭⁬‭⁪⁬‏⁪‍‫‬⁮‌⁮‫⁫​‭​‭‭‍‫⁫‍‮‍‪‍‭⁯⁯​​‏⁭‍‎‮‮⁬‮(System.Windows.Forms.MouseEventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000442 RID: 1090 RVA: 0x0000441C File Offset: 0x0000261C
		static Type \u202A\u202E\u206B\u200B\u200E\u206C\u206E\u202D\u206C\u200D\u202E\u202C\u206F\u202A\u200C\u206B\u202D\u206E\u206B\u200D\u206B\u206D\u200E\u206E\u200F\u200C\u206B\u200E\u206E\u206D\u202B\u200D\u200B\u206C\u202E\u202A\u200F\u202E\u200F\u206A\u202E(RuntimeTypeHandle)
		{
			/*
An exception occurred when decompiling this method (06000442)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Type FPSMACROx.Form4::‪‮⁫​‎⁬⁮‭⁬‍‮‬⁯‪‌⁫‭⁮⁫‍⁫⁭‎⁮‏‌⁫‎⁮⁭‫‍​⁬‮‪‏‮‏⁪‮(System.RuntimeTypeHandle)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000443 RID: 1091 RVA: 0x00007784 File Offset: 0x00005984
		static object \u206D\u200F\u200C\u200E\u206A\u202A\u200D\u202B\u206A\u202D\u206D\u200B\u202C\u206F\u200C\u202A\u202E\u202E\u202C\u206D\u200E\u200D\u206F\u202D\u200D\u202D\u206B\u206F\u202A\u200B\u202C\u202A\u200C\u202B\u200D\u200E\u202A\u200B\u200D\u206F\u202E(Type, string, bool)
		{
			/*
An exception occurred when decompiling this method (06000443)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Object FPSMACROx.Form4::⁭‏‌‎⁪‪‍‫⁪‭⁭​‬⁯‌‪‮‮‬⁭‎‍⁯‭‍‭⁫⁯‪​‬‪‌‫‍‎‪​‍⁯‮(System.Type,System.String,System.Boolean)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000444 RID: 1092 RVA: 0x00005364 File Offset: 0x00003564
		static string \u200F\u202E\u200C\u200C\u202B\u202C\u206B\u206E\u200F\u202D\u206C\u206A\u202D\u206C\u202C\u206E\u206E\u202A\u202E\u202B\u200F\u200B\u202D\u206F\u206F\u206C\u200C\u202D\u202E\u200D\u206B\u206F\u200E\u200F\u200D\u206A\u202D\u202C\u202C\u200D\u202E(Exception)
		{
			/*
An exception occurred when decompiling this method (06000444)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.String FPSMACROx.Form4::‏‮‌‌‫‬⁫⁮‏‭⁬⁪‭⁬‬⁮⁮‪‮‫‏​‭⁯⁯⁬‌‭‮‍⁫⁯‎‏‍⁪‭‬‬‍‮(System.Exception)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000445 RID: 1093
		static extern string \u206E\u200B\u200E\u206D\u200F\u202D\u206F\u202A\u202C\u202A\u202A\u200D\u200D\u202E\u206F\u206B\u206E\u202D\u202A\u206F\u200C\u206D\u206D\u202E\u206E\u200F\u206A\u206A\u200F\u200E\u206D\u206E\u206E\u200C\u206D\u206C\u202E\u206A\u202B\u202C\u202E(string, string);

		// Token: 0x06000446 RID: 1094
		static extern void \u202C\u200C\u202A\u206B\u206D\u206E\u202C\u200B\u200B\u206A\u200B\u200C\u200F\u206D\u206C\u202B\u206B\u206F\u206D\u200B\u200C\u200F\u202E\u206B\u206F\u206E\u206C\u200B\u206B\u202E\u206C\u206A\u200D\u200D\u200F\u202A\u200E\u202A\u200E\u206C\u202E(string);

		// Token: 0x06000447 RID: 1095
		static extern string \u200E\u206F\u202C\u202A\u202A\u202C\u206E\u202D\u200E\u202D\u200F\u206F\u200C\u206C\u206F\u206F\u200C\u200C\u206F\u206E\u206E\u206B\u206D\u206B\u202A\u200B\u202A\u206C\u202D\u206A\u206A\u202C\u206C\u202D\u202C\u206A\u200E\u206D\u206B\u202C\u202E();

		// Token: 0x06000448 RID: 1096 RVA: 0x000077BC File Offset: 0x000059BC
		static void \u202A\u206E\u206E\u206C\u200B\u206E\u200F\u200C\u202E\u206D\u206C\u202B\u206C\u206C\u200D\u202E\u202D\u200E\u202C\u202B\u200D\u206C\u200F\u206C\u206A\u200E\u206E\u200B\u206B\u206A\u202E\u202C\u206E\u200F\u206A\u202A\u202A\u202D\u202B\u206C\u202E(TextBox, string)
		{
			/*
An exception occurred when decompiling this method (06000448)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::‪⁮⁮⁬​⁮‏‌‮⁭⁬‫⁬⁬‍‮‭‎‬‫‍⁬‏⁬⁪‎⁮​⁫⁪‮‬⁮‏⁪‪‪‭‫⁬‮(Siticone.UI.WinForms.Suite.TextBox,System.String)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000449 RID: 1097
		static extern string \u200D\u206F\u206F\u202B\u206B\u206E\u202D\u200E\u200B\u200D\u202E\u206C\u202B\u200E\u200C\u202C\u206C\u206F\u202A\u206F\u202C\u200D\u200B\u202D\u200E\u206B\u206E\u206D\u202D\u202D\u200F\u200F\u200D\u202D\u200B\u200B\u200C\u206B\u200D\u202C\u202E(TextBox);

		// Token: 0x0600044A RID: 1098
		static extern int \u200E\u206B\u200D\u202E\u206E\u206A\u202A\u206B\u200C\u206E\u206F\u206F\u200F\u200B\u206B\u200D\u206A\u202C\u200E\u202B\u206D\u200E\u202D\u200E\u206C\u202B\u202D\u202B\u206E\u206C\u202B\u200B\u200F\u202B\u202C\u206C\u200B\u206F\u200B\u200C\u202E(string);

		// Token: 0x0600044B RID: 1099
		static extern void \u202D\u200B\u206D\u202E\u202D\u202D\u206D\u206A\u200F\u206C\u200C\u200C\u202C\u206B\u206A\u202C\u206A\u200D\u206B\u202D\u200F\u206D\u202A\u206C\u200C\u206F\u202E\u200D\u202C\u200F\u200E\u206E\u206E\u202B\u202E\u206F\u202A\u202D\u200C\u202E\u202E(SiticoneTrackBar, int);

		// Token: 0x0600044C RID: 1100 RVA: 0x0000571C File Offset: 0x0000391C
		static Win32Exception \u202A\u202B\u202A\u206E\u202B\u202D\u202B\u206F\u200D\u206D\u206F\u206D\u206E\u206E\u200F\u200F\u200E\u200B\u200D\u200B\u200E\u200F\u206D\u206A\u202A\u200E\u200E\u202A\u200B\u200B\u206A\u206A\u206F\u200D\u202E\u200C\u200E\u200F\u202A\u200E\u202E()
		{
			/*
An exception occurred when decompiling this method (0600044C)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.ComponentModel.Win32Exception FPSMACROx.Form4::‪‫‪⁮‫‭‫⁯‍⁭⁯⁭⁮⁮‏‏‎​‍​‎‏⁭⁪‪‎‎‪​​⁪⁪⁯‍‮‌‎‏‪‎‮()

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600044D RID: 1101
		static extern Bitmap \u202B\u206F\u200B\u202D\u202B\u206E\u206A\u206C\u200B\u202C\u206E\u206D\u206A\u206E\u200F\u202E\u206B\u200D\u200D\u206D\u202B\u202E\u206B\u202D\u206B\u202A\u202A\u202B\u200C\u202D\u202A\u206F\u206D\u206A\u200E\u206D\u206F\u200B\u202E\u206B\u202E(IntPtr);

		// Token: 0x0600044E RID: 1102 RVA: 0x00004680 File Offset: 0x00002880
		static void \u200C\u202E\u206F\u202A\u202E\u202D\u202B\u206F\u202A\u202A\u206C\u206B\u202C\u200C\u200C\u206A\u200E\u200E\u200E\u202C\u200B\u202D\u202C\u202C\u202D\u206A\u206E\u202B\u200B\u206D\u200B\u206E\u206F\u206F\u206E\u206E\u206D\u202C\u200D\u206F\u202E(int)
		{
			/*
An exception occurred when decompiling this method (0600044E)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::‌‮⁯‪‮‭‫⁯‪‪⁬⁫‬‌‌⁪‎‎‎‬​‭‬‬‭⁪⁮‫​⁭​⁮⁯⁯⁮⁮⁭‬‍⁯‮(System.Int32)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600044F RID: 1103 RVA: 0x000077D0 File Offset: 0x000059D0
		static object \u200E\u202A\u206E\u202E\u202C\u206F\u200B\u206C\u200B\u206E\u202C\u200F\u206A\u200D\u200E\u202C\u202C\u200C\u202C\u200B\u200D\u202A\u202D\u202E\u206D\u202D\u202E\u206F\u200D\u206B\u206D\u200D\u200D\u200D\u202E\u200E\u200C\u206A\u202E\u202A\u202E(Type A_0, string A_1)
		{
			6.515780969648808E+186;
			throw 5;
		}

		// Token: 0x06000450 RID: 1104
		static extern double \u206F\u206C\u200C\u206B\u206E\u202A\u200C\u202B\u206B\u202C\u202E\u202E\u200C\u202C\u200F\u206B\u202B\u206C\u200D\u200F\u206C\u200C\u206F\u206A\u202B\u200D\u202E\u206F\u200C\u200B\u206C\u206A\u200E\u202E\u206D\u200B\u206F\u206B\u206A\u202A\u202E(double, double);

		// Token: 0x06000451 RID: 1105 RVA: 0x0000661C File Offset: 0x0000481C
		static double \u206D\u202B\u200F\u202C\u200F\u206F\u200B\u206C\u202D\u200D\u202D\u206F\u202E\u202C\u206F\u202B\u200F\u202D\u202E\u206B\u206B\u202E\u206E\u202B\u202B\u202B\u202C\u200B\u200C\u206B\u206D\u206C\u200B\u202E\u202D\u200C\u202E\u206B\u200E\u200D\u202E(double)
		{
			/*
An exception occurred when decompiling this method (06000451)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Double FPSMACROx.Form4::⁭‫‏‬‏⁯​⁬‭‍‭⁯‮‬⁯‫‏‭‮⁫⁫‮⁮‫‫‫‬​‌⁫⁭⁬​‮‭‌‮⁫‎‍‮(System.Double)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000452 RID: 1106
		static extern bool \u206C\u202D\u202B\u200C\u206F\u200E\u202E\u206E\u200C\u202B\u200F\u202E\u200D\u202B\u206F\u206B\u206A\u206E\u200D\u202A\u206A\u206B\u206B\u202E\u200E\u202B\u202B\u202B\u206D\u200D\u202B\u200C\u202B\u200C\u202C\u206E\u200B\u200B\u200F\u206C\u202E(Keys);

		// Token: 0x06000453 RID: 1107
		static extern void \u200C\u206E\u202D\u200B\u202D\u206A\u200D\u206D\u206B\u202D\u200B\u202B\u206C\u200F\u202E\u202D\u206F\u206A\u206E\u202A\u200B\u200C\u200F\u200C\u200F\u202C\u202A\u202D\u206D\u200E\u200C\u202E\u206B\u202A\u200D\u206D\u206D\u202B\u202A\u206E\u202E(Image);

		// Token: 0x06000454 RID: 1108
		static extern bool \u202C\u202E\u206D\u200E\u206F\u206F\u200C\u206E\u200F\u200F\u200C\u202D\u206F\u202E\u206C\u206E\u206E\u200D\u206C\u200C\u206F\u206E\u202A\u206F\u200C\u206C\u200F\u200C\u206C\u200F\u206B\u200D\u206F\u200C\u202D\u206D\u206B\u202E\u206A\u202B\u202E(SiticoneCustomCheckBox);

		// Token: 0x06000455 RID: 1109
		static extern void \u200E\u206A\u206B\u202C\u200D\u206B\u200C\u206D\u202B\u200B\u202B\u202B\u202E\u200D\u202B\u200C\u206B\u202E\u206E\u206F\u206E\u202E\u206F\u202B\u202E\u206A\u202C\u206F\u200D\u202C\u202E\u202A\u206D\u206B\u202B\u206B\u202C\u206E\u200B\u202D\u202E(IDisposable);

		// Token: 0x06000456 RID: 1110 RVA: 0x000077EC File Offset: 0x000059EC
		static Container \u206A\u206B\u200B\u202D\u202C\u200E\u206E\u206E\u206F\u206F\u202D\u200D\u202D\u200D\u206A\u202D\u206A\u206D\u200F\u202D\u206E\u206E\u200C\u202D\u206A\u206B\u202E\u200E\u202C\u202C\u206E\u202B\u206B\u202B\u206D\u202C\u202B\u200C\u202A\u206B\u202E()
		{
			/*
An exception occurred when decompiling this method (06000456)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.ComponentModel.Container FPSMACROx.Form4::⁪⁫​‭‬‎⁮⁮⁯⁯‭‍‭‍⁪‭⁪⁭‏‭⁮⁮‌‭⁪⁫‮‎‬‬⁮‫⁫‫⁭‬‫‌‪⁫‮()

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000457 RID: 1111
		static extern SiticoneDragControl \u200F\u200E\u202D\u200E\u200B\u200E\u202D\u206E\u206D\u200E\u202E\u202B\u202B\u206E\u206E\u200D\u200E\u200E\u206A\u206B\u206C\u206F\u206F\u202C\u200D\u200F\u202D\u202C\u206E\u206E\u206B\u200E\u206B\u200D\u200B\u202A\u200B\u202B\u202D\u206F\u202E(IContainer);

		// Token: 0x06000458 RID: 1112
		static extern Label \u202B\u206E\u206F\u206E\u206D\u206F\u202B\u206F\u206F\u206D\u200D\u206D\u200B\u200D\u200D\u202C\u206E\u200B\u206D\u200E\u202A\u202C\u202B\u202A\u202B\u202E\u202A\u206C\u202D\u202D\u206C\u206C\u206A\u200B\u206A\u200C\u202B\u206C\u202D\u202A\u202E();

		// Token: 0x06000459 RID: 1113
		static extern SiticoneButton \u206B\u206D\u200B\u206E\u200D\u200C\u202E\u200F\u202C\u200E\u200E\u202C\u202B\u206D\u200D\u206B\u202B\u200C\u202C\u202C\u202C\u206E\u200F\u206A\u200D\u206C\u206D\u206D\u206F\u202B\u200B\u206A\u202A\u206C\u206A\u200E\u202A\u206B\u200C\u200D\u202E();

		// Token: 0x0600045A RID: 1114
		static extern SiticoneToggleSwitch \u200B\u200F\u206D\u202E\u206C\u206D\u202C\u202C\u206D\u206B\u200B\u206F\u206B\u202D\u206C\u200D\u206E\u202D\u206A\u200B\u206F\u206A\u200B\u200C\u202A\u200D\u206F\u200B\u202B\u200D\u206D\u202B\u206E\u200B\u202D\u206E\u206B\u206A\u202A\u206A\u202E();

		// Token: 0x0600045B RID: 1115
		static extern SiticoneMetroTrackBar \u200E\u206E\u200C\u200F\u200F\u200D\u206C\u200E\u202E\u202B\u202A\u200E\u206E\u200C\u200F\u202E\u206E\u206E\u202A\u202D\u206D\u202B\u206D\u202D\u206F\u202E\u206A\u206C\u200B\u206C\u206F\u206F\u202B\u202D\u200C\u200F\u200C\u202A\u202B\u202E();

		// Token: 0x0600045C RID: 1116
		static extern SiticoneTextBox \u202E\u202E\u206A\u202D\u202E\u202E\u200F\u206C\u202A\u202C\u206A\u200C\u202C\u202B\u206E\u200E\u200C\u206D\u202E\u200F\u206B\u206E\u206F\u206E\u202A\u202C\u200C\u202A\u202C\u206F\u202C\u202A\u200C\u202B\u200F\u206C\u200E\u200E\u200D\u200F\u202E();

		// Token: 0x0600045D RID: 1117 RVA: 0x00007830 File Offset: 0x00005A30
		static Guna2VSeparator \u206D\u206F\u206C\u200E\u206D\u200F\u206C\u202D\u206F\u200D\u206C\u202E\u202A\u202C\u200E\u206F\u200F\u206F\u202D\u200B\u200E\u206A\u202D\u206C\u206A\u202E\u206F\u206D\u200E\u200F\u202A\u206F\u202B\u200C\u206E\u206B\u202A\u206A\u206C\u200E\u202E()
		{
			/*
An exception occurred when decompiling this method (0600045D)

ICSharpCode.Decompiler.DecompilerException: Error decompiling Guna.UI2.WinForms.Guna2VSeparator FPSMACROx.Form4::⁭⁯⁬‎⁭‏⁬‭⁯‍⁬‮‪‬‎⁯‏⁯‭​‎⁪‭⁬⁪‮⁯⁭‎‏‪⁯‫‌⁮⁫‪⁪⁬‎‮()

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600045E RID: 1118
		static extern SiticoneCustomCheckBox \u202B\u200F\u200C\u202E\u202D\u206A\u200B\u200F\u202E\u202D\u202D\u200E\u202B\u200B\u206A\u206A\u200D\u202C\u200F\u202D\u200F\u206A\u200B\u202E\u206A\u200F\u200C\u206D\u200F\u202E\u206A\u206F\u200D\u200C\u200B\u202B\u200C\u202B\u206D\u200D\u202E();

		// Token: 0x0600045F RID: 1119
		static extern PictureBox \u202E\u200B\u200D\u200D\u206D\u206C\u206C\u206E\u202E\u206E\u206B\u206F\u200C\u206C\u206C\u206E\u206A\u202B\u200D\u200E\u206E\u206E\u206F\u202D\u206E\u206A\u206F\u202E\u202E\u206C\u200E\u202E\u202C\u206E\u202B\u206F\u206E\u206F\u202C\u202E();

		// Token: 0x06000460 RID: 1120
		static extern SiticoneImageButton \u202D\u206C\u206C\u202C\u206E\u200F\u200B\u206B\u202D\u202D\u202D\u202E\u206C\u200E\u206F\u206A\u202D\u202A\u202A\u202E\u206B\u206A\u200D\u206B\u206B\u206C\u206F\u202B\u202A\u200D\u200D\u202C\u202A\u202B\u206C\u200F\u206B\u202B\u206D\u202C\u202E();

		// Token: 0x06000461 RID: 1121
		static extern SiticoneImageCheckBox \u200E\u206F\u200F\u200D\u202B\u202D\u200D\u200E\u200B\u206E\u200B\u206B\u200B\u200E\u200C\u206B\u200F\u206E\u202A\u200B\u202E\u206D\u200C\u206C\u200C\u202C\u202C\u202B\u206A\u200B\u200C\u200F\u202A\u202C\u206C\u200C\u206C\u202B\u200F\u202E\u202E();

		// Token: 0x06000462 RID: 1122 RVA: 0x00007854 File Offset: 0x00005A54
		static TextBox \u206C\u206A\u206A\u202E\u206D\u200F\u202B\u206E\u202A\u200B\u202B\u202D\u200E\u206A\u206D\u206E\u206D\u200D\u200E\u206F\u202D\u206C\u206E\u200D\u206C\u206C\u202A\u202C\u200C\u202C\u200B\u206E\u202B\u202D\u200C\u206F\u206D\u200B\u206E\u202C\u202E()
		{
			/*
An exception occurred when decompiling this method (06000462)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Windows.Forms.TextBox FPSMACROx.Form4::⁬⁪⁪‮⁭‏‫⁮‪​‫‭‎⁪⁭⁮⁭‍‎⁯‭⁬⁮‍⁬⁬‪‬‌‬​⁮‫‭‌⁯⁭​⁮‬‮()

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000463 RID: 1123
		static extern void \u202C\u206C\u202B\u202A\u206C\u206F\u200D\u202D\u200B\u202A\u202D\u206E\u202E\u202D\u200E\u206A\u202E\u200F\u206A\u200C\u202E\u206C\u200B\u202A\u202A\u200B\u206C\u206F\u206E\u206A\u202B\u200C\u200B\u200D\u206A\u200C\u206A\u202E\u206C\u206F\u202E(ISupportInitialize);

		// Token: 0x06000464 RID: 1124 RVA: 0x00007878 File Offset: 0x00005A78
		static void \u200D\u202A\u206C\u206D\u200D\u206E\u202E\u200D\u202B\u206F\u206A\u206A\u206A\u206A\u206C\u202E\u206A\u200C\u202D\u206C\u206E\u200E\u200D\u200E\u206E\u200B\u202B\u206A\u200F\u202E\u200C\u202E\u202E\u202A\u206B\u202D\u206A\u206D\u202D\u206E\u202E(Control)
		{
			/*
An exception occurred when decompiling this method (06000464)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::‍‪⁬⁭‍⁮‮‍‫⁯⁪⁪⁪⁪⁬‮⁪‌‭⁬⁮‎‍‎⁮​‫⁪‏‮‌‮‮‪⁫‭⁪⁭‭⁮‮(System.Windows.Forms.Control)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000465 RID: 1125 RVA: 0x000078AC File Offset: 0x00005AAC
		static void \u206A\u206C\u200C\u202D\u206E\u202A\u202E\u206E\u206D\u202B\u202D\u200C\u202E\u206E\u206C\u202A\u202D\u206B\u200D\u206F\u206B\u206E\u200B\u202B\u200E\u206C\u202D\u206E\u200E\u202C\u206F\u202A\u202D\u206E\u200B\u206E\u206B\u202C\u206F\u200F\u202E(SiticoneDragControl, Control)
		{
			/*
An exception occurred when decompiling this method (06000465)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::⁪⁬‌‭⁮‪‮⁮⁭‫‭‌‮⁮⁬‪‭⁫‍⁯⁫⁮​‫‎⁬‭⁮‎‬⁯‪‭⁮​⁮⁫‬⁯‏‮(Siticone.UI.WinForms.SiticoneDragControl,System.Windows.Forms.Control)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000466 RID: 1126
		static extern void \u200C\u202D\u206E\u200F\u206B\u206F\u202D\u206B\u206B\u202B\u206A\u200B\u202E\u200D\u200F\u206A\u202A\u202B\u200B\u202D\u200F\u206C\u200F\u206C\u200E\u200E\u200D\u200E\u200F\u206D\u200C\u206C\u206A\u202A\u206A\u206E\u202D\u206A\u202C\u200E\u202E(Control, bool);

		// Token: 0x06000467 RID: 1127
		static extern Font \u206C\u206F\u200C\u202D\u200F\u202B\u206A\u202A\u206A\u202A\u200E\u206F\u206A\u206B\u202A\u200F\u206D\u200B\u200D\u206C\u202B\u206D\u202B\u200F\u206C\u206F\u206C\u202C\u200E\u200C\u202B\u206B\u202D\u200F\u200C\u200D\u206D\u206E\u206A\u202A\u202E(string, float);

		// Token: 0x06000468 RID: 1128 RVA: 0x000078F8 File Offset: 0x00005AF8
		static void \u206C\u206B\u202E\u202C\u200B\u206B\u202E\u202D\u206E\u200E\u200D\u200C\u206E\u200E\u206A\u202B\u200D\u200E\u202D\u200B\u206B\u202D\u206F\u200D\u200B\u202D\u202D\u206C\u206E\u200D\u200B\u202E\u202C\u200C\u200D\u202A\u206A\u206A\u200E\u202E(Control, Font)
		{
			/*
An exception occurred when decompiling this method (06000468)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::⁬⁫‮‬​⁫‮‭⁮‎‍‌⁮‎⁪‫‍‎‭​⁫‭⁯‍​‭‭⁬⁮‍​‮‬‌‍‪⁪⁪‎‮(System.Windows.Forms.Control,System.Drawing.Font)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000469 RID: 1129
		static extern void \u200D\u202E\u202E\u206C\u200F\u200F\u206A\u206C\u202C\u202B\u200C\u200F\u202E\u206E\u200F\u200E\u200E\u202E\u206B\u202E\u202D\u200B\u202C\u202C\u202E\u202D\u206C\u206B\u206F\u200F\u206D\u206E\u202A\u202B\u206A\u200E\u202E\u206C\u200D\u202B\u202E(Control, string);

		// Token: 0x0600046A RID: 1130
		static extern void \u200D\u200F\u206B\u202B\u206B\u200C\u202E\u202E\u200C\u206F\u200D\u200C\u200D\u202A\u200D\u200B\u200B\u202E\u202D\u206E\u200B\u200B\u206A\u202E\u202D\u202B\u200B\u206C\u206A\u206D\u206C\u202C\u206A\u206B\u200B\u202B\u200C\u206B\u202A\u202E\u202E(Control, Size);

		// Token: 0x0600046B RID: 1131
		static extern void \u200C\u200D\u206E\u200F\u200E\u200C\u206E\u206E\u202A\u202E\u202B\u206D\u202D\u202B\u206C\u206C\u206A\u200B\u202B\u200F\u200C\u202D\u206A\u200B\u200F\u202E\u202E\u206A\u206B\u200C\u202A\u202E\u200D\u202A\u200C\u206B\u200D\u206A\u200E\u206A\u202E(Control, int);

		// Token: 0x0600046C RID: 1132 RVA: 0x00007928 File Offset: 0x00005B28
		static void \u202B\u206B\u202E\u206C\u206D\u200D\u202A\u206C\u202B\u200F\u202C\u200E\u202E\u200D\u200D\u202B\u202B\u202D\u200C\u206A\u202C\u202B\u202A\u206A\u206B\u202C\u206C\u200E\u200F\u200F\u202E\u200B\u206F\u206D\u202B\u202A\u200E\u206A\u202C\u202D\u202E(SiticoneButton, bool)
		{
			/*
An exception occurred when decompiling this method (0600046C)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::‫⁫‮⁬⁭‍‪⁬‫‏‬‎‮‍‍‫‫‭‌⁪‬‫‪⁪⁫‬⁬‎‏‏‮​⁯⁭‫‪‎⁪‬‭‮(Siticone.UI.WinForms.SiticoneButton,System.Boolean)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600046D RID: 1133
		static extern void \u202B\u202E\u200D\u200D\u202C\u202B\u202B\u206E\u206F\u200D\u200C\u206A\u206D\u202A\u206B\u206B\u206C\u200E\u202A\u202A\u206E\u206E\u206A\u200F\u206F\u206C\u202E\u206A\u200B\u202C\u200C\u200D\u202B\u200F\u202E\u206D\u202C\u202A\u206C\u202C\u202E(SiticoneButton, Color);

		// Token: 0x0600046E RID: 1134
		static extern void \u200C\u200F\u202B\u206B\u206F\u202A\u200F\u206C\u206A\u206F\u202D\u202B\u206D\u206B\u202D\u202A\u206F\u202E\u200F\u206F\u202D\u206F\u206B\u206B\u202D\u202C\u202E\u200D\u200F\u200E\u200F\u200E\u202B\u206A\u202B\u206D\u202E\u206C\u206F\u206A\u202E(SiticoneButton, int);

		// Token: 0x0600046F RID: 1135
		static extern void \u206C\u202B\u202D\u206E\u206F\u200C\u202C\u200E\u200C\u202E\u202D\u202A\u202B\u202B\u200B\u200E\u202A\u200F\u206F\u200B\u200B\u206F\u202D\u206E\u206B\u206D\u206F\u206B\u206B\u200D\u206E\u202D\u206B\u202E\u200B\u206B\u202C\u206E\u200B\u206E\u202E(SiticoneButton, DashStyle);

		// Token: 0x06000470 RID: 1136
		static extern void \u202C\u206B\u206E\u206F\u200B\u202A\u200D\u206C\u200D\u206C\u206E\u206C\u206B\u202E\u202C\u202D\u200F\u200F\u206B\u200E\u200D\u206C\u206D\u206D\u200C\u202E\u200C\u206E\u202A\u200E\u202C\u206D\u202E\u206B\u200C\u202A\u200B\u200D\u202D\u202E\u202E(SiticoneButton, int);

		// Token: 0x06000471 RID: 1137 RVA: 0x00007940 File Offset: 0x00005B40
		static void \u200D\u206B\u206D\u200D\u202C\u206A\u200B\u200B\u206F\u206A\u202A\u202A\u200E\u206A\u206C\u206D\u200F\u202B\u206F\u202E\u206C\u206D\u206F\u206B\u200D\u202E\u206B\u206F\u206D\u200C\u206F\u206F\u206A\u200F\u206A\u202C\u200D\u200E\u200D\u202A\u202E(SiticoneButton, ButtonMode)
		{
			/*
An exception occurred when decompiling this method (06000471)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::‍⁫⁭‍‬⁪​​⁯⁪‪‪‎⁪⁬⁭‏‫⁯‮⁬⁭⁯⁫‍‮⁫⁯⁭‌⁯⁯⁪‏⁪‬‍‎‍‪‮(Siticone.UI.WinForms.SiticoneButton,Siticone.UI.WinForms.Enums.ButtonMode)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000472 RID: 1138 RVA: 0x00007954 File Offset: 0x00005B54
		static ButtonState \u206B\u200D\u200F\u206E\u200D\u200F\u202D\u202C\u200B\u206F\u206E\u200D\u200C\u200B\u206B\u202A\u206F\u206B\u202B\u206E\u202A\u206A\u206E\u206E\u202D\u200E\u202A\u202A\u206F\u200B\u200B\u200E\u200D\u202A\u202A\u200F\u200C\u202B\u202D\u200E\u202E(SiticoneButton A_0)
		{
			jmp();
		}

		// Token: 0x06000473 RID: 1139
		static extern void \u206F\u206C\u200E\u206C\u202D\u202B\u200F\u202D\u206A\u206D\u206D\u200E\u206F\u202A\u206C\u202C\u200C\u202A\u206E\u200D\u200E\u200D\u200B\u200E\u206E\u206A\u206E\u202E\u202C\u202C\u202D\u202B\u206E\u202E\u202E\u202E\u206D\u202C\u202A\u206F\u202E(ButtonState, Color);

		// Token: 0x06000474 RID: 1140
		static extern void \u200F\u206D\u206A\u206E\u202E\u206C\u202B\u206F\u200D\u200D\u206A\u202D\u200E\u200D\u200F\u200C\u200B\u206E\u206D\u202A\u200C\u206A\u206A\u202A\u202E\u206D\u202B\u206C\u200C\u202D\u200F\u200B\u200B\u202A\u200D\u206B\u206F\u200F\u200F\u200E\u202E(ButtonState, CustomButtonBase);

		// Token: 0x06000475 RID: 1141 RVA: 0x00007970 File Offset: 0x00005B70
		static ButtonImages \u206C\u200F\u202E\u202D\u200D\u206C\u200E\u206C\u206E\u206B\u202C\u202A\u202C\u200C\u206F\u200F\u202D\u206D\u202C\u202A\u200B\u200C\u200D\u202B\u202E\u206B\u206E\u200D\u202D\u202E\u200B\u206F\u206B\u206C\u206F\u202E\u206B\u206C\u200D\u202E\u202E(SiticoneButton)
		{
			/*
An exception occurred when decompiling this method (06000475)

ICSharpCode.Decompiler.DecompilerException: Error decompiling Siticone.UI.WinForms.Suite.ButtonImages FPSMACROx.Form4::⁬‏‮‭‍⁬‎⁬⁮⁫‬‪‬‌⁯‏‭⁭‬‪​‌‍‫‮⁫⁮‍‭‮​⁯⁫⁬⁯‮⁫⁬‍‮‮(Siticone.UI.WinForms.SiticoneButton)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000476 RID: 1142
		static extern void \u200B\u202D\u202D\u206C\u206B\u206D\u206B\u206C\u206B\u202C\u206C\u202C\u206F\u200D\u200E\u202A\u202E\u202D\u206B\u200C\u206A\u202B\u200F\u206D\u200D\u206F\u206E\u206B\u206B\u202B\u200F\u202B\u200D\u206D\u206A\u202C\u206B\u202C\u202C\u202A\u202E(ButtonImages, CustomButtonBase);

		// Token: 0x06000477 RID: 1143
		static extern Color \u200F\u206E\u202A\u202C\u206B\u202D\u200F\u206C\u206A\u200F\u200E\u202A\u206C\u202A\u206F\u202D\u200D\u200C\u202E\u202B\u202B\u206E\u202E\u200F\u206E\u206D\u206E\u206B\u206D\u202A\u202C\u206C\u200D\u200C\u200F\u202B\u206C\u206D\u202D\u206D\u202E();

		// Token: 0x06000478 RID: 1144 RVA: 0x000079A4 File Offset: 0x00005BA4
		static void \u206D\u206F\u202C\u202C\u200B\u206D\u202C\u202B\u206F\u202E\u206D\u206A\u200F\u206D\u206A\u206D\u200D\u206F\u200E\u200C\u200C\u206B\u206E\u206F\u200F\u206E\u202A\u202B\u206F\u206E\u206F\u200B\u206A\u200E\u200B\u202C\u206E\u200F\u206C\u200C\u202E(SiticoneButton, Color)
		{
			/*
An exception occurred when decompiling this method (06000478)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::⁭⁯‬‬​⁭‬‫⁯‮⁭⁪‏⁭⁪⁭‍⁯‎‌‌⁫⁮⁯‏⁮‪‫⁯⁮⁯​⁪‎​‬⁮‏⁬‌‮(Siticone.UI.WinForms.SiticoneButton,System.Drawing.Color)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000479 RID: 1145
		static extern ButtonState \u206B\u200E\u202E\u200E\u206E\u206B\u200B\u202D\u206B\u206C\u206F\u202B\u200E\u200D\u206C\u206A\u202B\u202C\u206F\u206A\u200C\u206F\u206D\u202E\u200E\u206C\u202E\u206E\u202B\u202B\u202C\u206C\u200F\u200D\u200E\u206A\u200E\u206C\u200D\u202D\u202E(SiticoneButton);

		// Token: 0x0600047A RID: 1146
		static extern void \u206B\u206F\u200E\u206C\u202E\u202C\u200D\u202B\u202D\u206F\u202C\u202D\u206A\u206C\u200C\u206B\u202C\u206E\u206C\u200F\u206B\u206A\u202D\u202B\u206C\u202E\u200B\u202C\u206E\u206F\u206A\u202C\u202E\u202D\u206D\u202B\u206F\u200E\u200C\u206E\u202E(Control, Padding);

		// Token: 0x0600047B RID: 1147 RVA: 0x000079CC File Offset: 0x00005BCC
		static ShadowDecoration \u206F\u200C\u202A\u206F\u200F\u202A\u206B\u200B\u206D\u200C\u206B\u206B\u202E\u202A\u200B\u206B\u200C\u202C\u202C\u206A\u200F\u206D\u206A\u202D\u202A\u206D\u206F\u202D\u206A\u202B\u202A\u200E\u202A\u200D\u206A\u206E\u206A\u200E\u200D\u202C\u202E(SiticoneButton)
		{
			/*
An exception occurred when decompiling this method (0600047B)

ICSharpCode.Decompiler.DecompilerException: Error decompiling Siticone.UI.WinForms.Suite.ShadowDecoration FPSMACROx.Form4::⁯‌‪⁯‏‪⁫​⁭‌⁫⁫‮‪​⁫‌‬‬⁪‏⁭⁪‭‪⁭⁯‭⁪‫‪‎‪‍⁪⁮⁪‎‍‬‮(Siticone.UI.WinForms.SiticoneButton)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600047C RID: 1148
		static extern void \u200F\u206C\u206A\u202C\u200C\u202A\u200E\u202D\u206A\u200D\u202B\u200C\u206F\u206B\u202A\u202E\u202A\u206F\u206E\u206D\u200C\u206B\u200E\u206A\u202E\u206D\u206E\u202A\u200D\u206A\u202A\u206A\u202D\u206D\u202D\u200E\u202C\u200B\u206C\u206E\u202E(ShadowDecoration, Control);

		// Token: 0x0600047D RID: 1149 RVA: 0x000079FC File Offset: 0x00005BFC
		static void \u202E\u202A\u202E\u200E\u202D\u202C\u206B\u206A\u200E\u200B\u200B\u202B\u200C\u202A\u200D\u206B\u200B\u202D\u200E\u206A\u200C\u206F\u202B\u206F\u200E\u202C\u200E\u202B\u202E\u202D\u206E\u206D\u200F\u202A\u200B\u200C\u202C\u200F\u202C\u202B\u202E(Control, EventHandler)
		{
			/*
An exception occurred when decompiling this method (0600047D)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::‮‪‮‎‭‬⁫⁪‎​​‫‌‪‍⁫​‭‎⁪‌⁯‫⁯‎‬‎‫‮‭⁮⁭‏‪​‌‬‏‬‫‮(System.Windows.Forms.Control,System.EventHandler)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600047E RID: 1150
		static extern void \u206B\u206B\u200F\u206E\u202D\u202D\u200B\u206F\u202A\u206B\u206C\u202B\u202A\u202D\u200E\u202B\u206D\u206A\u206F\u202E\u202A\u206C\u202D\u206F\u202D\u200B\u202E\u206E\u206A\u200C\u200E\u206D\u202E\u202C\u202D\u202A\u200E\u200E\u202E\u200C\u202E(Control, EventHandler);

		// Token: 0x0600047F RID: 1151
		static extern void \u200D\u202C\u202A\u202B\u206F\u206A\u206B\u206E\u206D\u200F\u202D\u200E\u206D\u206B\u200E\u202D\u206E\u202B\u206F\u206B\u206A\u206A\u200B\u202A\u200F\u200B\u206D\u206C\u202C\u206A\u206A\u206C\u200C\u200F\u206B\u202C\u206A\u200C\u202E\u206F\u202E(Control, KeyEventHandler);

		// Token: 0x06000480 RID: 1152
		static extern void \u206C\u202C\u206B\u202A\u200B\u202D\u200B\u206B\u200D\u206D\u200B\u200B\u206B\u200B\u200C\u202B\u202E\u206F\u202D\u200D\u206F\u206A\u202A\u206B\u202B\u200C\u202B\u200F\u206F\u202E\u202B\u206D\u206D\u206C\u200D\u202C\u200B\u202E\u200E\u206D\u202E(Control, MouseEventHandler);

		// Token: 0x06000481 RID: 1153
		static extern ToggleSwitchState \u206E\u206B\u202A\u200B\u200F\u206D\u206D\u202C\u200F\u202D\u206A\u206E\u202E\u200F\u200F\u202D\u202A\u206B\u206B\u202A\u200E\u206C\u200E\u206D\u202E\u202B\u202A\u206A\u206A\u200E\u206A\u206E\u206F\u200C\u200B\u200C\u200C\u206E\u206D\u200C\u202E(SiticoneToggleSwitch);

		// Token: 0x06000482 RID: 1154 RVA: 0x00007A1C File Offset: 0x00005C1C
		static void \u200C\u206B\u202E\u200D\u206B\u202B\u206C\u206C\u202B\u206F\u206F\u202C\u206F\u206D\u206A\u206C\u202A\u202A\u206D\u206A\u200D\u206B\u202E\u202A\u200E\u202A\u206C\u200B\u206F\u202B\u200F\u202A\u200B\u202C\u200D\u206C\u200E\u206E\u202B\u202E\u202E(ToggleSwitchState, Color)
		{
			/*
An exception occurred when decompiling this method (06000482)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::‌⁫‮‍⁫‫⁬⁬‫⁯⁯‬⁯⁭⁪⁬‪‪⁭⁪‍⁫‮‪‎‪⁬​⁯‫‏‪​‬‍⁬‎⁮‫‮‮(Siticone.UI.WinForms.Suite.ToggleSwitchState,System.Drawing.Color)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000483 RID: 1155
		static extern void \u200F\u206C\u202B\u200B\u202B\u200F\u206C\u206D\u200F\u206D\u202A\u202A\u202E\u200C\u202B\u202B\u202A\u200E\u200C\u206B\u202A\u200E\u206A\u206D\u206D\u200F\u200E\u206A\u202C\u200F\u206A\u202C\u200F\u200E\u206B\u206E\u202B\u202A\u206D\u200E\u202E(ToggleSwitchState, Color);

		// Token: 0x06000484 RID: 1156
		static extern void \u206E\u206C\u202D\u200B\u206E\u206E\u202E\u200C\u200D\u202C\u202A\u200F\u202A\u200B\u200E\u206C\u206E\u202B\u202D\u202B\u202A\u202C\u200E\u206F\u200C\u202C\u202D\u206C\u200B\u206B\u202C\u206A\u200D\u202D\u200B\u200D\u206E\u200F\u202A\u200E\u202E(ToggleSwitchState, Color);

		// Token: 0x06000485 RID: 1157 RVA: 0x00007A34 File Offset: 0x00005C34
		static void \u200D\u206D\u200E\u202A\u202D\u200D\u200D\u206B\u200F\u200B\u206E\u202D\u200F\u200F\u200F\u206E\u206B\u206A\u206B\u206F\u202B\u202C\u206D\u206C\u206E\u202C\u202E\u202B\u206B\u200C\u206C\u206D\u200C\u200C\u200C\u202B\u202C\u206A\u200B\u200D\u202E(ToggleSwitchState, Color)
		{
			/*
An exception occurred when decompiling this method (06000485)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::‍⁭‎‪‭‍‍⁫‏​⁮‭‏‏‏⁮⁫⁪⁫⁯‫‬⁭⁬⁮‬‮‫⁫‌⁬⁭‌‌‌‫‬⁪​‍‮(Siticone.UI.WinForms.Suite.ToggleSwitchState,System.Drawing.Color)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000486 RID: 1158 RVA: 0x00007A4C File Offset: 0x00005C4C
		static void \u202D\u202E\u200C\u202D\u206F\u206D\u202E\u202D\u202B\u202E\u200E\u202C\u202E\u200E\u200D\u206F\u202D\u202D\u200B\u200B\u200B\u206D\u206E\u206F\u202E\u206C\u206E\u200C\u206D\u202A\u206B\u206A\u206D\u202B\u200F\u202B\u202C\u202C\u200D\u200E\u202E(ToggleSwitchState A_0, ToggleSwitch A_1)
		{
			goto IL_00;
			for (;;)
			{
				IL_00:
				goto IL_00;
			}
		}

		// Token: 0x06000487 RID: 1159
		static extern ShadowDecoration \u202C\u200E\u202D\u200E\u206E\u200B\u202D\u206F\u206C\u202D\u206C\u202B\u206F\u206A\u200D\u202D\u200C\u200D\u202E\u202B\u202D\u206B\u200D\u200F\u206D\u200D\u200F\u202D\u200B\u200E\u206E\u206A\u206D\u206A\u200D\u206E\u206D\u200F\u200D\u200C\u202E(SiticoneToggleSwitch);

		// Token: 0x06000488 RID: 1160
		static extern ToggleSwitchState \u206F\u200B\u200D\u206A\u202D\u206A\u202C\u200B\u206C\u202C\u206F\u202A\u206B\u206B\u202B\u206E\u202B\u206C\u200F\u206C\u206C\u206F\u200F\u202B\u206D\u206D\u206E\u200B\u206D\u200B\u200D\u202D\u200C\u202B\u206A\u200D\u206B\u202B\u206E\u206D\u202E(SiticoneToggleSwitch);

		// Token: 0x06000489 RID: 1161
		static extern void \u206A\u202D\u206B\u206F\u206E\u200B\u200D\u200C\u202B\u206F\u206F\u202A\u206E\u202B\u202C\u200B\u200B\u200F\u202B\u206C\u200D\u200C\u200F\u202E\u206A\u202A\u206D\u206D\u200F\u200C\u206A\u206D\u202B\u206E\u200D\u206B\u206B\u202A\u206A\u200F\u202E(ToggleSwitch, EventHandler);

		// Token: 0x0600048A RID: 1162
		static extern void \u200D\u202C\u202D\u206B\u202B\u202D\u200D\u206F\u200E\u206D\u200B\u206C\u200F\u200E\u202E\u200F\u206B\u202B\u200B\u200D\u202D\u200B\u206C\u206D\u202E\u200D\u200B\u202B\u206B\u206A\u202C\u202D\u202E\u206A\u202A\u200E\u206A\u206F\u202B\u206F\u202E(SiticoneTrackBar, Color);

		// Token: 0x0600048B RID: 1163
		static extern TrackBarState \u200F\u206E\u200C\u202A\u206B\u200F\u200D\u202C\u206F\u202C\u200D\u200F\u202C\u200D\u200C\u202C\u206B\u206B\u202A\u206A\u202A\u206E\u200F\u206F\u200F\u202A\u202E\u202B\u206B\u202A\u206D\u200E\u206C\u206D\u202D\u200D\u202C\u202B\u202E\u200F\u202E(SiticoneTrackBar);

		// Token: 0x0600048C RID: 1164
		static extern void \u206E\u206A\u206F\u206D\u206F\u206F\u200E\u200D\u200C\u202D\u200B\u200D\u206A\u200E\u206C\u202B\u200E\u206F\u202A\u206A\u202C\u206D\u202A\u200E\u200F\u206D\u200E\u200C\u206D\u206D\u206A\u202E\u202D\u200D\u206E\u202A\u202A\u206E\u206A\u206C\u202E(TrackBarState, TrackBar);

		// Token: 0x0600048D RID: 1165
		static extern void \u206A\u200B\u200F\u206B\u206E\u202C\u206E\u206B\u200C\u202D\u202C\u202D\u206F\u206C\u202D\u202C\u206C\u200B\u202C\u206F\u206A\u200E\u200B\u200B\u200E\u200F\u202A\u206B\u206D\u200F\u206B\u202D\u200C\u206D\u206E\u202B\u200F\u202D\u200C\u200C\u202E(SiticoneTrackBar, int);

		// Token: 0x0600048E RID: 1166
		static extern void \u206A\u202B\u200F\u200E\u206B\u202E\u200B\u200F\u200E\u202E\u200B\u206C\u202C\u202B\u202B\u200E\u206D\u202B\u206F\u200E\u202A\u200E\u200E\u206B\u206A\u206B\u202E\u200C\u206A\u200C\u206B\u202C\u206F\u206B\u206E\u200F\u200B\u202B\u200F\u206D\u202E(SiticoneTrackBar, int);

		// Token: 0x0600048F RID: 1167
		static extern void \u200F\u202A\u206E\u206B\u202B\u206B\u206B\u202B\u200C\u206F\u202E\u206C\u206C\u202E\u206D\u206F\u202C\u206A\u206D\u202A\u200F\u202B\u200C\u206E\u200C\u202D\u206F\u200D\u202A\u202E\u202D\u206E\u202C\u206A\u200E\u202E\u206D\u200B\u206D\u206B\u202E(SiticoneTrackBar, int);

		// Token: 0x06000490 RID: 1168
		static extern void \u200D\u202C\u206C\u200D\u200B\u202E\u200C\u202A\u206E\u200F\u206D\u202C\u206C\u206D\u200C\u202A\u200D\u202C\u206F\u202D\u206F\u200E\u206D\u202E\u202E\u202C\u206B\u206B\u200B\u202A\u206F\u206A\u200C\u206D\u206F\u206D\u200F\u206B\u202C\u200C\u202E(SiticoneTrackBar, int);

		// Token: 0x06000491 RID: 1169
		static extern void \u202B\u206E\u200D\u206F\u202E\u200C\u206C\u202D\u202A\u200E\u206A\u206D\u202A\u200F\u200B\u200C\u206D\u206A\u202C\u202D\u206F\u200C\u206C\u202C\u202B\u206C\u200E\u202E\u206A\u202E\u206D\u202E\u206E\u206B\u206D\u202E\u202A\u202C\u206C\u202D\u202E(SiticoneTrackBar, Color);

		// Token: 0x06000492 RID: 1170
		static extern void \u200B\u200D\u206E\u206C\u206C\u200F\u200C\u200E\u206D\u200C\u206D\u206D\u202C\u200E\u200B\u206B\u202E\u206E\u200C\u202C\u202B\u206E\u206F\u206D\u206B\u200F\u202E\u202D\u206E\u200D\u206E\u200D\u202B\u206D\u200F\u202D\u200F\u202E\u200D\u200F\u202E(TrackBar, ScrollEventHandler);

		// Token: 0x06000493 RID: 1171
		static extern Color \u206C\u200F\u202D\u200C\u200C\u206E\u202E\u200D\u206D\u206F\u200B\u200D\u202E\u200E\u206F\u202A\u206C\u202B\u206C\u200E\u202E\u202D\u202C\u206E\u200F\u202A\u202A\u206D\u202B\u202D\u202A\u200F\u206D\u206A\u202D\u200F\u206B\u202C\u202E\u206A\u202E();

		// Token: 0x06000494 RID: 1172 RVA: 0x000044CA File Offset: 0x000026CA
		static Cursor \u206E\u202B\u200F\u202C\u206F\u206B\u202B\u202C\u202A\u200F\u206A\u206A\u200D\u206B\u206D\u206B\u200B\u206D\u206A\u202E\u200F\u206B\u200F\u202C\u202C\u206C\u202E\u202D\u206D\u206D\u202B\u200D\u200E\u200B\u206C\u206F\u202E\u202B\u206F\u206C\u202E()
		{
			/*
An exception occurred when decompiling this method (06000494)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Windows.Forms.Cursor FPSMACROx.Form4::⁮‫‏‬⁯⁫‫‬‪‏⁪⁪‍⁫⁭⁫​⁭⁪‮‏⁫‏‬‬⁬‮‭⁭⁭‫‍‎​⁬⁯‮‫⁯⁬‮()

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000495 RID: 1173
		static extern void \u206B\u200D\u200F\u206D\u202E\u200D\u206F\u206C\u206C\u202A\u200B\u200C\u200B\u200C\u206A\u200B\u206F\u206E\u202E\u206F\u200F\u202D\u202C\u200B\u206D\u202E\u200D\u202E\u206C\u200F\u202C\u206B\u202C\u206E\u202E\u202D\u206C\u206F\u206F\u202A\u202E(Control, Cursor);

		// Token: 0x06000496 RID: 1174
		static extern void \u206F\u206C\u200D\u200C\u202A\u200E\u206E\u200C\u200C\u202C\u206D\u200E\u200C\u202E\u202A\u202B\u206E\u200F\u200E\u206D\u200C\u200F\u202A\u202D\u206E\u206F\u206C\u200E\u202D\u202B\u200D\u200E\u206A\u206F\u202B\u200B\u200F\u200B\u206D\u200E\u202E(TextBox, string);

		// Token: 0x06000497 RID: 1175
		static extern TextBoxState \u206A\u202C\u202D\u206B\u206E\u202D\u206E\u202D\u206D\u202C\u206E\u200E\u202A\u202A\u206C\u206C\u206E\u200F\u202B\u200D\u202E\u202B\u200D\u206B\u206B\u202A\u200E\u206E\u200E\u200F\u200B\u200B\u200C\u206B\u202E\u202E\u200E\u206C\u206F\u202D\u202E(SiticoneTextBox);

		// Token: 0x06000498 RID: 1176
		static extern void \u206B\u206D\u202C\u200B\u202B\u200C\u206D\u200E\u200B\u200F\u206E\u202A\u202C\u202E\u202B\u200C\u206C\u206E\u202A\u202B\u200D\u200E\u206B\u200C\u206B\u200B\u200F\u200D\u206D\u206A\u206C\u206A\u200C\u200F\u202E\u202B\u202D\u206D\u200D\u206A\u202E(TextBoxState, Color);

		// Token: 0x06000499 RID: 1177
		static extern void \u206A\u200B\u200E\u200D\u202A\u202C\u202D\u202C\u200E\u200D\u200B\u206A\u200F\u206D\u202B\u206F\u202A\u206A\u206D\u200F\u202C\u206B\u200C\u206C\u200B\u206A\u200B\u206B\u200E\u200C\u202E\u202D\u202A\u206B\u206C\u200E\u206D\u200C\u202E\u200F\u202E(TextBoxState, Color);

		// Token: 0x0600049A RID: 1178
		static extern void \u202D\u206B\u202D\u200E\u200D\u200D\u206A\u206E\u206D\u206F\u200B\u202D\u202A\u200F\u206A\u206C\u202A\u202A\u202D\u206A\u200E\u202E\u206C\u206C\u206C\u200F\u202E\u206C\u206F\u206C\u202B\u202D\u202A\u202A\u206C\u202C\u206D\u206B\u200B\u200C\u202E(TextBoxState, Color);

		// Token: 0x0600049B RID: 1179
		static extern void \u206E\u206C\u200F\u206E\u200F\u202C\u202A\u206C\u200E\u202A\u200B\u202E\u206B\u200F\u202E\u206F\u200C\u200E\u202C\u202B\u206A\u206C\u202A\u206F\u206A\u202E\u202B\u200D\u202B\u202C\u206B\u200D\u206F\u200D\u200B\u200B\u206F\u206D\u202B\u200F\u202E(TextBoxState, TextBox);

		// Token: 0x0600049C RID: 1180
		static extern void \u200F\u206D\u200D\u206F\u200D\u200F\u200B\u200C\u200E\u200E\u202E\u202C\u202A\u200B\u200F\u202A\u200E\u200E\u202E\u206D\u202E\u202C\u202D\u200F\u202A\u206C\u200C\u202B\u206F\u202A\u206E\u200B\u202B\u206A\u202A\u200B\u202D\u206B\u206C\u202C\u202E(TextBoxState, Color);

		// Token: 0x0600049D RID: 1181
		static extern TextBoxState \u200C\u200E\u200C\u202C\u202B\u200C\u202C\u202B\u206E\u206D\u202B\u206D\u206F\u200F\u202B\u206E\u200F\u200D\u206A\u202C\u202A\u200B\u200E\u206D\u200B\u200B\u206E\u206C\u202E\u206A\u202A\u206B\u202C\u206B\u202C\u202E\u206E\u206A\u200D\u206C\u202E(SiticoneTextBox);

		// Token: 0x0600049E RID: 1182
		static extern TextBoxState \u200E\u206B\u206C\u200E\u202C\u206A\u202A\u206B\u200D\u206A\u200D\u200E\u206F\u206A\u206D\u206A\u206B\u202D\u206B\u206D\u200D\u206A\u200C\u202C\u200E\u206E\u206E\u206E\u200D\u200F\u200D\u202C\u200C\u202B\u206A\u206D\u206F\u202D\u202A\u202C\u202E(SiticoneTextBox);

		// Token: 0x0600049F RID: 1183 RVA: 0x00007A90 File Offset: 0x00005C90
		static void \u202E\u206B\u200B\u200B\u206F\u200B\u202D\u200E\u206A\u206C\u200D\u206F\u206C\u200B\u206A\u206A\u206A\u206A\u200B\u202E\u206A\u202E\u200B\u206E\u200B\u202C\u202D\u206F\u200C\u206D\u200C\u200F\u200D\u206E\u202E\u200F\u202E\u206E\u202C\u202D\u202E(TextBox, char)
		{
			/*
An exception occurred when decompiling this method (0600049F)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::‮⁫​​⁯​‭‎⁪⁬‍⁯⁬​⁪⁪⁪⁪​‮⁪‮​⁮​‬‭⁯‌⁭‌‏‍⁮‮‏‮⁮‬‭‮(Siticone.UI.WinForms.Suite.TextBox,System.Char)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060004A0 RID: 1184
		static extern void \u200C\u206A\u206C\u202D\u202D\u206D\u206C\u206E\u202B\u200C\u202D\u202E\u206F\u206B\u200B\u202E\u200F\u200F\u200C\u200D\u206C\u200D\u202A\u200F\u202E\u200E\u202B\u206E\u200D\u202C\u202C\u202E\u202E\u202B\u200B\u202C\u206A\u200E\u202E\u200E\u202E(SiticoneTextBox, string);

		// Token: 0x060004A1 RID: 1185 RVA: 0x000044CD File Offset: 0x000026CD
		static void \u202D\u200C\u200C\u200C\u200E\u206B\u206E\u200E\u206C\u206C\u206A\u200C\u202D\u202A\u202D\u206E\u202B\u200D\u206E\u202E\u206E\u202D\u206D\u200D\u200E\u202C\u202B\u206D\u202B\u206D\u202C\u202E\u206F\u200E\u206C\u202B\u200E\u202E\u202D\u206D\u202E(TextBox, string)
		{
			/*
An exception occurred when decompiling this method (060004A1)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::‭‌‌‌‎⁫⁮‎⁬⁬⁪‌‭‪‭⁮‫‍⁮‮⁮‭⁭‍‎‬‫⁭‫⁭‬‮⁯‎⁬‫‎‮‭⁭‮(Siticone.UI.WinForms.Suite.TextBox,System.String)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	ldc.i4:int32(394245628); 	ldc.i4:int32(31); 	switch(, ldloc:TextBox(A_0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060004A2 RID: 1186 RVA: 0x000044DE File Offset: 0x000026DE
		static ShadowDecoration \u202E\u206F\u206B\u206E\u202C\u206E\u202C\u202D\u202B\u202B\u200E\u202C\u202C\u206F\u206B\u206D\u202D\u202B\u206B\u206E\u202E\u200D\u202A\u202E\u200B\u200F\u202B\u206F\u200F\u206F\u206C\u206E\u200F\u206D\u202A\u202A\u202B\u202A\u200C\u200D\u202E(SiticoneTextBox)
		{
			/*
An exception occurred when decompiling this method (060004A2)

ICSharpCode.Decompiler.DecompilerException: Error decompiling Siticone.UI.WinForms.Suite.ShadowDecoration FPSMACROx.Form4::‮⁯⁫⁮‬⁮‬‭‫‫‎‬‬⁯⁫⁭‭‫⁫⁮‮‍‪‮​‏‫⁯‏⁯⁬⁮‏⁭‪‪‫‪‌‍‮(Siticone.UI.WinForms.SiticoneTextBox)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060004A3 RID: 1187
		static extern void \u202E\u200D\u206B\u202E\u202E\u200E\u202A\u200B\u206C\u206B\u200B\u206B\u206E\u206C\u200D\u202B\u206F\u202B\u206D\u206D\u200C\u202A\u202A\u200E\u206A\u206C\u200E\u206A\u202B\u206B\u202C\u202A\u200C\u206B\u202A\u202E\u200E\u200C\u200C\u202E(TextBox, EventHandler);

		// Token: 0x060004A4 RID: 1188
		static extern void \u200D\u206D\u202D\u200E\u206E\u206F\u202B\u206C\u202D\u206D\u206F\u206C\u200C\u200B\u202D\u206F\u202E\u206B\u206A\u200F\u206F\u206F\u200F\u202E\u202C\u200C\u200E\u200D\u206F\u206F\u200D\u200D\u202A\u202D\u202B\u200D\u200F\u202A\u200F\u202A\u202E(Control, bool);

		// Token: 0x060004A5 RID: 1189
		static extern CustomCheckBoxState \u206C\u202C\u206E\u206A\u206E\u202D\u206E\u206E\u202D\u206B\u202A\u206C\u206A\u206B\u206D\u200C\u206C\u202A\u202C\u206B\u206E\u200D\u206F\u206B\u200C\u202C\u202A\u202C\u206D\u206F\u206A\u206D\u202A\u206B\u200B\u206B\u206C\u206C\u202D\u202A\u202E(SiticoneCustomCheckBox);

		// Token: 0x060004A6 RID: 1190 RVA: 0x00007AA4 File Offset: 0x00005CA4
		static void \u200E\u200B\u200B\u200C\u202E\u206C\u200B\u200D\u206C\u200D\u202E\u206C\u206F\u202E\u202E\u200C\u200E\u200F\u202B\u200E\u206B\u200E\u206C\u202D\u206F\u206F\u206E\u206E\u200D\u206D\u200B\u202B\u202E\u200D\u200D\u200F\u206E\u200C\u206F\u206A\u202E(CustomCheckBoxState A_0, Color A_1)
		{
			jmp();
		}

		// Token: 0x060004A7 RID: 1191
		static extern void \u202B\u200E\u200D\u206C\u200B\u200E\u202B\u206E\u200E\u206A\u200C\u200D\u200D\u206E\u200E\u206C\u202D\u202B\u202D\u202C\u200E\u202B\u200E\u202A\u200C\u202D\u200C\u206F\u200B\u206B\u206D\u202C\u206A\u200C\u200C\u206D\u206B\u206B\u206B\u202A\u202E(CustomCheckBoxState, int);

		// Token: 0x060004A8 RID: 1192 RVA: 0x00007AF4 File Offset: 0x00005CF4
		static void \u206D\u206E\u202E\u206E\u200F\u200B\u206F\u200B\u202B\u202A\u206E\u206F\u200B\u202D\u206F\u206C\u206D\u200F\u200E\u202B\u200C\u202B\u200E\u200B\u202D\u206B\u202A\u200B\u202B\u206C\u200C\u200D\u206E\u206A\u202B\u200E\u202D\u202A\u202D\u200E\u202E(CustomCheckBoxState, int)
		{
			/*
An exception occurred when decompiling this method (060004A8)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::⁭⁮‮⁮‏​⁯​‫‪⁮⁯​‭⁯⁬⁭‏‎‫‌‫‎​‭⁫‪​‫⁬‌‍⁮⁪‫‎‭‪‭‎‮(Siticone.UI.WinForms.Suite.CustomCheckBoxState,System.Int32)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060004A9 RID: 1193
		static extern void \u206F\u206A\u206B\u202A\u202B\u202D\u206E\u206F\u206B\u200C\u206E\u202E\u206F\u206E\u200E\u206D\u200D\u200F\u202B\u206C\u200D\u206E\u200B\u202E\u206B\u200E\u202E\u206B\u200F\u202B\u202D\u200E\u206A\u202B\u200E\u206E\u206A\u202E\u202E\u200E\u202E(CustomCheckBoxState, Color);

		// Token: 0x060004AA RID: 1194
		static extern void \u202C\u200D\u202E\u206A\u200D\u206E\u206B\u202B\u200D\u200F\u206C\u206D\u200E\u202D\u206F\u206C\u202B\u206F\u200B\u206F\u206A\u202E\u206D\u200D\u202B\u200D\u206F\u202A\u202A\u200C\u202D\u202E\u202E\u206D\u206B\u200B\u200D\u202D\u200F\u202D\u202E(CustomCheckBoxState, CustomCheckBox);

		// Token: 0x060004AB RID: 1195
		static extern ShadowDecoration \u206A\u200D\u200F\u206F\u202C\u202A\u202B\u200E\u202C\u206F\u200F\u206A\u202E\u200B\u200B\u206A\u202E\u206E\u200B\u200B\u202A\u206E\u206F\u202B\u200C\u200E\u206E\u202A\u206D\u200D\u200B\u206C\u202C\u202A\u200C\u200E\u200E\u202A\u206E\u206B\u202E(SiticoneCustomCheckBox);

		// Token: 0x060004AC RID: 1196 RVA: 0x00007B1C File Offset: 0x00005D1C
		static CustomCheckBoxState \u202D\u200F\u200C\u200D\u206F\u202B\u202A\u202C\u202A\u202A\u202E\u202D\u202C\u202A\u202E\u202B\u206A\u200F\u200F\u202D\u206E\u206B\u202E\u202D\u206B\u202D\u200B\u200F\u206E\u200F\u202A\u202A\u206A\u206C\u202A\u200E\u206D\u202E\u200B\u202B\u202E(SiticoneCustomCheckBox)
		{
			/*
An exception occurred when decompiling this method (060004AC)

ICSharpCode.Decompiler.DecompilerException: Error decompiling Siticone.UI.WinForms.Suite.CustomCheckBoxState FPSMACROx.Form4::‭‏‌‍⁯‫‪‬‪‪‮‭‬‪‮‫⁪‏‏‭⁮⁫‮‭⁫‭​‏⁮‏‪‪⁪⁬‪‎⁭‮​‫‮(Siticone.UI.WinForms.SiticoneCustomCheckBox)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060004AD RID: 1197
		static extern void \u200F\u206D\u200F\u206D\u200D\u206E\u206D\u202B\u202A\u200E\u202B\u206D\u202D\u200F\u202A\u200B\u202C\u206A\u200B\u200B\u202A\u202B\u202C\u206B\u200E\u200C\u206C\u200C\u200C\u202C\u202D\u200B\u206B\u202C\u202A\u202B\u206C\u206E\u202E\u206D\u202E(CustomCheckBox, EventHandler);

		// Token: 0x060004AE RID: 1198
		static extern void \u202C\u200F\u206C\u200F\u200C\u202D\u200F\u200D\u202A\u202E\u202D\u202D\u200F\u202D\u202B\u202D\u202E\u206F\u200B\u202E\u202A\u200E\u206C\u200D\u202D\u202B\u206F\u206B\u202A\u206D\u202E\u206A\u206B\u202C\u202C\u202E\u202A\u200C\u202E\u200C\u202E(PictureBox, Image);

		// Token: 0x060004AF RID: 1199 RVA: 0x000054C4 File Offset: 0x000036C4
		static void \u202C\u206B\u200F\u200B\u206F\u206E\u200C\u200D\u202D\u206B\u202D\u200C\u200F\u200E\u200D\u206C\u202C\u202D\u206C\u200B\u202E\u202A\u200E\u206B\u206A\u206E\u202C\u206B\u206A\u200F\u200F\u200C\u202A\u206A\u202D\u206C\u206D\u202D\u206E\u202B\u202E(PictureBox, PictureBoxSizeMode)
		{
			/*
An exception occurred when decompiling this method (060004AF)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::‬⁫‏​⁯⁮‌‍‭⁫‭‌‏‎‍⁬‬‭⁬​‮‪‎⁫⁪⁮‬⁫⁪‏‏‌‪⁪‭⁬⁭‭⁮‫‮(System.Windows.Forms.PictureBox,System.Windows.Forms.PictureBoxSizeMode)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060004B0 RID: 1200
		static extern void \u202E\u200F\u200C\u206E\u200D\u200E\u206A\u206C\u206C\u200B\u200F\u200B\u206F\u206F\u202C\u200F\u206A\u206C\u202A\u206D\u202E\u206E\u206E\u202A\u206E\u206D\u206C\u202A\u202B\u206A\u202B\u202C\u206D\u202C\u206D\u200E\u206B\u200B\u200C\u206D\u202E(PictureBox, int);

		// Token: 0x060004B1 RID: 1201 RVA: 0x00007B4C File Offset: 0x00005D4C
		static void \u206D\u200C\u206E\u206B\u200E\u200C\u206B\u202E\u200B\u202C\u200D\u202C\u202B\u200F\u202B\u206D\u202A\u200F\u200C\u206A\u206F\u200B\u200F\u206F\u202C\u206C\u206D\u200D\u206D\u202A\u206D\u200C\u200F\u206C\u206D\u206D\u202E\u206F\u206F\u206F\u202E(PictureBox, bool)
		{
			/*
An exception occurred when decompiling this method (060004B1)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::⁭‌⁮⁫‎‌⁫‮​‬‍‬‫‏‫⁭‪‏‌⁪⁯​‏⁯‬⁬⁭‍⁭‪⁭‌‏⁬⁭⁭‮⁯⁯⁯‮(System.Windows.Forms.PictureBox,System.Boolean)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060004B2 RID: 1202 RVA: 0x00007B84 File Offset: 0x00005D84
		static ImageControlState \u202E\u202A\u206C\u202B\u202B\u200E\u202E\u202E\u200E\u206D\u202A\u200C\u202A\u202D\u200D\u202B\u206C\u200F\u202B\u200F\u202E\u206A\u202E\u206A\u202A\u206E\u202C\u206B\u200E\u200C\u202B\u202D\u200C\u200D\u206B\u202E\u200F\u206E\u202A\u206E\u202E(SiticoneImageButton)
		{
			/*
An exception occurred when decompiling this method (060004B2)

ICSharpCode.Decompiler.DecompilerException: Error decompiling Siticone.UI.WinForms.Suite.ImageControlState FPSMACROx.Form4::‮‪⁬‫‫‎‮‮‎⁭‪‌‪‭‍‫⁬‏‫‏‮⁪‮⁪‪⁮‬⁫‎‌‫‭‌‍⁫‮‏⁮‪⁮‮(Siticone.UI.WinForms.SiticoneImageButton)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060004B3 RID: 1203
		static extern void \u206D\u206D\u200E\u202A\u206E\u202C\u206C\u202C\u202A\u206D\u206B\u200D\u200B\u200D\u206C\u200F\u206C\u200B\u200C\u202C\u206B\u202B\u200C\u206B\u200F\u200F\u206B\u206F\u206F\u206E\u202A\u206C\u206D\u200E\u200C\u202D\u200B\u202B\u200F\u206C\u202E(ImageControlState, Size);

		// Token: 0x060004B4 RID: 1204
		static extern void \u200C\u202B\u200D\u200F\u200E\u200C\u206C\u206A\u200B\u202E\u200F\u206D\u200E\u202D\u200B\u202A\u206D\u202E\u206A\u200F\u202D\u206F\u202C\u202E\u202B\u202D\u202E\u206A\u200E\u202D\u202E\u202C\u202B\u202D\u206A\u206C\u202C\u206F\u202C\u200C\u202E(ImageControlState, UIDefaultControl);

		// Token: 0x060004B5 RID: 1205 RVA: 0x00007BB0 File Offset: 0x00005DB0
		static ImageControlState \u202B\u200C\u200B\u202B\u206B\u200B\u202E\u202C\u200B\u206B\u200B\u206C\u202C\u200C\u202C\u206A\u206D\u200E\u206E\u206E\u202C\u206D\u206E\u206D\u206B\u200B\u202D\u206D\u202A\u200C\u200E\u206E\u202A\u202A\u200D\u206B\u202D\u206E\u202D\u206F\u202E(SiticoneImageButton)
		{
			/*
An exception occurred when decompiling this method (060004B5)

ICSharpCode.Decompiler.DecompilerException: Error decompiling Siticone.UI.WinForms.Suite.ImageControlState FPSMACROx.Form4::‫‌​‫⁫​‮‬​⁫​⁬‬‌‬⁪⁭‎⁮⁮‬⁭⁮⁭⁫​‭⁭‪‌‎⁮‪‪‍⁫‭⁮‭⁯‮(Siticone.UI.WinForms.SiticoneImageButton)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060004B6 RID: 1206
		static extern void \u206F\u202D\u200F\u206D\u206B\u200F\u206C\u202E\u202B\u206A\u200F\u202B\u200D\u200B\u202C\u202D\u206D\u206C\u206A\u206C\u200F\u200E\u206F\u200F\u202B\u202D\u202D\u206E\u206F\u200F\u206F\u200F\u202A\u202B\u206A\u206D\u200B\u206E\u200C\u206B\u202E(SiticoneImageButton, Image);

		// Token: 0x060004B7 RID: 1207 RVA: 0x00007BF0 File Offset: 0x00005DF0
		static void \u202B\u200F\u206E\u200D\u206E\u200F\u206A\u206C\u206A\u206B\u206B\u206D\u202D\u202D\u202C\u206F\u202B\u200F\u206C\u202D\u206F\u200C\u206E\u200F\u206F\u200E\u206C\u206D\u200F\u202C\u206D\u206E\u200D\u202C\u202D\u202C\u202B\u202C\u200E\u200F\u202E(SiticoneImageButton, Size)
		{
			/*
An exception occurred when decompiling this method (060004B7)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::‫‏⁮‍⁮‏⁪⁬⁪⁫⁫⁭‭‭‬⁯‫‏⁬‭⁯‌⁮‏⁯‎⁬⁭‏‬⁭⁮‍‬‭‬‫‬‎‏‮(Siticone.UI.WinForms.SiticoneImageButton,System.Drawing.Size)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060004B8 RID: 1208
		static extern ImageControlState \u206E\u206A\u206F\u206F\u206A\u202E\u206C\u200F\u202A\u202C\u206F\u200D\u202D\u206D\u206E\u200E\u200D\u200B\u200C\u206E\u206A\u200D\u206C\u200E\u200C\u206E\u206F\u200F\u206B\u200B\u202E\u206F\u206B\u206F\u200B\u202E\u206F\u206E\u202B\u202C\u202E(SiticoneImageButton);

		// Token: 0x060004B9 RID: 1209
		static extern void \u202B\u206F\u206F\u202D\u206E\u200D\u202E\u200E\u200F\u202A\u206D\u202E\u206F\u206D\u206C\u206D\u202A\u200C\u200E\u206E\u202D\u202A\u200F\u202C\u200D\u206C\u206B\u202A\u206E\u200C\u202A\u206A\u202E\u200F\u206F\u206B\u206B\u200F\u200D\u206A\u202E(Control, Color);

		// Token: 0x060004BA RID: 1210
		static extern ImageControlState \u200D\u206A\u200B\u200D\u200E\u202B\u202B\u202B\u200E\u206A\u206F\u206C\u206E\u202A\u202C\u206C\u202C\u206A\u200D\u202E\u200F\u200C\u206E\u202A\u202E\u200F\u206C\u206C\u206B\u206A\u200F\u202D\u202D\u206B\u200C\u202A\u202E\u200C\u206E\u206C\u202E(SiticoneImageCheckBox);

		// Token: 0x060004BB RID: 1211
		static extern ImageControlState \u200C\u202D\u206B\u202E\u206F\u206D\u206D\u206F\u202D\u200E\u202B\u200E\u200F\u206E\u206F\u202B\u206D\u206D\u206D\u202B\u202B\u200D\u202C\u206D\u206D\u206D\u200F\u200B\u202B\u202C\u206E\u206B\u202D\u206A\u202E\u206D\u202C\u202B\u200E\u202E(SiticoneImageCheckBox);

		// Token: 0x060004BC RID: 1212 RVA: 0x00007C28 File Offset: 0x00005E28
		static void \u200E\u202D\u200F\u206A\u206C\u202D\u200F\u202D\u202E\u206D\u200F\u202E\u200C\u200D\u200F\u206C\u200C\u206B\u206E\u206B\u202B\u200D\u206A\u206F\u202A\u206A\u202A\u206B\u206C\u202E\u206E\u200F\u206E\u202E\u206F\u206A\u202C\u200F\u200F\u202B\u202E(SiticoneImageCheckBox, Image)
		{
			/*
An exception occurred when decompiling this method (060004BC)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::‎‭‏⁪⁬‭‏‭‮⁭‏‮‌‍‏⁬‌⁫⁮⁫‫‍⁪⁯‪⁪‪⁫⁬‮⁮‏⁮‮⁯⁪‬‏‏‫‮(Siticone.UI.WinForms.SiticoneImageCheckBox,System.Drawing.Image)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060004BD RID: 1213 RVA: 0x00007C58 File Offset: 0x00005E58
		static void \u202A\u200F\u200B\u206E\u206C\u206F\u206D\u202B\u206D\u200F\u206E\u202B\u206B\u200E\u206C\u206B\u206F\u202A\u206A\u206B\u202A\u206C\u202D\u202D\u200D\u202C\u206B\u206B\u200E\u200F\u202E\u200B\u200D\u202E\u206F\u202B\u200C\u206A\u206B\u200C\u202E(SiticoneImageCheckBox, Size)
		{
			/*
An exception occurred when decompiling this method (060004BD)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4::‪‏​⁮⁬⁯⁭‫⁭‏⁮‫⁫‎⁬⁫⁯‪⁪⁫‪⁬‭‭‍‬⁫⁫‎‏‮​‍‮⁯‫‌⁪⁫‌‮(Siticone.UI.WinForms.SiticoneImageCheckBox,System.Drawing.Size)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060004BE RID: 1214
		static extern ImageControlState \u202C\u202A\u202A\u206E\u206F\u206E\u206E\u200B\u202E\u200B\u200B\u206D\u206A\u202A\u206F\u200B\u202A\u202A\u200F\u202D\u202A\u200E\u200D\u200E\u200E\u206C\u206D\u200E\u206E\u202B\u206F\u200C\u202A\u206C\u202B\u206C\u200F\u200D\u202E\u202E\u202E(SiticoneImageCheckBox);

		// Token: 0x060004BF RID: 1215
		static extern void \u206D\u206F\u206C\u202E\u206B\u200C\u206B\u206B\u200B\u200B\u206F\u200B\u206D\u206C\u202A\u206A\u202D\u206E\u206E\u202C\u202C\u202D\u200C\u202A\u206A\u200D\u202C\u206B\u200E\u202E\u206C\u200B\u206E\u206A\u202C\u206B\u200E\u200B\u200F\u206D\u202E(SiticoneImageCheckBox, bool);

		// Token: 0x060004C0 RID: 1216
		static extern void \u202D\u202E\u202E\u200B\u202B\u200E\u206F\u202E\u200C\u206D\u200C\u202C\u202C\u202A\u200E\u206B\u200C\u206A\u206B\u202D\u200D\u202A\u202D\u200F\u202D\u200D\u206E\u200D\u206D\u202A\u206F\u200F\u200F\u202E\u202B\u200E\u200E\u200B\u206B\u200F\u202E(SiticoneTrackBar, int);

		// Token: 0x060004C1 RID: 1217 RVA: 0x00007C7C File Offset: 0x00005E7C
		static void \u206E\u202C\u202E\u206E\u202B\u206B\u202A\u200E\u206E\u200D\u202A\u206F\u206F\u200C\u206A\u206F\u206F\u206E\u202C\u206F\u200E\u200C\u200C\u202E\u200D\u200B\u202E\u202B\u206A\u206B\u206F\u200B\u200E\u202B\u200B\u200D\u200B\u200B\u202A\u206D\u202E(Control A_0, bool A_1)
		{
		}

		// Token: 0x060004C2 RID: 1218
		static extern void \u206E\u200D\u200E\u200C\u200E\u202C\u206E\u200D\u200D\u206B\u200C\u200F\u202A\u202B\u206D\u200C\u202E\u206F\u206D\u202A\u200C\u206F\u206E\u206C\u200B\u200F\u202A\u200C\u200E\u200E\u202B\u200F\u200C\u200F\u202D\u206D\u206B\u202D\u200F\u200D\u202E(ContainerControl, SizeF);

		// Token: 0x060004C3 RID: 1219
		static extern void \u206A\u200D\u202E\u206E\u206C\u206A\u206C\u202B\u206C\u202D\u202E\u206F\u206F\u202A\u200C\u206D\u200B\u206D\u200B\u206C\u202B\u202D\u206F\u206B\u206A\u202E\u200D\u200B\u206E\u206D\u200F\u202B\u206F\u202E\u202E\u200C\u200C\u200E\u200B\u200F\u202E(ContainerControl, AutoScaleMode);

		// Token: 0x060004C4 RID: 1220
		static extern void \u200C\u206E\u200B\u206D\u206A\u206D\u200D\u202E\u206E\u200D\u202E\u206A\u206A\u202E\u206B\u206F\u200C\u200D\u202C\u206C\u206D\u202D\u200B\u202D\u202B\u206D\u206C\u206F\u202B\u200E\u200D\u202A\u200C\u206F\u200D\u200B\u206B\u202D\u202D\u206F\u202E(Form, Size);

		// Token: 0x060004C5 RID: 1221
		static extern Control.ControlCollection \u202C\u200B\u200B\u200E\u200F\u206A\u200D\u202E\u206B\u202A\u206A\u202D\u202D\u200F\u202C\u200D\u206F\u202A\u202B\u206D\u206A\u206F\u206D\u200D\u206D\u202B\u200B\u206F\u206D\u202B\u206D\u206D\u200C\u206C\u200B\u206F\u206D\u202D\u206D\u202E\u202E(Control);

		// Token: 0x060004C6 RID: 1222
		static extern void \u206D\u206C\u202C\u200C\u206A\u206A\u200F\u202A\u200E\u202C\u202E\u200C\u200E\u202D\u200F\u206A\u202B\u206C\u206E\u206F\u206E\u202B\u206A\u202C\u206B\u200D\u200D\u200B\u206C\u206E\u200C\u200E\u206D\u202C\u202E\u200B\u206D\u200E\u200B\u206C\u202E(Control.ControlCollection, Control);

		// Token: 0x060004C7 RID: 1223
		static extern void \u202D\u206C\u200D\u200B\u200F\u206B\u206C\u206E\u206C\u202C\u200F\u206A\u200B\u206E\u206A\u200E\u200B\u206B\u200C\u202B\u202C\u200D\u200E\u206C\u206D\u206F\u200D\u202A\u206E\u200D\u202B\u200E\u202C\u206F\u202B\u200E\u200E\u206B\u200F\u202C\u202E(Form, FormBorderStyle);

		// Token: 0x060004C8 RID: 1224
		static extern void \u206E\u200C\u206B\u200B\u202C\u202D\u200D\u200E\u206B\u200B\u202D\u202B\u202D\u200F\u206E\u202C\u206E\u202E\u200D\u206F\u202A\u200D\u200F\u206B\u206B\u202C\u202A\u200C\u200D\u200E\u206B\u206C\u206F\u200B\u200B\u206E\u202B\u206E\u202D\u206F\u202E(Form, Padding);

		// Token: 0x060004C9 RID: 1225
		static extern void \u200E\u206F\u202C\u202C\u202A\u202B\u200D\u206C\u200B\u206E\u200B\u202A\u202E\u200E\u200D\u206D\u200F\u202A\u202B\u202C\u206C\u202D\u200F\u202E\u200C\u206C\u206C\u202D\u202D\u206A\u202C\u206B\u206B\u200F\u200D\u202A\u206C\u206F\u206C\u200C\u202E(Control, string);

		// Token: 0x060004CA RID: 1226
		static extern void \u206C\u206C\u206F\u202C\u200F\u202B\u206D\u202E\u200F\u206F\u200C\u200F\u200C\u206F\u206F\u206C\u200E\u202C\u206F\u200D\u200D\u200F\u202A\u200B\u206F\u200B\u206A\u202C\u202D\u200C\u206A\u200F\u202A\u206B\u206E\u206F\u202B\u200C\u200B\u206F\u202E(Form, bool);

		// Token: 0x060004CB RID: 1227
		static extern void \u206C\u202B\u206D\u202C\u200E\u200F\u202D\u206F\u206B\u202D\u206C\u202B\u200F\u206D\u206C\u202C\u206E\u206B\u202D\u206B\u200C\u206D\u202A\u200E\u202E\u206B\u206A\u200D\u206D\u200C\u200E\u200C\u206E\u202D\u202D\u202D\u202A\u200F\u200F\u206A\u202E(Form, EventHandler);

		// Token: 0x060004CC RID: 1228
		static extern void \u206A\u200C\u200C\u200B\u202D\u206A\u202A\u200D\u206D\u200F\u206F\u202C\u200C\u200E\u202B\u202D\u200E\u202C\u202D\u200C\u200D\u200C\u202B\u206F\u206A\u206D\u200E\u202D\u202E\u202D\u202B\u202B\u206F\u206D\u206D\u202E\u202E\u202B\u206D\u206C\u202E(ISupportInitialize);

		// Token: 0x060004CD RID: 1229
		static extern void \u206E\u206D\u206B\u206C\u206C\u206B\u206E\u200D\u202D\u206E\u200D\u206C\u202C\u200B\u206B\u206F\u206F\u206B\u206D\u206A\u206A\u202D\u202C\u206D\u206D\u200F\u202A\u206A\u200E\u200F\u200B\u200C\u202E\u206A\u200E\u206D\u202C\u206C\u200B\u200C\u202E(Control, bool);

		// Token: 0x060004CE RID: 1230
		static extern void \u206D\u206A\u206B\u202E\u200D\u206F\u206B\u202D\u202C\u200E\u206F\u206A\u202A\u202E\u206D\u200D\u206D\u202A\u200B\u202D\u202E\u200E\u202D\u206A\u206A\u202A\u202D\u206D\u200F\u206C\u206B\u200F\u206B\u200F\u206B\u206B\u200E\u202E\u202A\u206C\u202E(Control);

		// Token: 0x04000146 RID: 326
		private static int bindok;

		// Token: 0x04000147 RID: 327
		private static int indok;

		// Token: 0x04000148 RID: 328
		private int fow;

		// Token: 0x04000149 RID: 329
		private static double sens;

		// Token: 0x0400014A RID: 330
		private static double smooth;

		// Token: 0x0400014B RID: 331
		private double sens_x;

		// Token: 0x0400014C RID: 332
		private double sens_y;

		// Token: 0x0400014D RID: 333
		private Thread işçibaşı;

		// Token: 0x0400014E RID: 334
		private AutoItX3 au3;

		// Token: 0x0400014F RID: 335
		private const int SRCCOPY = 13369376;

		// Token: 0x04000150 RID: 336
		private const int CAPTUREBLT = 1073741824;

		// Token: 0x04000151 RID: 337
		private int total;

		// Token: 0x04000152 RID: 338
		private int stx;

		// Token: 0x04000153 RID: 339
		private IContainer components;

		// Token: 0x04000154 RID: 340
		private SiticoneDragControl siticoneDragControl1;

		// Token: 0x04000155 RID: 341
		private SiticoneImageButton siticoneImageButton1;

		// Token: 0x04000156 RID: 342
		private SiticoneImageButton siticoneImageButton2;

		// Token: 0x04000157 RID: 343
		private Label label1;

		// Token: 0x04000158 RID: 344
		private SiticoneButton siticoneButton4;

		// Token: 0x04000159 RID: 345
		private SiticoneToggleSwitch siticoneToggleSwitch1;

		// Token: 0x0400015A RID: 346
		private PictureBox pictureBox1;

		// Token: 0x0400015B RID: 347
		private Label label3;

		// Token: 0x0400015C RID: 348
		private SiticoneImageCheckBox siticoneImageCheckBox1;

		// Token: 0x0400015D RID: 349
		private Label label2;

		// Token: 0x0400015E RID: 350
		private Label label4;

		// Token: 0x0400015F RID: 351
		private SiticoneMetroTrackBar siticoneMetroTrackBar1;

		// Token: 0x04000160 RID: 352
		private Label label34;

		// Token: 0x04000161 RID: 353
		private Label label5;

		// Token: 0x04000162 RID: 354
		private SiticoneTextBox siticoneTextBox2;

		// Token: 0x04000163 RID: 355
		private Label label6;

		// Token: 0x04000164 RID: 356
		private SiticoneMetroTrackBar siticoneMetroTrackBar3;

		// Token: 0x04000165 RID: 357
		private Guna2VSeparator guna2VSeparator1;

		// Token: 0x04000166 RID: 358
		private SiticoneButton siticoneButton1;

		// Token: 0x04000167 RID: 359
		private Label label9;

		// Token: 0x04000168 RID: 360
		private Label label10;

		// Token: 0x04000169 RID: 361
		private Label label11;

		// Token: 0x0400016A RID: 362
		private Label label12;

		// Token: 0x0400016B RID: 363
		private SiticoneToggleSwitch siticoneToggleSwitch3;

		// Token: 0x0400016C RID: 364
		private Label label13;

		// Token: 0x0400016D RID: 365
		private SiticoneButton siticoneButton2;

		// Token: 0x0400016E RID: 366
		private SiticoneCustomCheckBox siticoneCustomCheckBox1;

		// Token: 0x0400016F RID: 367
		private Label label14;

		// Token: 0x04000170 RID: 368
		private SiticoneToggleSwitch siticoneToggleSwitch4;

		// Token: 0x04000171 RID: 369
		private Label label15;

		// Token: 0x04000172 RID: 370
		private Label label16;

		// Token: 0x04000173 RID: 371
		private SiticoneDragControl siticoneDragControl2;

		// Token: 0x04000174 RID: 372
		private Label label17;

		// Token: 0x04000175 RID: 373
		private SiticoneCustomCheckBox siticoneCustomCheckBox2;

		// Token: 0x04000176 RID: 374
		private Label label18;

		// Token: 0x04000177 RID: 375
		private SiticoneCustomCheckBox siticoneCustomCheckBox3;

		// Token: 0x04000178 RID: 376
		private SiticoneMetroTrackBar siticoneMetroTrackBar2;

		// Token: 0x04000179 RID: 377
		private SiticoneTextBox siticoneTextBox1;

		// Token: 0x0400017A RID: 378
		private Label label7;

		// Token: 0x0400017B RID: 379
		private SiticoneTextBox siticoneTextBox3;

		// Token: 0x0400017C RID: 380
		private Label label8;

		// Token: 0x0400017D RID: 381
		private TextBox textBox4;

		// Token: 0x0400017E RID: 382
		private TextBox textBox3;

		// Token: 0x0400017F RID: 383
		private TextBox textBox2;

		// Token: 0x04000180 RID: 384
		private TextBox textBox1;

		// Token: 0x04000181 RID: 385
		private TextBox textBox5;

		// Token: 0x04000182 RID: 386
		private TextBox textBox6;

		// Token: 0x04000183 RID: 387
		private Label label19;

		// Token: 0x04000184 RID: 388
		private SiticoneCustomCheckBox siticoneCustomCheckBox4;

		// Token: 0x04000185 RID: 389
		private Label label20;

		// Token: 0x04000186 RID: 390
		private SiticoneCustomCheckBox siticoneCustomCheckBox5;

		// Token: 0x04000187 RID: 391
		private SiticoneButton siticoneButton3;

		// Token: 0x04000188 RID: 392
		private SiticoneButton siticoneButton7;

		// Token: 0x04000189 RID: 393
		private SiticoneButton siticoneButton6;

		// Token: 0x0400018A RID: 394
		private SiticoneButton siticoneButton5;

		// Token: 0x02000040 RID: 64
		public class INIKaydet
		{
			// Token: 0x060004CF RID: 1231
			[DllImport("kernel32")]
			private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

			// Token: 0x060004D0 RID: 1232
			[DllImport("kernel32")]
			private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

			// Token: 0x060004D1 RID: 1233 RVA: 0x00007CB0 File Offset: 0x00005EB0
			public INIKaydet(string dosyaYolu)
			{
				/*
An exception occurred when decompiling this method (060004D1)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form4/INIKaydet::.ctor(System.String)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
			}

			// Token: 0x17000080 RID: 128
			// (get) Token: 0x060004D2 RID: 1234
			// (set) Token: 0x060004D3 RID: 1235
			public extern string Varsayilan { [CompilerGenerated] get; [CompilerGenerated] set; }

			// Token: 0x060004D4 RID: 1236 RVA: 0x00007CD0 File Offset: 0x00005ED0
			public string Oku(string bolum, string ayaradi)
			{
				/*
An exception occurred when decompiling this method (060004D4)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.String FPSMACROx.Form4/INIKaydet::Oku(System.String,System.String)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
			}

			// Token: 0x060004D5 RID: 1237 RVA: 0x00007D00 File Offset: 0x00005F00
			public long Yaz(string bolum, string ayaradi, string deger)
			{
				/*
An exception occurred when decompiling this method (060004D5)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Int64 FPSMACROx.Form4/INIKaydet::Yaz(System.String,System.String,System.String)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
			}

			// Token: 0x060004D6 RID: 1238
			static extern StringBuilder \u202E\u206D\u202B\u202B\u200B\u200E\u200B\u206F\u206D\u202D\u206D\u202B\u200E\u200F\u200D\u202D\u200C\u202E\u200B\u206A\u202D\u202A\u206C\u200B\u206D\u200F\u206B\u200E\u200F\u206B\u206C\u202D\u200C\u200E\u200C\u202D\u202A\u200F\u206E\u202D\u202E(int);

			// Token: 0x060004D7 RID: 1239 RVA: 0x000055D4 File Offset: 0x000037D4
			static string \u202B\u206E\u200C\u202C\u206B\u202A\u202D\u200B\u200F\u202C\u200E\u200F\u200B\u206F\u202D\u206E\u200C\u202C\u206E\u202E\u206B\u206B\u206B\u200F\u206E\u206B\u200C\u206D\u200D\u200F\u202E\u202D\u200B\u200C\u200F\u200D\u200D\u206D\u200E\u202A\u202E(object)
			{
				/*
An exception occurred when decompiling this method (060004D7)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.String FPSMACROx.Form4/INIKaydet::‫⁮‌‬⁫‪‭​‏‬‎‏​⁯‭⁮‌‬⁮‮⁫⁫⁫‏⁮⁫‌⁭‍‏‮‭​‌‏‍‍⁭‎‪‮(System.Object)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
			}

			// Token: 0x0400018B RID: 395
			private string DOSYAYOLU;
		}
	}
}
