﻿using System;
using System.Numerics;

namespace Cryptographic
{
    /// <summary>
    /// Provides helper methods for working with <see cref="BigInteger"/> values.
    /// </summary>
    internal static class BigIntegerHelpers
    {
        /// <summary>
        /// Calculates the modulus of a <see cref="BigInteger"/> value.
        /// </summary>
        /// <param name="num">The numerator.</param>
        /// <param name="modulo">The modulo value.</param>
        /// <returns>The remainder after dividing <paramref name="num"/> by <paramref name="modulo"/>.</returns>
        /// <exception cref="ArgumentException">Thrown when <paramref name="modulo"/> is zero.</exception>
        public static BigInteger Mod(this BigInteger num, BigInteger modulo)
        {
            if (modulo == 0)
            {
                throw new ArgumentException("Modulo cannot be zero.", nameof(modulo));
            }

            BigInteger result = num % modulo;
            // Ensure the result is always non-negative
            return result < 0 ? result + modulo : result;
        }
    }
}