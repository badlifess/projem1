﻿namespace FPSMACROx
{
	// Token: 0x02000062 RID: 98
	public partial class Form7 : global::System.Windows.Forms.Form
	{
	}
}
