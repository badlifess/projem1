using System;
using System.Windows.Forms;
using System.Security.Principal;
using System.Diagnostics;
using System.Threading;
using System.IO;

namespace FPSMACROx
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            try
            {
                // Güvenlik kontrolleri
                if (!IsAdministrator())
                {
                    MessageBox.Show("Bu uygulama yönetici hakları gerektirir.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Anti-debug kontrolü
                if (IsDebuggerAttached())
                {
                    Environment.Exit(0);
                    return;
                }

                // Uygulama başlatma
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                
                // Güvenlik yöneticisini başlat
                SecurityManager.Instance.Initialize();
                
                // Ana formu başlat
                Application.Run(new Form1());
            }
            catch (Exception ex)
            {
                LogError(ex);
                MessageBox.Show("Uygulama başlatılırken bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static bool IsAdministrator()
        {
            using (WindowsIdentity identity = WindowsIdentity.GetCurrent())
            {
                WindowsPrincipal principal = new WindowsPrincipal(identity);
                return principal.IsInRole(WindowsBuiltInRole.Administrator);
            }
        }

        private static bool IsDebuggerAttached()
        {
            return Debugger.IsAttached;
        }

        private static void LogError(Exception ex)
        {
            try
            {
                string logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "error.log");
                File.AppendAllText(logPath, $"[{DateTime.Now}] {ex.Message}\n{ex.StackTrace}\n\n");
            }
            catch
            {
                // Log yazma hatası göz ardı edilir
            }
        }
    }
} 