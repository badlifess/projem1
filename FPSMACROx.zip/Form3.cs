﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using Siticone.UI.WinForms;
using Siticone.UI.WinForms.Enums;
using Siticone.UI.WinForms.Suite;

namespace FPSMACROx
{
	public partial class Form3 : Form
	{
		private readonly SecurityManager securityManager;
		private bool isRunning;
		private bool isHotkeyPressed;
		private bool isMinimized;
		
		// UI Components
		private SiticoneDragControl dragControl;
		private SiticoneImageButton imageButton1;
		private SiticoneImageButton imageButton2;
		private SiticoneButton button1;
		private Label label1;
		private Label label2;
		private SiticoneRadioButton radioButton1;
		private SiticoneRadioButton radioButton2;
		private SiticoneRadioButton radioButton3;
		private SiticoneToggleSwitch toggleSwitch1;
		private SiticoneSeparator separator1;
		private SiticoneTextBox textBox1;
		private PictureBox pictureBox1;
		private SiticoneMetroTrackBar trackBar1;
		private SiticoneImageRadioButton imageRadioButton1;
		private SiticoneCustomCheckBox customCheckBox1;

		public Form3()
		{
			InitializeComponent();
			InitializeSecurity();
			InitializeUI();
			InitializeEventHandlers();
		}

		private void InitializeSecurity()
		{
			securityManager = new SecurityManager();
			securityManager.CheckSecurity();
		}

		private void InitializeUI()
		{
			// Initialize and configure UI components
			InitializeDragControl();
			InitializeButtons();
			InitializeLabels();
			InitializeRadioButtons();
			InitializeToggleSwitch();
			InitializeSeparator();
			InitializeTextBox();
			InitializePictureBox();
			InitializeTrackBar();
			InitializeImageRadioButtons();
			InitializeCustomCheckBox();
			
			// Set form properties
			this.FormBorderStyle = FormBorderStyle.None;
			this.StartPosition = FormStartPosition.CenterScreen;
			this.Size = new Size(800, 600);
		}

		private void InitializeEventHandlers()
		{
			this.Load += Form3_Load;
			this.FormClosed += Form3_FormClosed;
			this.LocationChanged += Form3_LocationChanged;
			this.MouseUp += Form3_MouseUp;
			this.Shown += Form3_Shown;
		}

		private void Form3_Load(object sender, EventArgs e)
		{
			try
			{
				securityManager.CheckSecurity();
				InitializeSettings();
			}
			catch (Exception ex)
			{
				securityManager.LogError("Form3_Load", ex);
				MessageBox.Show("An error occurred while loading the form.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void Form3_FormClosed(object sender, FormClosedEventArgs e)
		{
			try
			{
				CleanupResources();
			}
			catch (Exception ex)
			{
				securityManager.LogError("Form3_FormClosed", ex);
			}
		}

		private void CleanupResources()
		{
			if (components != null)
			{
				components.Dispose();
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				CleanupResources();
			}
			base.Dispose(disposing);
		}

		// ... existing code ...
	}
}
