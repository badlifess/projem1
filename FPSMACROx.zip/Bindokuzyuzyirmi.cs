﻿using System;

namespace GameSettings
{
    /// <summary>
    /// Represents configuration settings and values for the game.
    /// </summary>
    internal class GameConfiguration
    {
        // General configuration values
        public static int FirstValue;
        public static int SecondValue;

        // Bounding Box coordinates
        public static int BoundingBoxX;
        public static int BoundingBoxY;
        public static int BoundingBoxWidth;
        public static int BoundingBoxHeight;

        // Keyboard Box coordinates
        public static int KeyboardBoxX;
        public static int KeyboardBoxY;
        public static int KeyboardBoxWidth;
        public static int KeyboardBoxHeight;

        // Additional settings
        public static int AdditionalSetting1;
        public static int AdditionalSetting2;

        // Screen coordinates
        public static int ScreenX;
        public static int ScreenY;
        public static int ScreenWidth;
        public static int ScreenHeight;

        // Color detection settings
        public static string DetectedColorName;
        public static int DetectedColorValue;

        // Object properties
        public static int ObjectPositionX;
        public static int ObjectPositionY;
        public static int ObjectWidth;
        public static int ObjectHeight;
        public static int ObjectColorValue;

        // Alternate object properties
        public static int AlternateColorValue;
        public static int AlternateObjectPositionX;
        public static int AlternateObjectPositionY;
        public static int AlternateObjectWidth;
        public static int AlternateObjectHeight;
    }
}