﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace AutoItX3Lib
{
    /// <summary>
    /// Represents the AutoItX3 COM interface, which provides automation capabilities through the AutoIt library.
    /// </summary>
    [TypeIdentifier] // Indicates that this is a type identifier generated for COM interop.
    [CompilerGenerated] // Specifies that this code was auto-generated, usually during compilation.
    [CoClass(typeof(object))] // Specifies the default implementation class for this COM interface.
    [Guid("3D54C6B8-D283-40E0-8FAB-C97F05947EE8")] // The unique identifier (GUID) for this COM interface.
    [ComImport] // Indicates that this interface is imported from a COM library.
    public interface AutoItX3 : IAutoItX3
    {
        // This interface inherits from IAutoItX3, which should contain the definitions for AutoIt methods.
        // No additional members are defined here because this interface is a COM wrapper for AutoIt functionality.
    }
}
