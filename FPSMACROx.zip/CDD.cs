﻿using System;

namespace SecurityChecks
{
    /// <summary>
    /// A class containing various anti-debugging and virtualization detection mechanisms.
    /// </summary>
    internal class DetectionResults
    {
        // Example String Properties
        public static string SampleStringProperty1;
        public static string SampleStringProperty2;

        // Anti-Debugging Checks
        public static bool GetForegroundWindowAntiDebugResult;
        public static bool DebuggerIsAttachedResult;
        public static bool HideThreadsAntiDebugResult;
        public static bool IsDebuggerPresentCheckResult;
        public static bool NtSetDebugFilterStateAntiDebugResult;
        public static bool PageGuardAntiDebugResult;
        public static bool NtQueryInformationProcessCheck_ProcessDebugFlagsResult;
        public static bool NtQueryInformationProcessCheck_ProcessDebugPortResult;
        public static bool NtQueryInformationProcessCheck_ProcessDebugObjectHandleResult;
        public static bool NtCloseAntiDebug_InvalidHandleResult;
        public static bool NtCloseAntiDebug_ProtectedHandleResult;
        public static bool ParentProcessAntiDebugResult;
        public static bool HardwareRegistersBreakpointsDetectionResult;
        public static bool FindWindowAntiDebugResult;
        public static bool OllyDbgFormatStringExploitResult;
        public static bool AntiDebugAttachResult;

        // Sandbox Detection
        public static bool AnyRunCheckResult;
        public static bool TriageCheckResult;
        public static bool CheckForQemuResult;
        public static bool CheckForParallelsResult;
        public static bool IsSandboxiePresentResult;
        public static bool IsComodoSandboxPresentResult;
        public static bool IsCuckooSandboxPresentResult;
        public static bool IsQihoo360SandboxPresentResult;
        public static bool IsEmulationPresentResult;
        public static bool CheckForBlacklistedNamesResult;
        public static bool IsWinePresentResult;

        // Virtualization Detection
        public static bool CheckForVMwareAndVirtualBoxResult;
        public static bool CheckForKVMResult;
        public static bool CheckForHyperVResult;
        public static bool BadVMFilesDetectionResult;
        public static bool BadVMProcessNamesResult;
        public static bool PortConnectionAntiVMResult;

        // Driver and Library Checks
        public static bool CheckDevicesResult;
        public static bool PatchLoadLibraryAResult;
        public static bool PatchLoadLibraryWResult;
        public static bool SetDllLoadPolicyResult;
        public static bool IsInjectedLibraryResult;
        public static bool IsUnsignedDriversAllowedResult;
        public static bool IsTestSignedDriversAllowedResult;

        // Security Features
        public static bool IsKernelDebuggingEnabledResult;
        public static bool IsSecureBootEnabledResult;
        public static bool IsVirtualizationBasedSecurityEnabledResult;
        public static bool IsMemoryIntegrityEnabledResult;

        // Hook and Assembly Detection
        public static bool IsInovkedAssemblyResult;
        public static bool DetectHooksOnCommonWinAPIFunctionsResult;
        public static bool DetectCLRHooksResult;
    }
}