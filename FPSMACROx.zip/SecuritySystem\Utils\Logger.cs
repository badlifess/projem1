using System;
using System.IO;

namespace SecuritySystem.Utils
{
    public static class Logger
    {
        private static readonly string LogPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "SecuritySystem",
            "logs.txt"
        );

        private const int MAX_LOG_SIZE = 1024 * 1024; // 1MB

        public static void Log(string message)
        {
            try
            {
                string logMessage = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {message}";
                
                Directory.CreateDirectory(Path.GetDirectoryName(LogPath));
                
                // Log dosyası boyut kontrolü
                if (File.Exists(LogPath))
                {
                    FileInfo fileInfo = new FileInfo(LogPath);
                    if (fileInfo.Length > MAX_LOG_SIZE)
                    {
                        File.Delete(LogPath);
                    }
                }

                File.AppendAllText(LogPath, logMessage + Environment.NewLine);
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        public static void Clear()
        {
            try
            {
                if (File.Exists(LogPath))
                {
                    File.Delete(LogPath);
                }
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }
    }
} 