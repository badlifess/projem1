﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Net;
using System.Resources;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using KeyAuth;
using Siticone.UI.WinForms;
using Siticone.UI.WinForms.Enums;
using Siticone.UI.WinForms.Suite;
using yapilarci;

namespace FPSMACROx
{
	// Token: 0x02000062 RID: 98
	public partial class Form7 : Form
	{
		// Token: 0x0600089E RID: 2206
		public extern Form7();

		// Token: 0x0600089F RID: 2207
		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern bool TerminateProcess(IntPtr hProcess, uint uExitCode);

		// Token: 0x060008A0 RID: 2208
		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern IntPtr GetCurrentProcess();

		// Token: 0x060008A1 RID: 2209
		[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
		private static extern ushort GlobalFindAtom(string lpString);

		// Token: 0x060008A2 RID: 2210
		private extern void Form7_Load(object sender, EventArgs e);

		// Token: 0x060008A3 RID: 2211
		public static extern bool SubExist(string name);

		// Token: 0x060008A4 RID: 2212
		public static extern string random_string();

		// Token: 0x060008A5 RID: 2213
		public static extern string expirydaysleft();

		// Token: 0x060008A6 RID: 2214
		public extern Task kontrolcu();

		// Token: 0x060008A7 RID: 2215
		private extern void siticoneButton1_Click(object sender, EventArgs e);

		// Token: 0x060008A8 RID: 2216
		public static extern void dıscı();

		// Token: 0x060008A9 RID: 2217
		private extern void siticoneImageButton1_Click(object sender, EventArgs e);

		// Token: 0x060008AA RID: 2218
		public static extern void formdansonraaq();

		// Token: 0x060008AB RID: 2219
		private extern void siticoneButton3_Click(object sender, EventArgs e);

		// Token: 0x060008AC RID: 2220
		private extern void issirası();

		// Token: 0x060008AD RID: 2221
		private extern void indirvekur();

		// Token: 0x060008AE RID: 2222
		private extern void indirvekur2();

		// Token: 0x060008AF RID: 2223
		private static extern void RunCommand(string command, string arguments = "");

		// Token: 0x060008B0 RID: 2224
		private static extern void RunCommand2(string command);

		// Token: 0x060008B1 RID: 2225
		private extern void siticoneImageButton4_Click(object sender, EventArgs e);

		// Token: 0x060008B2 RID: 2226 RVA: 0x000064DC File Offset: 0x000046DC
		private void güncelleToolStripMenuItem_Click(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060008B2)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::güncelleToolStripMenuItem_Click(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008B3 RID: 2227
		private extern void kayıtOlToolStripMenuItem_Click(object sender, EventArgs e);

		// Token: 0x060008B4 RID: 2228 RVA: 0x00004501 File Offset: 0x00002701
		private void güncelleToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060008B4)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::güncelleToolStripMenuItem1_Click(System.Object,System.EventArgs)

 ---> System.NullReferenceException: Object reference not set to an instance of an object.
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.IntroducePropertyAccessInstructions(ILExpression expr, ILExpression parentExpr, Int32 posInParent) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1589
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.IntroducePropertyAccessInstructions(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1579
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 244
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008B5 RID: 2229 RVA: 0x00008B14 File Offset: 0x00006D14
		private void girişYapToolStripMenuItem_Click(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060008B5)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::girişYapToolStripMenuItem_Click(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008B6 RID: 2230 RVA: 0x000064DC File Offset: 0x000046DC
		private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
		{
			/*
An exception occurred when decompiling this method (060008B6)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::menuStrip1_ItemClicked(System.Object,System.Windows.Forms.ToolStripItemClickedEventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008B7 RID: 2231 RVA: 0x000064DC File Offset: 0x000046DC
		private void panel1_Paint(object sender, PaintEventArgs e)
		{
			/*
An exception occurred when decompiling this method (060008B7)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::panel1_Paint(System.Object,System.Windows.Forms.PaintEventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008B8 RID: 2232
		private extern void siticoneButton7_Click(object sender, EventArgs e);

		// Token: 0x060008B9 RID: 2233 RVA: 0x0000451A File Offset: 0x0000271A
		private void siticoneImageButton3_Click(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060008B9)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::siticoneImageButton3_Click(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008BA RID: 2234
		private extern void siticoneControlBox1_Click(object sender, EventArgs e);

		// Token: 0x060008BB RID: 2235
		private extern void adresegit();

		// Token: 0x060008BC RID: 2236
		private extern void siticoneButton5_Click(object sender, EventArgs e);

		// Token: 0x060008BD RID: 2237
		private extern void keySatınAlToolStripMenuItem_Click(object sender, EventArgs e);

		// Token: 0x060008BE RID: 2238
		private extern void siticoneButton4_Click(object sender, EventArgs e);

		// Token: 0x060008BF RID: 2239
		private extern void kullanıcıaktifmi();

		// Token: 0x060008C0 RID: 2240 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneButton6_Click(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060008C0)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::siticoneButton6_Click(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008C1 RID: 2241
		private extern void hwidsıfırla();

		// Token: 0x060008C2 RID: 2242
		private extern void siticoneTextBox2_TextChanged(object sender, EventArgs e);

		// Token: 0x060008C3 RID: 2243 RVA: 0x000064DC File Offset: 0x000046DC
		private void panel2_Paint(object sender, PaintEventArgs e)
		{
			/*
An exception occurred when decompiling this method (060008C3)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::panel2_Paint(System.Object,System.Windows.Forms.PaintEventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008C4 RID: 2244 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneTextBox4_TextChanged(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060008C4)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::siticoneTextBox4_TextChanged(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008C5 RID: 2245 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneTextBox7_TextChanged(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060008C5)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::siticoneTextBox7_TextChanged(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008C6 RID: 2246
		private extern void siticoneTextBox3_TextChanged(object sender, EventArgs e);

		// Token: 0x060008C7 RID: 2247
		private extern void Form7_Shown(object sender, EventArgs e);

		// Token: 0x060008C8 RID: 2248
		private extern void siticoneRadioButton2_CheckedChanged(object sender, EventArgs e);

		// Token: 0x060008C9 RID: 2249
		private extern void siticoneRadioButton1_CheckedChanged(object sender, EventArgs e);

		// Token: 0x060008CA RID: 2250 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneCheckBox2_CheckedChanged(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060008CA)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::siticoneCheckBox2_CheckedChanged(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008CB RID: 2251
		private extern void siticoneLabel9_Click(object sender, EventArgs e);

		// Token: 0x060008CC RID: 2252 RVA: 0x000064DC File Offset: 0x000046DC
		private void siticoneButton8_Click(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (060008CC)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::siticoneButton8_Click(System.Object,System.EventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008CD RID: 2253
		protected override extern void Dispose(bool disposing);

		// Token: 0x060008CE RID: 2254
		private extern void InitializeComponent();

		// Token: 0x060008D1 RID: 2257
		static extern string \u202E\u200D\u200B\u200E\u202B\u202E\u202E\u200E\u206A\u202A\u200D\u200C\u200F\u200E\u202B\u206C\u202C\u206A\u200B\u202A\u200B\u200F\u206F\u200E\u206E\u202A\u206C\u200B\u202D\u202D\u202B\u202A\u206C\u202D\u202A\u206F\u202A\u206A\u206A\u202A\u202E();

		// Token: 0x060008D2 RID: 2258
		static extern string \u200C\u206A\u200B\u200F\u206B\u206F\u202C\u202B\u200E\u202E\u200C\u200E\u202C\u206A\u206E\u202A\u202A\u206E\u206A\u202B\u200E\u202D\u206B\u206F\u200B\u206A\u202B\u200B\u200E\u202C\u200D\u202B\u202E\u206E\u202C\u202A\u200C\u200D\u206D\u200C\u202E(string, string);

		// Token: 0x060008D3 RID: 2259 RVA: 0x00005A34 File Offset: 0x00003C34
		static Random \u200C\u206A\u202C\u206D\u206A\u202D\u206D\u202B\u206B\u202E\u200B\u206E\u206E\u206D\u200F\u206B\u206D\u206F\u206C\u206F\u200D\u206B\u200B\u200F\u202D\u200F\u206F\u202B\u202D\u202E\u200C\u206E\u202A\u206C\u202C\u206D\u200F\u206E\u200F\u202E()
		{
			/*
An exception occurred when decompiling this method (060008D3)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Random FPSMACROx.Form7::‌⁪‬⁭⁪‭⁭‫⁫‮​⁮⁮⁭‏⁫⁭⁯⁬⁯‍⁫​‏‭‏⁯‫‭‮‌⁮‪⁬‬⁭‏⁮‏‮()

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008D4 RID: 2260 RVA: 0x00008B54 File Offset: 0x00006D54
		static double \u202D\u206B\u206B\u206E\u202D\u202C\u206A\u202E\u200F\u206E\u206B\u206E\u200C\u202E\u206E\u200E\u206C\u200B\u206F\u206D\u202D\u200E\u200B\u206E\u202C\u206F\u202C\u200E\u200E\u202E\u206D\u206D\u200B\u202B\u200C\u200E\u200E\u206B\u202B\u202E\u202E(Random)
		{
			/*
An exception occurred when decompiling this method (060008D4)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Double FPSMACROx.Form7::‭⁫⁫⁮‭‬⁪‮‏⁮⁫⁮‌‮⁮‎⁬​⁯⁭‭‎​⁮‬⁯‬‎‎‮⁭⁭​‫‌‎‎⁫‫‮‮(System.Random)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008D5 RID: 2261 RVA: 0x00008B74 File Offset: 0x00006D74
		static double \u206B\u202A\u206A\u206C\u206C\u206A\u202A\u202A\u202C\u200C\u200F\u200F\u206C\u200D\u202B\u206D\u200F\u200F\u206D\u202E\u200B\u206C\u206B\u200D\u200B\u200C\u206D\u200E\u202A\u200E\u202C\u202E\u206B\u200D\u200B\u200D\u202B\u200D\u200D\u206B\u202E(double)
		{
			/*
An exception occurred when decompiling this method (060008D5)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Double FPSMACROx.Form7::⁫‪⁪⁬⁬⁪‪‪‬‌‏‏⁬‍‫⁭‏‏⁭‮​⁬⁫‍​‌⁭‎‪‎‬‮⁫‍​‍‫‍‍⁫‮(System.Double)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008D6 RID: 2262
		static extern int \u206E\u202D\u206E\u206C\u206B\u202E\u200E\u202E\u202D\u200C\u200B\u200F\u200C\u200C\u200E\u206C\u206E\u202C\u200B\u206C\u202E\u202E\u202D\u200E\u200D\u202D\u206A\u202E\u200F\u206E\u206E\u200C\u202C\u200F\u200E\u206F\u206F\u202D\u202C\u206E\u202E(double);

		// Token: 0x060008D7 RID: 2263 RVA: 0x00008B9C File Offset: 0x00006D9C
		static char \u206B\u202C\u200B\u200D\u202E\u202A\u206E\u206C\u200C\u202D\u202C\u206A\u206D\u202C\u206C\u206F\u202C\u200C\u200C\u200E\u206C\u206E\u200F\u206E\u200E\u202B\u200E\u200C\u200C\u202E\u202C\u202A\u206F\u206B\u202E\u202B\u202C\u206F\u206E\u200E\u202E(int)
		{
			/*
An exception occurred when decompiling this method (060008D7)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Char FPSMACROx.Form7::⁫‬​‍‮‪⁮⁬‌‭‬⁪⁭‬⁬⁯‬‌‌‎⁬⁮‏⁮‎‫‎‌‌‮‬‪⁯⁫‮‫‬⁯⁮‎‮(System.Int32)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008D8 RID: 2264
		static extern string \u202D\u200D\u206B\u200D\u200C\u200E\u200B\u206C\u206B\u202D\u206A\u206E\u202B\u200E\u200C\u200B\u200D\u206E\u200E\u206A\u202D\u206C\u206F\u202A\u202B\u206D\u206E\u202D\u202B\u206C\u206D\u202B\u200C\u202C\u202B\u200F\u202B\u202E\u206F\u202C\u202E(int);

		// Token: 0x060008D9 RID: 2265
		static extern string \u200C\u202D\u200C\u200F\u200D\u206E\u200E\u206B\u206B\u200E\u206D\u202C\u206F\u200B\u202E\u206B\u202E\u202A\u200D\u206E\u200C\u206F\u202E\u200E\u200F\u202D\u202A\u200B\u202D\u206B\u202E\u202C\u206C\u200B\u206B\u200E\u200B\u202B\u206A\u206E\u202E(TextBox);

		// Token: 0x060008DA RID: 2266 RVA: 0x000055D4 File Offset: 0x000037D4
		static string \u206B\u200F\u206F\u200C\u206F\u200F\u200D\u202A\u202C\u202D\u200E\u206F\u202A\u206C\u206C\u206C\u206D\u202C\u206C\u202A\u200F\u202C\u202C\u202C\u206A\u206F\u200F\u202B\u202C\u202D\u200C\u200C\u202D\u202A\u206A\u206B\u202E\u202E\u200D\u202A\u202E(object)
		{
			/*
An exception occurred when decompiling this method (060008DA)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.String FPSMACROx.Form7::⁫‏⁯‌⁯‏‍‪‬‭‎⁯‪⁬⁬⁬⁭‬⁬‪‏‬‬‬⁪⁯‏‫‬‭‌‌‭‪⁪⁫‮‮‍‪‮(System.Object)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008DB RID: 2267
		static extern DialogResult \u206A\u206B\u202B\u206A\u200B\u206E\u202E\u206A\u200D\u206F\u202D\u200E\u206F\u202B\u206D\u206F\u206C\u200F\u202A\u206B\u202E\u206A\u202B\u206B\u206D\u202D\u206F\u200E\u206C\u202A\u200D\u202C\u206F\u202D\u206B\u202E\u202D\u206D\u206F\u202A\u202E(string);

		// Token: 0x060008DC RID: 2268
		static extern Thread \u200F\u200B\u200C\u206B\u202C\u200F\u202E\u200D\u200F\u206D\u206F\u200D\u200F\u200D\u202A\u200F\u206F\u200C\u206E\u206C\u206D\u200E\u200D\u200F\u206E\u202A\u206A\u200B\u202E\u200E\u202A\u206D\u202B\u206E\u202C\u202A\u202E\u202E\u200B\u206F\u202E(ThreadStart);

		// Token: 0x060008DD RID: 2269 RVA: 0x00005AE4 File Offset: 0x00003CE4
		static void \u202A\u202B\u206D\u200D\u206E\u206F\u206F\u202B\u200D\u200F\u200E\u202B\u206C\u200F\u200C\u206E\u200E\u206F\u206D\u200D\u202C\u206C\u206A\u206E\u206F\u202A\u200F\u200F\u200E\u200C\u206D\u202E\u200D\u202D\u202B\u200F\u202D\u202C\u200C\u202E(Thread)
		{
			/*
An exception occurred when decompiling this method (060008DD)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::‪‫⁭‍⁮⁯⁯‫‍‏‎‫⁬‏‌⁮‎⁯⁭‍‬⁬⁪⁮⁯‪‏‏‎‌⁭‮‍‭‫‏‭‬‌‮(System.Threading.Thread)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008DE RID: 2270 RVA: 0x00008BD0 File Offset: 0x00006DD0
		static void \u202E\u200E\u200E\u200D\u200C\u202D\u200E\u202C\u200C\u206E\u200D\u202D\u202B\u206B\u202C\u206B\u206A\u206D\u200D\u206F\u206C\u202D\u200B\u206F\u200E\u200F\u206F\u202C\u206A\u202E\u206D\u206A\u206F\u206F\u200E\u202D\u206A\u206B\u206A\u206E\u202E(Thread)
		{
			/*
An exception occurred when decompiling this method (060008DE)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::‮‎‎‍‌‭‎‬‌⁮‍‭‫⁫‬⁫⁪⁭‍⁯⁬‭​⁯‎‏⁯‬⁪‮⁭⁪⁯⁯‎‭⁪⁫⁪⁮‮(System.Threading.Thread)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008DF RID: 2271
		static extern WebClient \u206B\u206A\u200B\u202A\u200C\u202D\u202B\u202E\u202A\u202C\u202E\u206D\u206D\u206C\u206F\u206D\u206C\u202C\u200D\u206B\u202B\u202E\u200B\u202E\u202B\u206E\u200D\u206A\u206D\u202B\u202B\u202B\u200E\u202C\u202B\u206A\u202A\u202E\u202B\u202E();

		// Token: 0x060008E0 RID: 2272
		static extern void \u202D\u206D\u202A\u200F\u202C\u206A\u202D\u206F\u200C\u202B\u200B\u200B\u202C\u202C\u202A\u206D\u206E\u206A\u206F\u206F\u206D\u200B\u202E\u200B\u206D\u206E\u206E\u200C\u200D\u200C\u200B\u200D\u202D\u206E\u206C\u206A\u202E\u202D\u200E\u206E\u202E(WebClient, string, string);

		// Token: 0x060008E1 RID: 2273
		static extern void \u202A\u200B\u206E\u200C\u206A\u202D\u200E\u202C\u202C\u202E\u202E\u200B\u206C\u202B\u206E\u200E\u206A\u206E\u202D\u206A\u202A\u206C\u200C\u206C\u206E\u200E\u206F\u200B\u200C\u202E\u200B\u202D\u200B\u202A\u202D\u206D\u206A\u200B\u206B\u206A\u202E(IDisposable);

		// Token: 0x060008E2 RID: 2274 RVA: 0x00005C98 File Offset: 0x00003E98
		static string \u200E\u202A\u200D\u200E\u202D\u200F\u202A\u200B\u202C\u202D\u206F\u206F\u206C\u206F\u206A\u206D\u206A\u202C\u200F\u200F\u206A\u206D\u206F\u206D\u202B\u200B\u202C\u202A\u202D\u206A\u202D\u206C\u206D\u200C\u206B\u206E\u206D\u206C\u200F\u202E(string, string)
		{
			/*
An exception occurred when decompiling this method (060008E2)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.String FPSMACROx.Form7::‎‪‍‎‭‏‪​‬‭⁯⁯⁬⁯⁪⁭⁪‬‏‏⁪⁭⁯⁭‫​‬‪‭⁪‭⁬⁭‌⁫⁮⁭⁬‏‮(System.String,System.String)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008E3 RID: 2275
		static extern void \u206C\u206C\u206A\u206A\u202A\u206B\u200B\u202E\u202E\u206A\u206A\u206E\u206B\u200E\u206F\u202B\u202D\u206C\u200D\u202D\u202A\u206B\u206B\u202A\u200B\u200B\u200D\u200C\u206E\u200B\u206B\u202A\u206C\u202B\u206B\u202D\u202C\u202A\u202C\u202A\u202E(string, string, bool);

		// Token: 0x060008E4 RID: 2276
		static extern bool \u200F\u202C\u200D\u202E\u206C\u200E\u202E\u202A\u200D\u200B\u202D\u206F\u202A\u206C\u206D\u202D\u202D\u200D\u202E\u206C\u202D\u202C\u206C\u200F\u200D\u200E\u202B\u202B\u200C\u206F\u202B\u206B\u202B\u202C\u202A\u206C\u200B\u200C\u202C\u206D\u202E(string);

		// Token: 0x060008E5 RID: 2277
		static extern void \u206A\u200D\u200C\u206A\u202D\u206B\u200F\u202B\u202E\u206B\u206F\u200C\u202A\u206E\u202B\u202D\u200E\u206F\u202B\u200F\u206D\u202D\u206B\u202D\u206E\u200B\u200E\u200E\u206F\u206A\u202D\u200F\u202A\u202D\u206E\u206D\u200E\u202B\u200E\u202B\u202E(string);

		// Token: 0x060008E6 RID: 2278
		static extern ProcessStartInfo \u206C\u206D\u206E\u206C\u202B\u206D\u202D\u206F\u200D\u202C\u200E\u202B\u206B\u206E\u202C\u206D\u200D\u200D\u206A\u206F\u200D\u206C\u202A\u206F\u202C\u202B\u202B\u202B\u202C\u200C\u202C\u202A\u206E\u200D\u200F\u202C\u206E\u200E\u200E\u202C\u202E();

		// Token: 0x060008E7 RID: 2279
		static extern void \u206C\u202C\u200E\u202C\u202D\u206C\u206D\u206B\u202A\u202D\u202D\u202C\u202C\u202B\u202C\u206D\u200C\u200B\u206F\u202E\u200D\u200C\u202E\u200C\u202B\u202A\u200F\u206B\u206F\u200E\u206B\u202A\u206D\u206A\u202D\u200B\u202A\u202A\u200F\u202C\u202E(ProcessStartInfo, string);

		// Token: 0x060008E8 RID: 2280 RVA: 0x00008C08 File Offset: 0x00006E08
		static void \u202A\u206A\u206C\u206C\u200F\u202A\u206E\u202E\u200F\u202E\u202D\u200D\u200E\u200D\u202E\u202A\u206B\u206A\u206B\u206C\u200B\u200B\u206C\u200F\u200E\u206B\u202E\u206F\u200C\u202C\u200E\u200C\u200D\u200F\u206C\u202A\u202E\u206F\u202D\u206B\u202E(ProcessStartInfo, string)
		{
			/*
An exception occurred when decompiling this method (060008E8)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::‪⁪⁬⁬‏‪⁮‮‏‮‭‍‎‍‮‪⁫⁪⁫⁬​​⁬‏‎⁫‮⁯‌‬‎‌‍‏⁬‪‮⁯‭⁫‮(System.Diagnostics.ProcessStartInfo,System.String)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008E9 RID: 2281 RVA: 0x00005CF0 File Offset: 0x00003EF0
		static Process \u206B\u206C\u200E\u200F\u200B\u200D\u202E\u200D\u202E\u206C\u206C\u202A\u200F\u206E\u206F\u200D\u200C\u202E\u202A\u206B\u200C\u206B\u206D\u200D\u206B\u202A\u202B\u200F\u200C\u202A\u202E\u206C\u202D\u200C\u202A\u200C\u206E\u202B\u200D\u206B\u202E(ProcessStartInfo)
		{
			/*
An exception occurred when decompiling this method (060008E9)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Diagnostics.Process FPSMACROx.Form7::⁫⁬‎‏​‍‮‍‮⁬⁬‪‏⁮⁯‍‌‮‪⁫‌⁫⁭‍⁫‪‫‏‌‪‮⁬‭‌‪‌⁮‫‍⁫‮(System.Diagnostics.ProcessStartInfo)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008EA RID: 2282
		static extern void \u200C\u202D\u202C\u202A\u206A\u202B\u206A\u206E\u202B\u200C\u200C\u206F\u202D\u206D\u200F\u200B\u202B\u200C\u200C\u200D\u202E\u202C\u202E\u206C\u200C\u206C\u200D\u202C\u202C\u202A\u202B\u202E\u206B\u202A\u200C\u202D\u202D\u206F\u202A\u200D\u202E(Process);

		// Token: 0x060008EB RID: 2283 RVA: 0x00006564 File Offset: 0x00004764
		static void \u200D\u202C\u202D\u200E\u202D\u200F\u206E\u202A\u206B\u206A\u200B\u202D\u202A\u202C\u206A\u206F\u206E\u202D\u202B\u206A\u206A\u200B\u200B\u202B\u206D\u202B\u206E\u206C\u206C\u206A\u206A\u206F\u206E\u206E\u206C\u200E\u206C\u206E\u206E\u202B\u202E(Control, string)
		{
			/*
An exception occurred when decompiling this method (060008EB)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::‍‬‭‎‭‏⁮‪⁫⁪​‭‪‬⁪⁯⁮‭‫⁪⁪​​‫⁭‫⁮⁬⁬⁪⁪⁯⁮⁮⁬‎⁬⁮⁮‫‮(System.Windows.Forms.Control,System.String)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008EC RID: 2284 RVA: 0x00007C7C File Offset: 0x00005E7C
		static void \u206A\u202D\u206B\u202C\u200D\u206B\u202E\u206C\u202B\u206F\u200B\u206F\u206D\u200E\u206F\u202C\u202B\u206F\u200B\u200B\u200E\u206B\u202B\u206C\u206D\u202B\u200E\u206A\u206A\u202B\u200B\u202D\u202B\u200D\u206D\u202C\u202B\u206D\u202B\u202E(Control A_0, bool A_1)
		{
		}

		// Token: 0x060008ED RID: 2285
		static extern bool \u206A\u206B\u206D\u200C\u206F\u202A\u206C\u206A\u206C\u202A\u200B\u206A\u206D\u202E\u200E\u206F\u202E\u202D\u202B\u206B\u206C\u206A\u200E\u200D\u206B\u202D\u200F\u202E\u200B\u200E\u202A\u206E\u206C\u206F\u202C\u200B\u202E\u200E\u200E\u206A\u202E(RadioButton);

		// Token: 0x060008EE RID: 2286
		static extern bool \u202B\u202B\u200E\u200F\u206D\u202E\u202A\u202B\u200D\u202C\u202E\u206F\u206C\u206C\u200E\u206B\u206E\u206B\u202C\u206C\u200F\u206C\u206A\u206B\u206F\u206C\u206E\u206C\u206E\u206E\u202A\u200F\u200E\u200C\u202C\u200D\u206B\u206F\u202D\u202D\u202E(string, string);

		// Token: 0x060008EF RID: 2287 RVA: 0x000059F8 File Offset: 0x00003BF8
		static Process \u206A\u200E\u200D\u200B\u202D\u206F\u202E\u206D\u200D\u206A\u206F\u206F\u206B\u206E\u206D\u202D\u206D\u200F\u206B\u202D\u202E\u202A\u200B\u202B\u206C\u202D\u206B\u200D\u206B\u200D\u200C\u206A\u202A\u200D\u200D\u202C\u202A\u206A\u202B\u200F\u202E(string)
		{
			/*
An exception occurred when decompiling this method (060008EF)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Diagnostics.Process FPSMACROx.Form7::⁪‎‍​‭⁯‮⁭‍⁪⁯⁯⁫⁮⁭‭⁭‏⁫‭‮‪​‫⁬‭⁫‍⁫‍‌⁪‪‍‍‬‪⁪‫‏‮(System.String)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008F0 RID: 2288 RVA: 0x00004680 File Offset: 0x00002880
		static void \u200D\u206D\u200C\u206E\u206E\u206B\u206C\u200E\u206D\u206C\u206B\u206B\u206B\u206C\u202A\u206A\u202C\u200B\u202A\u200B\u202A\u206E\u202C\u202C\u202D\u200C\u206F\u206A\u200E\u202E\u202B\u206C\u200C\u200F\u200F\u202A\u200E\u206A\u202B\u200E\u202E(int)
		{
			/*
An exception occurred when decompiling this method (060008F0)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::‍⁭‌⁮⁮⁫⁬‎⁭⁬⁫⁫⁫⁬‪⁪‬​‪​‪⁮‬‬‭‌⁯⁪‎‮‫⁬‌‏‏‪‎⁪‫‎‮(System.Int32)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008F1 RID: 2289
		static extern void \u202E\u200E\u206C\u202C\u202E\u206E\u202B\u200F\u200C\u206A\u202B\u202C\u200E\u202E\u202B\u202B\u200C\u200C\u200F\u206A\u202C\u202D\u206A\u206B\u206A\u200D\u206F\u200C\u206F\u200C\u202D\u206E\u202A\u200F\u200D\u200F\u200E\u206F\u206A\u200E\u202E(int);

		// Token: 0x060008F2 RID: 2290
		static extern void \u202E\u200C\u200D\u200D\u202B\u206D\u202A\u202D\u202B\u200B\u206F\u200E\u202B\u206F\u200E\u200E\u200B\u206A\u206A\u202B\u202A\u206E\u206B\u206E\u206A\u200B\u206E\u200B\u202E\u202C\u206D\u202C\u200B\u202E\u206A\u206E\u200F\u202E\u206D\u200C\u202E(ProcessStartInfo, bool);

		// Token: 0x060008F3 RID: 2291 RVA: 0x00005364 File Offset: 0x00003564
		static string \u200E\u200C\u200C\u206C\u206D\u206E\u202A\u200B\u200F\u200E\u206F\u202D\u202D\u202C\u202B\u202A\u202A\u206A\u202E\u206C\u202B\u200B\u206F\u202B\u206B\u206B\u206F\u202C\u202D\u200E\u200E\u200D\u206E\u202E\u202E\u202B\u202C\u202C\u206E\u206D\u202E(Exception)
		{
			/*
An exception occurred when decompiling this method (060008F3)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.String FPSMACROx.Form7::‎‌‌⁬⁭⁮‪​‏‎⁯‭‭‬‫‪‪⁪‮⁬‫​⁯‫⁫⁫⁯‬‭‎‎‍⁮‮‮‫‬‬⁮⁭‮(System.Exception)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008F4 RID: 2292 RVA: 0x000077BC File Offset: 0x000059BC
		static void \u202B\u202C\u200C\u206F\u202E\u200D\u206D\u206B\u202E\u200F\u206C\u200E\u206D\u200E\u200F\u200F\u200F\u202D\u206E\u202E\u202A\u200C\u206B\u202A\u202D\u202A\u206F\u200B\u200E\u206B\u206A\u200F\u200B\u200C\u202D\u202D\u200B\u200C\u202E\u202A\u202E(TextBox, string)
		{
			/*
An exception occurred when decompiling this method (060008F4)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::‫‬‌⁯‮‍⁭⁫‮‏⁬‎⁭‎‏‏‏‭⁮‮‪‌⁫‪‭‪⁯​‎⁫⁪‏​‌‭‭​‌‮‪‮(Siticone.UI.WinForms.Suite.TextBox,System.String)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008F5 RID: 2293 RVA: 0x000077EC File Offset: 0x000059EC
		static Container \u202A\u202D\u200E\u202D\u202E\u206E\u202C\u200C\u202A\u202A\u206A\u200C\u206F\u202B\u206A\u202A\u202E\u200D\u206B\u206D\u206A\u206A\u200F\u202A\u200E\u206A\u206E\u202A\u206F\u200E\u200D\u206C\u200F\u206F\u202B\u202D\u200D\u200D\u200E\u200D\u202E()
		{
			/*
An exception occurred when decompiling this method (060008F5)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.ComponentModel.Container FPSMACROx.Form7::‪‭‎‭‮⁮‬‌‪‪⁪‌⁯‫⁪‪‮‍⁫⁭⁪⁪‏‪‎⁪⁮‪⁯‎‍⁬‏⁯‫‭‍‍‎‍‮()

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008F6 RID: 2294 RVA: 0x0000441C File Offset: 0x0000261C
		static Type \u202B\u202B\u200F\u200B\u202C\u206B\u202B\u202A\u202A\u200E\u202D\u200F\u206E\u206C\u202A\u206D\u202D\u200B\u200F\u206F\u202B\u206F\u206E\u202E\u200F\u206D\u202D\u202E\u206E\u200B\u202B\u202E\u206B\u200F\u206C\u200E\u202B\u200F\u202C\u202B\u202E(RuntimeTypeHandle)
		{
			/*
An exception occurred when decompiling this method (060008F6)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Type FPSMACROx.Form7::‫‫‏​‬⁫‫‪‪‎‭‏⁮⁬‪⁭‭​‏⁯‫⁯⁮‮‏⁭‭‮⁮​‫‮⁫‏⁬‎‫‏‬‫‮(System.RuntimeTypeHandle)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008F7 RID: 2295
		static extern ComponentResourceManager \u202A\u206C\u206A\u202C\u202E\u206B\u202B\u206A\u202E\u206A\u206B\u202B\u202B\u200D\u202E\u202A\u206A\u202A\u202C\u206F\u202A\u202E\u200C\u202E\u200C\u202E\u202A\u206E\u206C\u202A\u200E\u200B\u200E\u202C\u200C\u206A\u200D\u206E\u202E\u202B\u202E(Type);

		// Token: 0x060008F8 RID: 2296 RVA: 0x00008C3C File Offset: 0x00006E3C
		static SiticoneLabel \u202B\u200C\u200F\u206E\u202C\u202C\u200E\u202D\u206A\u206D\u200C\u202D\u200B\u200F\u200C\u202E\u206C\u200C\u206E\u206A\u202B\u202D\u202A\u206C\u206B\u202B\u206A\u200C\u206B\u206B\u206D\u200E\u206F\u200D\u206B\u200E\u200D\u206D\u206E\u202D\u202E()
		{
			/*
An exception occurred when decompiling this method (060008F8)

ICSharpCode.Decompiler.DecompilerException: Error decompiling Siticone.UI.WinForms.SiticoneLabel FPSMACROx.Form7::‫‌‏⁮‬‬‎‭⁪⁭‌‭​‏‌‮⁬‌⁮⁪‫‭‪⁬⁫‫⁪‌⁫⁫⁭‎⁯‍⁫‎‍⁭⁮‭‮()

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060008F9 RID: 2297
		static extern SiticoneTextBox \u206D\u206E\u206C\u200F\u202B\u206D\u202D\u200B\u202D\u206B\u202E\u202E\u200F\u202A\u200F\u206D\u206A\u206D\u206E\u206E\u206C\u200B\u202A\u200E\u200D\u200F\u202D\u200C\u202D\u200F\u202A\u202B\u202B\u200E\u206E\u200C\u200D\u206D\u202A\u206E\u202E();

		// Token: 0x060008FA RID: 2298
		static extern SiticoneControlBox \u206A\u200C\u202B\u200C\u202B\u206F\u200E\u206A\u202A\u206C\u200E\u202E\u200E\u200B\u202B\u200F\u200C\u206D\u202C\u202C\u200F\u206A\u206B\u202C\u200E\u202A\u206E\u200B\u202A\u202B\u206D\u202D\u206A\u202E\u202E\u202C\u200F\u202B\u202C\u200F\u202E();

		// Token: 0x060008FB RID: 2299
		static extern Panel \u202C\u200E\u202B\u202D\u206A\u200D\u202A\u202A\u206F\u206D\u202A\u206D\u200E\u206B\u206D\u206A\u206E\u200D\u206C\u206B\u202E\u206E\u200E\u202A\u202C\u200D\u200D\u202C\u206D\u202D\u200D\u206D\u200D\u202C\u206F\u202B\u202D\u202A\u202E\u202B\u202E();

		// Token: 0x060008FC RID: 2300
		static extern SiticoneRadioButton \u200F\u206F\u206A\u200E\u202E\u206A\u202A\u200B\u200C\u206D\u200C\u200F\u202A\u202B\u200E\u200E\u200B\u202E\u202B\u200E\u202E\u200E\u206B\u200C\u206A\u200D\u200F\u206D\u200E\u206C\u202B\u202B\u202E\u206F\u202D\u206D\u206F\u206B\u206C\u202E();

		// Token: 0x060008FD RID: 2301
		static extern SiticoneButton \u206D\u200F\u200C\u202E\u206C\u200E\u202E\u200B\u202C\u200D\u206C\u202D\u202A\u202B\u206D\u206D\u206A\u206A\u206B\u206F\u206F\u202E\u200C\u202D\u206E\u206F\u206B\u202B\u206A\u202E\u202A\u200B\u202C\u202A\u206E\u206F\u202A\u206A\u202A\u206D\u202E();

		// Token: 0x060008FE RID: 2302
		static extern Label \u200B\u206B\u202C\u202C\u202B\u200B\u200C\u200B\u206E\u200D\u202E\u200F\u202A\u200D\u202E\u206C\u202A\u202A\u206A\u206D\u202C\u202D\u206B\u202A\u206D\u200E\u206B\u202C\u200F\u202E\u206A\u206D\u200C\u200B\u206E\u200C\u202B\u200F\u202A\u200E\u202E();

		// Token: 0x060008FF RID: 2303
		static extern SiticoneImageButton \u206D\u200F\u200F\u200B\u206C\u206B\u206F\u206C\u206E\u200C\u202C\u206A\u202E\u200B\u200F\u206B\u200F\u202B\u206A\u202C\u206A\u202B\u200C\u202C\u206E\u202E\u200F\u200E\u202B\u206C\u206B\u200D\u202E\u202C\u202C\u200F\u202E\u200C\u202A\u202B\u202E();

		// Token: 0x06000900 RID: 2304
		static extern SiticoneCheckBox \u202B\u202A\u200F\u202D\u200D\u202A\u202B\u200E\u206A\u200B\u200F\u206E\u202D\u206B\u206D\u200E\u202A\u200D\u206B\u202A\u206D\u206C\u200B\u200E\u200D\u202D\u200E\u206E\u200C\u202A\u202C\u206C\u202A\u200B\u206C\u200B\u206F\u206D\u206C\u202E\u202E();

		// Token: 0x06000901 RID: 2305
		static extern CheckBox \u206B\u202B\u200D\u202C\u206A\u200D\u200F\u206F\u202D\u206B\u206D\u206C\u200B\u200E\u202C\u202A\u206B\u200E\u202A\u206A\u202A\u202E\u202B\u200E\u200B\u206D\u202D\u200D\u200C\u202E\u206C\u200B\u202A\u200C\u206C\u202B\u200C\u200E\u200F\u206A\u202E();

		// Token: 0x06000902 RID: 2306
		static extern ToolStripMenuItem \u206F\u200F\u200F\u206C\u202E\u200F\u202A\u206B\u200D\u206F\u200F\u200F\u202D\u202C\u200B\u206F\u206C\u206C\u202C\u200E\u202C\u200E\u202D\u202E\u206C\u206B\u202C\u206D\u202A\u206A\u206D\u206B\u200D\u200F\u200C\u200D\u206F\u200F\u202D\u202C\u202E();

		// Token: 0x06000903 RID: 2307
		static extern MenuStrip \u200B\u200D\u202A\u202E\u206F\u202C\u206B\u200C\u200F\u206D\u206E\u206B\u200C\u206C\u206B\u206A\u202B\u206F\u200E\u200F\u200F\u202B\u200E\u206D\u206F\u200B\u200C\u202A\u202E\u200C\u200C\u206C\u206F\u202A\u200E\u202D\u200C\u206E\u200F\u202A\u202E();

		// Token: 0x06000904 RID: 2308
		static extern SiticoneDragControl \u202D\u202C\u200B\u206B\u202C\u200D\u200B\u206E\u206C\u206E\u200B\u202A\u202D\u206C\u202D\u206F\u202E\u202D\u206B\u206D\u202E\u206C\u202A\u202E\u200F\u200D\u200C\u206F\u202D\u202E\u206D\u200F\u200C\u200E\u202D\u202A\u206C\u200F\u200E\u202A\u202E(IContainer);

		// Token: 0x06000905 RID: 2309
		static extern void \u200E\u206C\u206E\u206A\u202B\u200D\u202B\u200C\u206A\u206F\u200D\u202C\u206B\u202D\u206E\u206A\u200C\u202A\u206C\u202D\u206C\u206A\u202D\u206A\u200B\u202B\u200D\u200C\u206D\u206E\u206A\u206F\u206E\u206D\u206D\u206D\u202C\u200D\u202C\u202E\u202E(Control);

		// Token: 0x06000906 RID: 2310 RVA: 0x00007878 File Offset: 0x00005A78
		static void \u202C\u206E\u206D\u200C\u202A\u206A\u200F\u202C\u206D\u206A\u202B\u200C\u202E\u200D\u200C\u200E\u206B\u206C\u202D\u200B\u206E\u200F\u202E\u200D\u206E\u200F\u202A\u200D\u202C\u200C\u206C\u200E\u200F\u200C\u202B\u200F\u206A\u202D\u200C\u206F\u202E(Control)
		{
			/*
An exception occurred when decompiling this method (06000906)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::‬⁮⁭‌‪⁪‏‬⁭⁪‫‌‮‍‌‎⁫⁬‭​⁮‏‮‍⁮‏‪‍‬‌⁬‎‏‌‫‏⁪‭‌⁯‮(System.Windows.Forms.Control)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000907 RID: 2311
		static extern void \u206B\u206F\u206F\u206A\u202C\u200D\u200F\u200F\u206F\u202C\u206C\u200E\u206F\u200D\u200B\u202D\u202D\u200E\u206D\u206E\u202A\u202D\u200C\u202E\u202C\u200B\u206B\u202C\u202E\u200B\u202E\u200C\u200D\u202E\u200E\u200F\u202B\u206D\u200E\u202A\u202E(Control, Color);

		// Token: 0x06000908 RID: 2312
		static extern Font \u206C\u206F\u200B\u206E\u206D\u200B\u202D\u200E\u202B\u206F\u200E\u202B\u200B\u202C\u202C\u206E\u206E\u200E\u202A\u206E\u202C\u202D\u200F\u206A\u206C\u206B\u202D\u206D\u200F\u202B\u200B\u206A\u202A\u206D\u206A\u202C\u206B\u200F\u206D\u200E\u202E(string, float);

		// Token: 0x06000909 RID: 2313
		static extern void \u200B\u202B\u202D\u206B\u200D\u200F\u202D\u206D\u200D\u202D\u206B\u202E\u206B\u206B\u202E\u202A\u202B\u206C\u202A\u202C\u202E\u202B\u202B\u206B\u200E\u202D\u206D\u206A\u202B\u206F\u200F\u206B\u206B\u206F\u200E\u200F\u202C\u200B\u202D\u206F\u202E(SiticoneLabel, Font);

		// Token: 0x0600090A RID: 2314
		static extern Color \u202B\u206E\u202E\u200E\u206E\u206C\u202D\u202B\u206A\u200F\u200F\u202B\u206B\u206F\u202E\u206D\u206F\u206D\u206D\u202E\u200F\u202D\u206B\u206E\u202B\u202B\u206F\u206A\u200B\u202E\u202D\u202E\u200E\u202D\u206A\u206C\u202C\u202D\u200B\u202D\u202E();

		// Token: 0x0600090B RID: 2315 RVA: 0x00008C7C File Offset: 0x00006E7C
		static void \u206E\u200E\u206D\u206F\u202A\u206A\u206B\u202E\u200C\u206B\u200D\u206D\u200C\u202E\u206C\u202E\u202A\u200F\u206C\u202A\u202E\u200B\u200D\u202E\u200E\u200F\u200D\u200D\u206F\u206B\u206E\u206A\u200B\u206D\u206E\u200C\u206E\u202A\u202A\u202A\u202E(SiticoneLabel, Color)
		{
			/*
An exception occurred when decompiling this method (0600090B)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::⁮‎⁭⁯‪⁪⁫‮‌⁫‍⁭‌‮⁬‮‪‏⁬‪‮​‍‮‎‏‍‍⁯⁫⁮⁪​⁭⁮‌⁮‪‪‪‮(Siticone.UI.WinForms.SiticoneLabel,System.Drawing.Color)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600090C RID: 2316 RVA: 0x0000659C File Offset: 0x0000479C
		static void \u206A\u202D\u206B\u200E\u200E\u202B\u206A\u206D\u200C\u200D\u206F\u202A\u202A\u200D\u206D\u200E\u206D\u206C\u206E\u206F\u206D\u206B\u200D\u200B\u202A\u206B\u202C\u202D\u206E\u200F\u206A\u200D\u200D\u202D\u200E\u206C\u200E\u200D\u206F\u202D\u202E(Control, Point)
		{
			/*
An exception occurred when decompiling this method (0600090C)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::⁪‭⁫‎‎‫⁪⁭‌‍⁯‪‪‍⁭‎⁭⁬⁮⁯⁭⁫‍​‪⁫‬‭⁮‏⁪‍‍‭‎⁬‎‍⁯‭‮(System.Windows.Forms.Control,System.Drawing.Point)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600090D RID: 2317
		static extern void \u200E\u206C\u206B\u206C\u202C\u202E\u206C\u202E\u200D\u206F\u206D\u206F\u200C\u202E\u206A\u200C\u200F\u206D\u206E\u206F\u202E\u202B\u206E\u206E\u200D\u200C\u200B\u206C\u206B\u202A\u206A\u202B\u200D\u206C\u202C\u206A\u202C\u200B\u200D\u202A\u202E(Control, string);

		// Token: 0x0600090E RID: 2318
		static extern void \u200B\u206B\u206E\u202B\u206D\u200F\u202A\u202A\u202A\u206F\u206E\u206B\u200F\u206D\u202E\u206C\u206B\u202A\u202C\u206C\u200B\u206E\u200B\u200D\u202E\u206F\u206D\u200B\u202B\u202E\u202A\u206C\u200C\u202A\u206C\u202B\u206F\u206D\u206F\u200F\u202E(Control, Size);

		// Token: 0x0600090F RID: 2319
		static extern void \u206C\u206C\u200D\u202A\u200B\u202A\u200F\u206A\u206D\u200B\u206B\u200D\u206E\u202B\u202B\u202C\u202C\u202E\u206E\u206A\u202A\u206A\u206D\u202D\u200F\u206E\u200F\u202D\u202E\u200E\u206D\u202C\u206C\u202C\u202C\u206E\u202E\u206E\u200F\u206E\u202E(Control, int);

		// Token: 0x06000910 RID: 2320 RVA: 0x00008CB8 File Offset: 0x00006EB8
		static void \u202A\u200E\u202E\u202A\u200C\u206E\u206B\u206B\u200B\u200F\u200E\u202E\u200E\u206F\u202A\u200C\u202B\u202E\u202A\u202C\u200C\u206A\u202C\u206E\u206A\u200E\u200C\u206C\u206F\u200B\u202A\u206C\u200D\u202D\u206D\u202E\u200B\u202B\u202A\u206F\u202E(Control, bool)
		{
			/*
An exception occurred when decompiling this method (06000910)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::‪‎‮‪‌⁮⁫⁫​‏‎‮‎⁯‪‌‫‮‪‬‌⁪‬⁮⁪‎‌⁬⁯​‪⁬‍‭⁭‮​‫‪⁯‮(System.Windows.Forms.Control,System.Boolean)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000911 RID: 2321
		static extern void \u206C\u202C\u200F\u206F\u206E\u202B\u200B\u200D\u206F\u200C\u200C\u202C\u202E\u200E\u206B\u202D\u206B\u206B\u206C\u200B\u202A\u202A\u202D\u200F\u206F\u200B\u200B\u202D\u206E\u202C\u202E\u206E\u200E\u200F\u202D\u202E\u206D\u202B\u200E\u200E\u202E(SiticoneTextBox, bool);

		// Token: 0x06000912 RID: 2322
		static extern void \u200D\u202B\u206E\u202C\u206E\u202A\u206A\u206A\u200B\u206C\u200C\u206A\u200C\u200D\u202C\u202E\u202B\u202E\u202E\u200F\u206C\u202A\u206B\u206C\u202D\u206A\u206F\u206E\u200B\u202A\u200C\u202E\u202A\u206A\u202E\u200C\u200C\u202B\u206C\u206E\u202E(SiticoneTextBox, Color);

		// Token: 0x06000913 RID: 2323 RVA: 0x000044CA File Offset: 0x000026CA
		static Cursor \u206B\u202E\u200D\u206A\u206F\u200B\u206F\u200E\u206A\u206A\u200F\u206C\u206F\u206A\u206D\u206E\u206D\u202B\u206E\u202A\u206E\u206D\u202D\u200C\u206F\u202B\u206F\u200D\u202D\u202C\u200F\u202E\u202A\u206E\u206D\u200C\u200C\u202C\u202D\u202E\u202E()
		{
			/*
An exception occurred when decompiling this method (06000913)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Windows.Forms.Cursor FPSMACROx.Form7::⁫‮‍⁪⁯​⁯‎⁪⁪‏⁬⁯⁪⁭⁮⁭‫⁮‪⁮⁭‭‌⁯‫⁯‍‭‬‏‮‪⁮⁭‌‌‬‭‮‮()

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000914 RID: 2324
		static extern void \u200D\u200E\u200E\u200C\u202A\u200C\u202D\u202A\u206A\u200E\u200B\u206A\u200F\u206D\u202E\u200C\u202E\u206B\u206E\u206F\u202C\u206F\u200D\u202A\u202B\u200E\u200E\u202D\u200C\u200D\u206C\u206F\u200B\u206C\u202A\u202A\u206D\u202C\u206C\u202C\u202E(Control, Cursor);

		// Token: 0x06000915 RID: 2325
		static extern void \u200D\u202C\u206B\u200C\u200C\u200E\u200D\u206A\u202B\u202E\u200F\u206A\u206F\u206E\u202B\u202B\u206C\u202C\u202B\u200F\u202C\u206E\u202C\u206A\u200B\u200F\u202A\u202A\u200B\u202B\u202C\u206D\u200E\u200F\u200E\u206E\u206D\u206B\u200F\u206A\u202E(TextBox, string);

		// Token: 0x06000916 RID: 2326
		static extern TextBoxState \u202A\u206C\u200D\u202A\u206C\u206D\u206A\u202E\u206A\u206D\u206C\u200B\u202D\u200C\u200F\u200F\u200E\u200D\u200F\u200F\u206A\u206A\u202B\u200C\u200F\u206C\u200D\u202E\u200B\u200F\u202B\u206F\u202E\u200E\u202A\u206B\u202D\u200C\u206D\u206E\u202E(SiticoneTextBox);

		// Token: 0x06000917 RID: 2327
		static extern void \u200E\u200C\u200F\u206A\u200C\u200C\u202B\u206D\u206D\u200F\u206F\u202D\u200C\u202E\u200B\u200B\u206C\u200F\u202C\u200D\u206F\u206F\u206A\u202D\u202E\u200F\u200D\u200F\u202A\u202E\u200C\u202D\u206A\u202E\u202B\u206B\u202C\u200E\u202D\u200E\u202E(TextBoxState, Color);

		// Token: 0x06000918 RID: 2328
		static extern void \u200C\u202C\u202C\u206E\u202E\u202D\u202E\u202A\u200E\u206A\u202A\u202E\u206E\u200D\u206D\u200B\u200D\u202E\u206E\u206D\u202A\u200F\u206A\u200F\u206F\u206C\u202D\u206F\u202C\u206C\u200B\u200B\u206A\u206C\u202A\u206D\u200E\u202D\u200E\u200F\u202E(TextBoxState, Color);

		// Token: 0x06000919 RID: 2329
		static extern void \u206C\u202A\u206D\u202A\u200C\u202B\u200F\u202D\u202C\u200E\u206D\u200C\u202B\u200B\u200B\u202B\u200C\u202A\u202A\u206D\u206A\u206E\u202A\u206A\u206D\u202C\u200B\u200D\u202E\u202D\u200E\u202C\u200E\u200D\u206D\u202D\u202B\u206F\u200C\u202C\u202E(TextBoxState, Color);

		// Token: 0x0600091A RID: 2330
		static extern void \u202D\u206A\u202A\u206B\u206D\u206C\u206E\u200E\u206E\u200E\u202C\u206A\u202D\u202A\u206C\u200C\u202A\u206A\u200C\u206B\u206F\u202A\u206B\u206E\u206E\u202E\u206D\u200D\u202C\u200C\u200E\u206D\u206A\u206C\u206E\u206A\u202D\u206F\u202D\u202C\u202E(TextBoxState, TextBox);

		// Token: 0x0600091B RID: 2331
		static extern void \u206D\u206F\u202C\u206B\u206B\u206B\u200C\u202D\u202D\u206F\u200D\u202A\u200F\u202C\u200D\u200C\u202E\u200D\u202E\u200B\u200F\u202A\u206B\u202B\u206E\u200B\u202E\u202C\u206B\u202D\u206B\u202E\u206E\u206F\u202D\u200E\u200D\u206A\u202E\u206A\u202E(TextBoxState, Color);

		// Token: 0x0600091C RID: 2332
		static extern void \u206D\u200C\u202E\u206A\u200C\u202C\u206F\u206B\u200E\u206F\u202C\u206A\u200C\u206F\u200B\u200B\u202B\u200C\u202E\u200E\u202A\u200C\u206F\u200C\u202D\u206A\u200E\u202B\u200B\u206F\u200D\u206F\u206F\u202C\u202C\u206D\u202C\u206B\u200D\u206A\u202E(SiticoneTextBox, Color);

		// Token: 0x0600091D RID: 2333
		static extern TextBoxState \u200B\u206A\u202A\u200F\u202A\u206A\u206B\u200E\u202B\u200B\u200E\u202B\u200B\u206B\u200E\u202A\u200F\u200D\u202E\u202C\u206D\u202C\u206D\u200B\u202A\u202D\u206C\u200F\u200C\u202C\u206E\u200E\u206C\u206C\u200C\u200C\u206B\u206E\u206C\u202C\u202E(SiticoneTextBox);

		// Token: 0x0600091E RID: 2334
		static extern TextBoxState \u202E\u202E\u200B\u202C\u202E\u202C\u202C\u202D\u206D\u200E\u206E\u202D\u200D\u200D\u200C\u202C\u202E\u202C\u200E\u206D\u206D\u206B\u206E\u202A\u206D\u200B\u200B\u202D\u202D\u202B\u200B\u202A\u206F\u202A\u202A\u206B\u206C\u206C\u200C\u206E\u202E(SiticoneTextBox);

		// Token: 0x0600091F RID: 2335
		static extern void \u202B\u200D\u202C\u202B\u206D\u206E\u200E\u206E\u202E\u202D\u206D\u200D\u206D\u200C\u200E\u202E\u206A\u206E\u206D\u206A\u206D\u206C\u202D\u206E\u206D\u200D\u206C\u202B\u200E\u202B\u206A\u206F\u206D\u202B\u200D\u206A\u200B\u202C\u206B\u202E(Control, Padding);

		// Token: 0x06000920 RID: 2336 RVA: 0x00007A90 File Offset: 0x00005C90
		static void \u202A\u200E\u200C\u206D\u206A\u200B\u206B\u200F\u202E\u202D\u202A\u202E\u200D\u206E\u202B\u200E\u200D\u200C\u202B\u202A\u200E\u206E\u206D\u202D\u200C\u202C\u202B\u200F\u202B\u200C\u206C\u202D\u202E\u206B\u202D\u202A\u206D\u206D\u206E\u206D\u202E(TextBox, char)
		{
			/*
An exception occurred when decompiling this method (06000920)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::‪‎‌⁭⁪​⁫‏‮‭‪‮‍⁮‫‎‍‌‫‪‎⁮⁭‭‌‬‫‏‫‌⁬‭‮⁫‭‪⁭⁭⁮⁭‮(Siticone.UI.WinForms.Suite.TextBox,System.Char)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000921 RID: 2337
		static extern void \u200B\u200D\u206F\u200E\u206A\u202B\u206C\u206B\u202A\u200D\u200B\u206C\u202B\u206B\u202E\u206B\u202C\u200C\u206F\u206E\u202B\u202A\u202B\u202A\u200B\u202E\u200F\u200D\u206B\u206E\u206F\u200D\u200B\u202B\u200B\u206A\u206B\u202A\u200C\u206C\u202E(SiticoneTextBox, string);

		// Token: 0x06000922 RID: 2338 RVA: 0x00008CD4 File Offset: 0x00006ED4
		static void \u206C\u202C\u206A\u206C\u200E\u202B\u206B\u206B\u202D\u200D\u206F\u206A\u206D\u202D\u202C\u206B\u200F\u206A\u202A\u206D\u202D\u206B\u206A\u202B\u202E\u206A\u206A\u206E\u206B\u200B\u202A\u202C\u206F\u206D\u200C\u202B\u200E\u202D\u200F\u202E(Control, RightToLeft)
		{
			/*
An exception occurred when decompiling this method (06000922)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::⁬‬⁪⁬‎‫⁫⁫‭‍⁯⁪⁭‭‬⁫‏⁪‪⁭‭⁫⁪‫‮⁪⁪⁮⁫​‪‬⁯⁭‌‫‎‭‏‮(System.Windows.Forms.Control,System.Windows.Forms.RightToLeft)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000923 RID: 2339 RVA: 0x000044CD File Offset: 0x000026CD
		static void \u206C\u200C\u202C\u206C\u202E\u202E\u206D\u206F\u206B\u200D\u202B\u200E\u202C\u202D\u200F\u202A\u200B\u206B\u202E\u206A\u200E\u202C\u202A\u206A\u206A\u202C\u202A\u200E\u206F\u206B\u200B\u200F\u206C\u206C\u200E\u206E\u202C\u206D\u202D\u202E\u202E(TextBox, string)
		{
			/*
An exception occurred when decompiling this method (06000923)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::⁬‌‬⁬‮‮⁭⁯⁫‍‫‎‬‭‏‪​⁫‮⁪‎‬‪⁪⁪‬‪‎⁯⁫​‏⁬⁬‎⁮‬⁭‭‮‮(Siticone.UI.WinForms.Suite.TextBox,System.String)

 ---> System.Exception: Basic block has to end with unconditional control flow. 
{; 	Block_0:; 	ldc.i4:int32(394245628); 	ldc.i4:int32(31); 	switch(, ldloc:TextBox(A_0)); }; 
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.FlattenBasicBlocks(ILNode node) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 1789
   at ICSharpCode.Decompiler.ILAst.ILAstOptimizer.Optimize(DecompilerContext context, ILBlock method, AutoPropertyProvider autoPropertyProvider, StateMachineKind& stateMachineKind, MethodDef& inlinedMethod, AsyncMethodDebugInfo& asyncInfo, ILAstOptimizationStep abortBeforeStep) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstOptimizer.cs:line 338
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 123
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000924 RID: 2340 RVA: 0x000044DE File Offset: 0x000026DE
		static ShadowDecoration \u206E\u206D\u200E\u206D\u200F\u200E\u202C\u206F\u200E\u206F\u200C\u202C\u206F\u200D\u206E\u206B\u202D\u206E\u202D\u206E\u206A\u206E\u200B\u202B\u200E\u200F\u200B\u206F\u202B\u202E\u200C\u206B\u202E\u206C\u200E\u200C\u200E\u202A\u200E\u200C\u202E(SiticoneTextBox)
		{
			/*
An exception occurred when decompiling this method (06000924)

ICSharpCode.Decompiler.DecompilerException: Error decompiling Siticone.UI.WinForms.Suite.ShadowDecoration FPSMACROx.Form7::⁮⁭‎⁭‏‎‬⁯‎⁯‌‬⁯‍⁮⁫‭⁮‭⁮⁪⁮​‫‎‏​⁯‫‮‌⁫‮⁬‎‌‎‪‎‌‮(Siticone.UI.WinForms.SiticoneTextBox)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000925 RID: 2341
		static extern void \u202D\u200E\u202B\u206C\u206E\u202C\u200F\u202D\u202C\u202D\u202B\u202B\u202C\u206C\u202E\u202B\u202C\u206B\u206B\u200F\u202D\u202D\u206C\u200B\u202E\u202D\u200B\u200D\u202C\u206E\u206C\u200E\u200B\u206E\u200C\u206A\u202B\u206F\u202C\u202A\u202E(ShadowDecoration, Control);

		// Token: 0x06000926 RID: 2342
		static extern void \u200B\u206A\u200B\u200B\u206A\u202B\u206F\u206C\u200D\u200D\u206C\u200D\u206E\u202A\u200C\u202B\u206B\u200D\u202D\u200E\u202D\u202B\u206C\u200F\u206C\u200E\u200D\u206D\u200D\u206B\u200D\u206F\u200E\u200E\u206C\u200C\u206D\u200C\u202B\u206D\u202E(TextBox, bool);

		// Token: 0x06000927 RID: 2343 RVA: 0x00008824 File Offset: 0x00006A24
		static void \u206A\u202D\u206F\u206B\u200B\u200D\u202B\u200F\u202D\u200B\u202B\u200E\u200C\u206E\u202A\u206E\u202C\u200E\u200C\u200C\u200B\u206A\u202C\u200B\u200E\u200F\u202B\u202D\u202E\u202A\u202E\u202A\u202B\u202D\u206B\u206B\u200D\u206D\u202D\u202E\u202E(Control, AnchorStyles)
		{
			/*
An exception occurred when decompiling this method (06000927)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::⁪‭⁯⁫​‍‫‏‭​‫‎‌⁮‪⁮‬‎‌‌​⁪‬​‎‏‫‭‮‪‮‪‫‭⁫⁫‍⁭‭‮‮(System.Windows.Forms.Control,System.Windows.Forms.AnchorStyles)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000928 RID: 2344
		static extern void \u200C\u206C\u202E\u200D\u200D\u202B\u206E\u202E\u202C\u200D\u200C\u206C\u200E\u202E\u200E\u200F\u202B\u206E\u206A\u206C\u200C\u202A\u206B\u206F\u202C\u206D\u202E\u202A\u200E\u206B\u200D\u202A\u202C\u206F\u206D\u202A\u202D\u206C\u206A\u202B\u202E(SiticoneControlBox, int);

		// Token: 0x06000929 RID: 2345
		static extern void \u206C\u200C\u206D\u202D\u200D\u206E\u200C\u202D\u202E\u206A\u200B\u206E\u202C\u202D\u206C\u202C\u202C\u200E\u200B\u200B\u206E\u202E\u202E\u206F\u200F\u206C\u206F\u200C\u206B\u200E\u200E\u206B\u200B\u202B\u206C\u206D\u206D\u202E\u202D\u202A\u202E(SiticoneControlBox, ControlBoxType);

		// Token: 0x0600092A RID: 2346
		static extern void \u200C\u202C\u200C\u206F\u200F\u200F\u206F\u206F\u206B\u206A\u202E\u202D\u200D\u202B\u202C\u200F\u200F\u202B\u202C\u206A\u200D\u202D\u202E\u200F\u202A\u206C\u202B\u202B\u200B\u200F\u202E\u200C\u202D\u200C\u206F\u200F\u206C\u206D\u202B\u206C\u202E(SiticoneControlBox, float);

		// Token: 0x0600092B RID: 2347
		static extern void \u202A\u206C\u206F\u202E\u206A\u206B\u200F\u206B\u206A\u200E\u200F\u206F\u206E\u202C\u202A\u206E\u200B\u206F\u206E\u202A\u206B\u206D\u202E\u206D\u202E\u202B\u200C\u200C\u200F\u206E\u202A\u206B\u202E\u200F\u202C\u206B\u200C\u206A\u206A\u202C\u202E(SiticoneControlBox, Color);

		// Token: 0x0600092C RID: 2348 RVA: 0x0000888C File Offset: 0x00006A8C
		static ControlBoxState \u206E\u200D\u206B\u206A\u202D\u200C\u206D\u200D\u202D\u200F\u200D\u206C\u202A\u200F\u206A\u200F\u202B\u206C\u206B\u200E\u206C\u200E\u206E\u202A\u200B\u206F\u200B\u206A\u206F\u202E\u202C\u202D\u206C\u200F\u202A\u206A\u206B\u200F\u206B\u206C\u202E(SiticoneControlBox)
		{
			/*
An exception occurred when decompiling this method (0600092C)

ICSharpCode.Decompiler.DecompilerException: Error decompiling Siticone.UI.WinForms.Suite.ControlBoxState FPSMACROx.Form7::⁮‍⁫⁪‭‌⁭‍‭‏‍⁬‪‏⁪‏‫⁬⁫‎⁬‎⁮‪​⁯​⁪⁯‮‬‭⁬‏‪⁪⁫‏⁫⁬‮(Siticone.UI.WinForms.SiticoneControlBox)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600092D RID: 2349
		static extern void \u200F\u202C\u206B\u200C\u206C\u202A\u202E\u206C\u200B\u202A\u200B\u206E\u200C\u200C\u200F\u206A\u202A\u200C\u200E\u200E\u206C\u200B\u206C\u202B\u206F\u200D\u206E\u200C\u202B\u206A\u202B\u200B\u206C\u202A\u206D\u200D\u202A\u206B\u206B\u200C\u202E(ControlBoxState, Color);

		// Token: 0x0600092E RID: 2350
		static extern void \u202C\u200D\u206C\u206A\u200B\u202A\u206B\u200B\u206A\u206D\u202A\u200B\u200D\u200E\u202C\u200D\u206A\u206A\u200E\u202C\u202D\u200D\u202D\u206A\u200B\u202C\u202A\u200E\u200B\u206E\u202D\u202A\u206A\u200C\u206F\u200B\u200F\u206B\u202E\u202E\u202E(ControlBoxState, ControlBox);

		// Token: 0x0600092F RID: 2351
		static extern void \u202B\u202B\u206D\u206F\u200E\u202A\u202C\u206A\u200F\u200D\u206F\u202E\u206C\u206A\u200C\u206E\u200E\u200B\u200D\u202B\u206C\u206A\u202B\u200F\u202B\u206E\u206F\u200F\u206F\u200E\u200D\u200C\u206B\u206E\u200E\u206D\u200F\u202B\u200B\u200E\u202E(SiticoneControlBox, Color);

		// Token: 0x06000930 RID: 2352
		static extern void \u202C\u206E\u206F\u202E\u202C\u200B\u206D\u202D\u200D\u200C\u202B\u200B\u200C\u202E\u206C\u202A\u202D\u202B\u202D\u202C\u206D\u200B\u202A\u206A\u206C\u206A\u202D\u200C\u206F\u206F\u206F\u200D\u202E\u202E\u202C\u206C\u200D\u202C\u200E\u202B\u202E(SiticoneControlBox, Color);

		// Token: 0x06000931 RID: 2353
		static extern ShadowDecoration \u200D\u206C\u202C\u200B\u202E\u202B\u200E\u202E\u202E\u202C\u200C\u206E\u200B\u202B\u206D\u206E\u206F\u202E\u202C\u206C\u202A\u206D\u206F\u200D\u206B\u200C\u200C\u202A\u200B\u200F\u206C\u200D\u206D\u200C\u206A\u200E\u206C\u200B\u206E\u202A\u202E(SiticoneControlBox);

		// Token: 0x06000932 RID: 2354
		static extern void \u202A\u200B\u202B\u200D\u200D\u202E\u206A\u206E\u200E\u206B\u200F\u202E\u200F\u200E\u202E\u206E\u200B\u202C\u206D\u200D\u206F\u202B\u200C\u202B\u200F\u200E\u206F\u206F\u202D\u202C\u206C\u202B\u206A\u206A\u200B\u206E\u200D\u206C\u206C\u202E\u202E(ControlBoxState, Color);

		// Token: 0x06000933 RID: 2355
		static extern void \u206B\u202E\u202E\u202E\u200D\u206B\u202D\u206E\u206D\u200B\u206C\u200B\u200D\u200F\u200F\u206B\u202C\u202B\u202A\u202B\u206B\u200F\u206E\u200D\u200E\u206A\u202E\u206D\u206D\u206B\u200F\u206A\u202A\u200B\u206D\u200D\u206B\u206A\u202E\u202E(Control, EventHandler);

		// Token: 0x06000934 RID: 2356 RVA: 0x00008CE4 File Offset: 0x00006EE4
		static Control.ControlCollection \u202B\u202B\u200D\u202E\u202D\u200C\u206B\u202D\u200F\u200E\u206E\u200C\u200B\u206E\u202A\u206E\u200F\u206D\u206B\u202D\u202E\u206F\u206C\u206F\u202D\u202E\u200D\u200C\u202D\u200E\u200D\u202B\u202D\u202E\u202B\u200D\u200F\u202E\u202E\u206C\u202E(Control)
		{
			/*
An exception occurred when decompiling this method (06000934)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Windows.Forms.Control/ControlCollection FPSMACROx.Form7::‫‫‍‮‭‌⁫‭‏‎⁮‌​⁮‪⁮‏⁭⁫‭‮⁯⁬⁯‭‮‍‌‭‎‍‫‭‮‫‍‏‮‮⁬‮(System.Windows.Forms.Control)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000935 RID: 2357
		static extern void \u200D\u202E\u206E\u206B\u200D\u200F\u206E\u200C\u206C\u202B\u206B\u202C\u206A\u200F\u202B\u202B\u206F\u202E\u202E\u200E\u202E\u202C\u206B\u206B\u206D\u206F\u200D\u206B\u206E\u200F\u206D\u200C\u206F\u206D\u202C\u202B\u200F\u200B\u200F\u202C\u202E(Control.ControlCollection, Control);

		// Token: 0x06000936 RID: 2358
		static extern void \u202E\u206D\u206B\u206F\u206A\u202A\u200E\u206E\u206F\u200C\u200F\u202A\u202A\u206D\u200F\u200B\u206F\u202B\u202D\u200C\u206F\u206D\u200D\u200F\u200E\u200E\u202A\u206B\u200B\u202D\u200F\u206A\u206F\u206A\u200B\u200D\u200C\u200C\u200E\u202B\u202E(Control, PaintEventHandler);

		// Token: 0x06000937 RID: 2359
		static extern void \u206B\u202E\u206C\u206A\u206B\u200F\u202C\u202A\u200E\u206A\u202C\u200D\u206D\u202A\u200B\u206F\u200B\u202A\u202D\u202E\u206B\u202A\u206A\u200F\u206C\u206F\u200D\u202C\u206B\u202C\u206F\u202E\u202A\u200D\u200E\u206A\u200D\u206C\u202A\u202B\u202E(Control, bool);

		// Token: 0x06000938 RID: 2360
		static extern CustomRadionButtonState \u202A\u202B\u202D\u200B\u200B\u202D\u206A\u206C\u200E\u206E\u200E\u202E\u206A\u202D\u206F\u206D\u200E\u206E\u206E\u200B\u206E\u202D\u200F\u206F\u202E\u200E\u200F\u200B\u202B\u202E\u202E\u206E\u206A\u206C\u206A\u206E\u202E\u206D\u206D\u202D\u202E(SiticoneRadioButton);

		// Token: 0x06000939 RID: 2361
		static extern void \u206B\u206B\u202A\u206A\u202B\u206D\u200D\u200C\u202C\u202A\u200C\u206B\u200F\u200F\u202C\u202C\u206B\u200C\u206D\u202E\u206F\u202E\u206A\u200C\u206F\u202B\u206E\u206A\u206F\u206C\u206F\u206A\u202C\u200F\u202D\u206E\u202E\u206B\u200C\u200D\u202E(CustomRadionButtonState, Color);

		// Token: 0x0600093A RID: 2362
		static extern void \u202B\u200E\u202E\u200F\u202B\u206A\u206C\u202B\u206E\u206D\u202C\u202C\u206B\u202D\u200D\u200B\u206F\u206C\u202B\u206A\u206D\u200F\u200B\u202E\u200E\u200E\u202B\u202C\u200B\u202E\u200E\u200B\u202C\u206A\u202B\u206E\u200F\u200B\u200D\u202A\u202E(CustomRadionButtonState, int);

		// Token: 0x0600093B RID: 2363
		static extern void \u200C\u200F\u200D\u206C\u200D\u206D\u206F\u200F\u202C\u200B\u200F\u206C\u206B\u200B\u206D\u200C\u200F\u206D\u202C\u206C\u202A\u202A\u202D\u202B\u206C\u202D\u206F\u200D\u206F\u200B\u202B\u206A\u200D\u200B\u206D\u206C\u202B\u202C\u200B\u200F\u202E(CustomRadionButtonState, Color);

		// Token: 0x0600093C RID: 2364 RVA: 0x00007D8C File Offset: 0x00005F8C
		static void \u200F\u202D\u200B\u200E\u202C\u202A\u206C\u206C\u206F\u206B\u202B\u200E\u200E\u200F\u206E\u206B\u206B\u200B\u200D\u200F\u202A\u202C\u200C\u200F\u200E\u200B\u206F\u200B\u202C\u206B\u206A\u200C\u200E\u202C\u206A\u200B\u200D\u206C\u200F\u200C\u202E(CustomRadionButtonState, Color)
		{
			/*
An exception occurred when decompiling this method (0600093C)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::‏‭​‎‬‪⁬⁬⁯⁫‫‎‎‏⁮⁫⁫​‍‏‪‬‌‏‎​⁯​‬⁫⁪‌‎‬⁪​‍⁬‏‌‮(Siticone.UI.WinForms.Suite.CustomRadionButtonState,System.Drawing.Color)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600093D RID: 2365
		static extern void \u202C\u200D\u206C\u200D\u202D\u200B\u200E\u206B\u200C\u206E\u202C\u202E\u200D\u202E\u206D\u200D\u206A\u200C\u206B\u202C\u202A\u202E\u200F\u200E\u200B\u206A\u200B\u202A\u206C\u200F\u206A\u200B\u202D\u202A\u202B\u206D\u202C\u200B\u206F\u202A\u202E(Control, Color);

		// Token: 0x0600093E RID: 2366
		static extern CustomRadionButtonState \u200E\u202A\u202E\u206A\u202B\u206D\u200D\u202E\u202E\u206D\u200E\u202E\u200D\u202A\u200C\u202B\u200D\u200B\u200C\u202A\u206C\u206D\u206C\u200B\u202B\u200B\u206B\u202A\u202B\u200C\u206E\u206F\u200D\u202C\u202B\u202A\u202D\u202A\u200D\u202C\u202E(SiticoneRadioButton);

		// Token: 0x0600093F RID: 2367 RVA: 0x00007DC0 File Offset: 0x00005FC0
		static void \u206C\u202C\u202E\u200D\u202D\u206F\u200F\u200B\u200F\u200D\u206A\u206F\u206A\u202B\u200D\u200B\u200E\u206D\u200E\u206D\u202E\u206C\u206E\u206E\u202B\u202B\u200C\u202D\u206B\u202E\u200D\u200C\u206E\u200C\u202C\u202A\u206C\u200B\u206B\u200F\u202E(ButtonBase, bool)
		{
			/*
An exception occurred when decompiling this method (0600093F)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::⁬‬‮‍‭⁯‏​‏‍⁪⁯⁪‫‍​‎⁭‎⁭‮⁬⁮⁮‫‫‌‭⁫‮‍‌⁮‌‬‪⁬​⁫‏‮(System.Windows.Forms.ButtonBase,System.Boolean)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000940 RID: 2368 RVA: 0x00007E00 File Offset: 0x00006000
		static void \u200E\u202E\u206D\u202C\u200B\u206A\u206A\u202E\u200D\u200B\u202C\u206A\u206C\u202C\u202A\u202C\u206B\u206D\u206A\u206F\u202C\u202B\u202D\u200C\u206F\u202C\u206B\u202C\u202A\u200C\u200C\u206B\u202E\u202D\u200D\u206E\u202B\u202C\u202B\u200C\u202E(RadioButton, EventHandler)
		{
			/*
An exception occurred when decompiling this method (06000940)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::‎‮⁭‬​⁪⁪‮‍​‬⁪⁬‬‪‬⁫⁭⁪⁯‬‫‭‌⁯‬⁫‬‪‌‌⁫‮‭‍⁮‫‬‫‌‮(System.Windows.Forms.RadioButton,System.EventHandler)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000941 RID: 2369 RVA: 0x00007D50 File Offset: 0x00005F50
		static void \u202B\u200B\u206E\u200C\u202D\u206C\u202E\u206E\u206D\u206D\u200C\u206C\u200C\u202D\u206C\u202A\u200E\u200E\u202B\u206C\u202B\u200E\u206D\u200F\u206D\u202B\u206D\u200C\u206C\u206D\u202C\u206E\u206E\u200F\u206D\u202B\u200D\u200C\u206E\u200E\u202E(RadioButton, bool)
		{
			/*
An exception occurred when decompiling this method (06000941)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::‫​⁮‌‭⁬‮⁮⁭⁭‌⁬‌‭⁬‪‎‎‫⁬‫‎⁭‏⁭‫⁭‌⁬⁭‬⁮⁮‏⁭‫‍‌⁮‎‮(System.Windows.Forms.RadioButton,System.Boolean)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000942 RID: 2370
		static extern void \u200C\u202B\u206B\u202A\u202A\u202A\u202E\u206C\u202E\u202E\u202D\u202A\u200F\u200F\u202D\u206B\u202C\u202B\u200B\u202D\u200E\u206B\u206F\u206B\u206E\u200C\u200E\u202B\u200F\u202C\u200F\u202C\u206D\u206A\u202A\u200C\u202C\u200B\u206B\u206E\u202E(CustomRadionButtonState, int);

		// Token: 0x06000943 RID: 2371
		static extern void \u206D\u202D\u200F\u200B\u200E\u200C\u206E\u200C\u206A\u202C\u200B\u206D\u206C\u200B\u200D\u200E\u206F\u200F\u206E\u200F\u206A\u200D\u200E\u200D\u206D\u202E\u206A\u206C\u202A\u202B\u206B\u202A\u200E\u206B\u206E\u202D\u202A\u206E\u202D\u202B\u202E(RadioButton, bool);

		// Token: 0x06000944 RID: 2372 RVA: 0x00007954 File Offset: 0x00005B54
		static ButtonState \u202D\u200C\u202A\u206E\u202A\u206E\u202A\u200B\u206B\u206F\u202D\u200C\u200D\u200F\u202D\u202C\u202E\u206B\u206A\u206B\u206E\u206F\u202D\u202B\u200C\u206D\u202B\u200E\u202C\u202A\u200E\u202B\u206C\u206D\u200D\u200F\u206F\u206D\u202E\u202E\u202E(SiticoneButton A_0)
		{
			jmp();
		}

		// Token: 0x06000945 RID: 2373
		static extern void \u206E\u206B\u202A\u200C\u200C\u202C\u206A\u206E\u202D\u202A\u202A\u202E\u206A\u206B\u200F\u206F\u206E\u202D\u200F\u206E\u206B\u206A\u206A\u200C\u206C\u206D\u200E\u202D\u202E\u206D\u200F\u206E\u202E\u200C\u202C\u200C\u202B\u200E\u206F\u200D\u202E(ButtonState, CustomButtonBase);

		// Token: 0x06000946 RID: 2374 RVA: 0x00007970 File Offset: 0x00005B70
		static ButtonImages \u206D\u206A\u202A\u200E\u206B\u200B\u206B\u200B\u202C\u202A\u202B\u206F\u200D\u202A\u206B\u200E\u200B\u206C\u200E\u206C\u202D\u202B\u206B\u202C\u206B\u200C\u206D\u206C\u200B\u202B\u202E\u200E\u200B\u202D\u200E\u200C\u200D\u200D\u202C\u206E\u202E(SiticoneButton)
		{
			/*
An exception occurred when decompiling this method (06000946)

ICSharpCode.Decompiler.DecompilerException: Error decompiling Siticone.UI.WinForms.Suite.ButtonImages FPSMACROx.Form7::⁭⁪‪‎⁫​⁫​‬‪‫⁯‍‪⁫‎​⁬‎⁬‭‫⁫‬⁫‌⁭⁬​‫‮‎​‭‎‌‍‍‬⁮‮(Siticone.UI.WinForms.SiticoneButton)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000947 RID: 2375
		static extern void \u202B\u200E\u206F\u206A\u202E\u206E\u206A\u206D\u206F\u200E\u200E\u202B\u206A\u202E\u202A\u200B\u202E\u206C\u202B\u200C\u202A\u200C\u200C\u202D\u202A\u200F\u206A\u200F\u200D\u200E\u206A\u202D\u200F\u200B\u202B\u206B\u200C\u200F\u202C\u202B\u202E(ButtonImages, CustomButtonBase);

		// Token: 0x06000948 RID: 2376 RVA: 0x000079A4 File Offset: 0x00005BA4
		static void \u200B\u206A\u200C\u202C\u202A\u202A\u200C\u206D\u200B\u206D\u202C\u200C\u206E\u206F\u200B\u202B\u202E\u202B\u200F\u202B\u200E\u200B\u206F\u202C\u202C\u206C\u202C\u206F\u202A\u206B\u200B\u206A\u206C\u206B\u200F\u202D\u200F\u200B\u200F\u202E\u202E(SiticoneButton, Color)
		{
			/*
An exception occurred when decompiling this method (06000948)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::​⁪‌‬‪‪‌⁭​⁭‬‌⁮⁯​‫‮‫‏‫‎​⁯‬‬⁬‬⁯‪⁫​⁪⁬⁫‏‭‏​‏‮‮(Siticone.UI.WinForms.SiticoneButton,System.Drawing.Color)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000949 RID: 2377 RVA: 0x000078F8 File Offset: 0x00005AF8
		static void \u200C\u202E\u206E\u206A\u200F\u206D\u200F\u206F\u202B\u206E\u200D\u200F\u206E\u202E\u202B\u206A\u202D\u206A\u202A\u206E\u202D\u206B\u202B\u200B\u200F\u206F\u206C\u202B\u202E\u202B\u202C\u206D\u200D\u200E\u200B\u206C\u200D\u200B\u200F\u202E\u202E(Control, Font)
		{
			/*
An exception occurred when decompiling this method (06000949)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::‌‮⁮⁪‏⁭‏⁯‫⁮‍‏⁮‮‫⁪‭⁪‪⁮‭⁫‫​‏⁯⁬‫‮‫‬⁭‍‎​⁬‍​‏‮‮(System.Windows.Forms.Control,System.Drawing.Font)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600094A RID: 2378
		static extern ButtonState \u200C\u206F\u200F\u206B\u206C\u200D\u206E\u206D\u206B\u202A\u202B\u200D\u206F\u202D\u202C\u206D\u200B\u202D\u206B\u200B\u200D\u206D\u202A\u200B\u206A\u202E\u202C\u200D\u202E\u206A\u200F\u206D\u206E\u206D\u202D\u202D\u206A\u200B\u206D\u206D\u202E(SiticoneButton);

		// Token: 0x0600094B RID: 2379 RVA: 0x000079CC File Offset: 0x00005BCC
		static ShadowDecoration \u200D\u206C\u206D\u202E\u206C\u202A\u202B\u202A\u206B\u200D\u206F\u202C\u202B\u202A\u206B\u206E\u202A\u200C\u202E\u206B\u200D\u202D\u200B\u200F\u202D\u206C\u200B\u206B\u202D\u200E\u202C\u200B\u206C\u206B\u202B\u200D\u202A\u206B\u200C\u202C\u202E(SiticoneButton)
		{
			/*
An exception occurred when decompiling this method (0600094B)

ICSharpCode.Decompiler.DecompilerException: Error decompiling Siticone.UI.WinForms.Suite.ShadowDecoration FPSMACROx.Form7::‍⁬⁭‮⁬‪‫‪⁫‍⁯‬‫‪⁫⁮‪‌‮⁫‍‭​‏‭⁬​⁫‭‎‬​⁬⁫‫‍‪⁫‌‬‮(Siticone.UI.WinForms.SiticoneButton)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600094C RID: 2380
		static extern void \u206E\u206A\u206D\u202E\u200C\u200F\u206C\u206E\u206E\u202C\u206E\u206B\u206C\u206B\u202E\u206E\u202D\u200E\u202C\u202E\u202C\u202E\u200C\u206D\u206F\u200B\u200F\u200D\u206E\u206F\u200D\u206D\u206B\u202A\u206A\u206E\u202B\u206F\u206E\u202D\u202E(TextBox, EventHandler);

		// Token: 0x0600094D RID: 2381 RVA: 0x00008D00 File Offset: 0x00006F00
		static Color \u202D\u200B\u202A\u206C\u200B\u202B\u200B\u202D\u206B\u202B\u200F\u200D\u202A\u202A\u202D\u206B\u202C\u200F\u202C\u206A\u206F\u200F\u200D\u202E\u202C\u202D\u200E\u202E\u206C\u206A\u200E\u206E\u206A\u200E\u206B\u200E\u206D\u202C\u206C\u200D\u202E()
		{
			/*
An exception occurred when decompiling this method (0600094D)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Drawing.Color FPSMACROx.Form7::‭​‪⁬​‫​‭⁫‫‏‍‪‪‭⁫‬‏‬⁪⁯‏‍‮‬‭‎‮⁬⁪‎⁮⁪‎⁫‎⁭‬⁬‍‮()

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600094E RID: 2382
		static extern Color \u200C\u200B\u206D\u202D\u200E\u200E\u200D\u202D\u200C\u202D\u200C\u200D\u202C\u200E\u206A\u206F\u200D\u206F\u206A\u200B\u200C\u200C\u206F\u202C\u200F\u206C\u202C\u200E\u202A\u206F\u200B\u200B\u200E\u206A\u202C\u206F\u202B\u206D\u202D\u200F\u202E();

		// Token: 0x0600094F RID: 2383 RVA: 0x00007B84 File Offset: 0x00005D84
		static ImageControlState \u200D\u200C\u206F\u206C\u200E\u200F\u202B\u200E\u202C\u206D\u200F\u206A\u202A\u200C\u202A\u202C\u200D\u202C\u206E\u206A\u202C\u206A\u206E\u206E\u202D\u206D\u200E\u206D\u206B\u202B\u200D\u206E\u206E\u206D\u206E\u200D\u206F\u206D\u206B\u202D\u202E(SiticoneImageButton)
		{
			/*
An exception occurred when decompiling this method (0600094F)

ICSharpCode.Decompiler.DecompilerException: Error decompiling Siticone.UI.WinForms.Suite.ImageControlState FPSMACROx.Form7::‍‌⁯⁬‎‏‫‎‬⁭‏⁪‪‌‪‬‍‬⁮⁪‬⁪⁮⁮‭⁭‎⁭⁫‫‍⁮⁮⁭⁮‍⁯⁭⁫‭‮(Siticone.UI.WinForms.SiticoneImageButton)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000950 RID: 2384
		static extern void \u202A\u202B\u202C\u202A\u202E\u200F\u202B\u202D\u200F\u200E\u202E\u202E\u200C\u200F\u206A\u206A\u200F\u206F\u200B\u202D\u200D\u200E\u202B\u202A\u202C\u206C\u200E\u206E\u206D\u206E\u202A\u206C\u206B\u202C\u206E\u202E\u200D\u206C\u206C\u206B\u202E(ImageControlState, UIDefaultControl);

		// Token: 0x06000951 RID: 2385 RVA: 0x00007BB0 File Offset: 0x00005DB0
		static ImageControlState \u200C\u200F\u200F\u206C\u202C\u202C\u206E\u206B\u200D\u202B\u202B\u202E\u202D\u200D\u206C\u200F\u200F\u206D\u202E\u202A\u200D\u200D\u202C\u206A\u202C\u206F\u202D\u202A\u202B\u202C\u200D\u206D\u200B\u202B\u200C\u200D\u202A\u206F\u200D\u206C\u202E(SiticoneImageButton)
		{
			/*
An exception occurred when decompiling this method (06000951)

ICSharpCode.Decompiler.DecompilerException: Error decompiling Siticone.UI.WinForms.Suite.ImageControlState FPSMACROx.Form7::‌‏‏⁬‬‬⁮⁫‍‫‫‮‭‍⁬‏‏⁭‮‪‍‍‬⁪‬⁯‭‪‫‬‍⁭​‫‌‍‪⁯‍⁬‮(Siticone.UI.WinForms.SiticoneImageButton)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000952 RID: 2386
		static extern void \u206A\u206B\u206E\u206B\u202B\u202B\u206B\u202A\u202D\u200F\u202D\u206C\u200B\u200D\u202B\u202D\u206C\u200F\u200F\u206D\u200C\u202A\u202C\u200B\u206D\u200E\u200D\u206D\u206D\u206B\u206E\u206B\u202B\u206C\u206B\u202E\u202C\u206A\u206D\u206E\u202E(ImageControlState, Size);

		// Token: 0x06000953 RID: 2387
		static extern void \u206E\u200B\u206D\u200D\u206C\u200B\u200D\u202E\u200F\u200F\u202A\u206A\u202B\u206E\u206F\u206E\u200F\u200E\u202B\u202D\u200B\u200B\u200E\u202B\u206F\u200D\u206F\u200C\u202B\u202E\u200D\u206C\u206C\u206D\u200C\u200E\u200B\u202C\u202A\u200D\u202E(SiticoneImageButton, Image);

		// Token: 0x06000954 RID: 2388 RVA: 0x00007BF0 File Offset: 0x00005DF0
		static void \u200E\u200B\u202E\u206C\u206F\u200E\u206D\u206E\u206A\u206B\u202E\u200B\u206F\u200E\u200E\u206B\u202A\u200C\u202D\u206F\u206C\u200B\u206B\u202D\u202C\u206D\u206D\u200C\u206E\u206E\u202D\u206A\u206B\u202C\u200F\u202E\u202A\u200D\u202E\u202A\u202E(SiticoneImageButton, Size)
		{
			/*
An exception occurred when decompiling this method (06000954)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::‎​‮⁬⁯‎⁭⁮⁪⁫‮​⁯‎‎⁫‪‌‭⁯⁬​⁫‭‬⁭⁭‌⁮⁮‭⁪⁫‬‏‮‪‍‮‪‮(Siticone.UI.WinForms.SiticoneImageButton,System.Drawing.Size)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000955 RID: 2389
		static extern ImageControlState \u200E\u202D\u202E\u206F\u206F\u200B\u200C\u202A\u200B\u202A\u200C\u206B\u202A\u202C\u200D\u202D\u200F\u200E\u206F\u206E\u206E\u200C\u200E\u200C\u200B\u206D\u206A\u200B\u202C\u200B\u202B\u206C\u202C\u202C\u200B\u202A\u206D\u202D\u202E\u202C\u202E(SiticoneImageButton);

		// Token: 0x06000956 RID: 2390 RVA: 0x00008D2C File Offset: 0x00006F2C
		static void \u206F\u206A\u206E\u206D\u202D\u200E\u202D\u202D\u202D\u206D\u200F\u202B\u200C\u206F\u202A\u202C\u202D\u200C\u206F\u206D\u200F\u200C\u206B\u206E\u200C\u202B\u200D\u206B\u206B\u206E\u206B\u200B\u200E\u202A\u206E\u202A\u202B\u200E\u206F\u202E(CheckBox, bool)
		{
			/*
An exception occurred when decompiling this method (06000956)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::⁯⁪⁮⁭‭‎‭‭‭⁭‏‫‌⁯‪‬‭‌⁯⁭‏‌⁫⁮‌‫‍⁫⁫⁮⁫​‎‪⁮‪‫‎⁯‮(System.Windows.Forms.CheckBox,System.Boolean)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000957 RID: 2391 RVA: 0x00008D44 File Offset: 0x00006F44
		static CustomCheckBoxState \u200B\u206D\u206F\u206A\u206D\u206B\u202E\u206E\u202B\u200B\u202C\u202C\u200F\u200C\u202B\u202A\u206A\u202D\u206C\u200B\u206D\u202A\u206F\u206C\u200E\u200D\u200E\u206F\u206A\u206B\u200D\u202E\u206C\u206B\u200F\u200F\u200B\u202A\u202B\u202E\u202E(SiticoneCheckBox)
		{
			/*
An exception occurred when decompiling this method (06000957)

ICSharpCode.Decompiler.DecompilerException: Error decompiling Siticone.UI.WinForms.Suite.CustomCheckBoxState FPSMACROx.Form7::​⁭⁯⁪⁭⁫‮⁮‫​‬‬‏‌‫‪⁪‭⁬​⁭‪⁯⁬‎‍‎⁯⁪⁫‍‮⁬⁫‏‏​‪‫‮‮(Siticone.UI.WinForms.SiticoneCheckBox)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000958 RID: 2392 RVA: 0x00007AA4 File Offset: 0x00005CA4
		static void \u200D\u200E\u202D\u202D\u202A\u206A\u200B\u202A\u200C\u206B\u200C\u200F\u206B\u206E\u202A\u206A\u202D\u202A\u200B\u206C\u206F\u202D\u200F\u206E\u206C\u202E\u202A\u206E\u202D\u206B\u200C\u206E\u206F\u200D\u206C\u202B\u202D\u202A\u206C\u206E\u202E(CustomCheckBoxState A_0, Color A_1)
		{
			jmp();
		}

		// Token: 0x06000959 RID: 2393
		static extern void \u202E\u202C\u200C\u200C\u202C\u200D\u206B\u200E\u200E\u202B\u206B\u200C\u200C\u200C\u200D\u206D\u206D\u200B\u206B\u206E\u202B\u206A\u206F\u202C\u206C\u206D\u200E\u202D\u202E\u200B\u206B\u202A\u206C\u202D\u200F\u200B\u206B\u206A\u202B\u202E(CustomCheckBoxState, int);

		// Token: 0x0600095A RID: 2394 RVA: 0x00007AF4 File Offset: 0x00005CF4
		static void \u200C\u200F\u202D\u206B\u202B\u206D\u202D\u206F\u202B\u200D\u200B\u202D\u200F\u202D\u202E\u206F\u202B\u200F\u206A\u206F\u206D\u202C\u200B\u206D\u202E\u206E\u202A\u200B\u206B\u200C\u202C\u200F\u206D\u202E\u200D\u202B\u202C\u206F\u202B\u200F\u202E(CustomCheckBoxState, int)
		{
			/*
An exception occurred when decompiling this method (0600095A)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::‌‏‭⁫‫⁭‭⁯‫‍​‭‏‭‮⁯‫‏⁪⁯⁭‬​⁭‮⁮‪​⁫‌‬‏⁭‮‍‫‬⁯‫‏‮(Siticone.UI.WinForms.Suite.CustomCheckBoxState,System.Int32)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600095B RID: 2395
		static extern void \u200E\u206F\u200C\u200B\u200D\u200F\u202A\u200E\u202A\u206E\u202E\u200E\u202E\u202D\u200C\u206A\u200B\u206E\u206F\u206B\u206B\u206C\u202E\u206F\u206A\u202E\u200E\u200D\u206A\u202E\u200B\u202A\u206A\u200D\u200F\u206B\u202B\u202E\u200B\u200E\u202E(CustomCheckBoxState, Color);

		// Token: 0x0600095C RID: 2396
		static extern void \u200E\u206D\u202E\u206E\u206E\u200B\u202D\u200F\u206A\u202C\u206C\u202C\u206E\u202A\u206C\u206E\u206A\u202A\u202A\u202B\u206A\u200C\u202B\u202D\u206D\u206E\u202B\u206F\u202C\u200C\u200D\u200C\u206D\u206F\u206C\u206A\u202D\u202E\u206D\u202A\u202E(CheckBox, CheckState);

		// Token: 0x0600095D RID: 2397
		static extern CustomCheckBoxState \u200D\u202B\u206D\u202D\u202B\u206E\u206E\u202A\u206D\u206A\u200E\u206A\u206C\u206A\u202C\u206B\u202C\u202B\u202A\u206F\u206C\u200B\u202C\u200F\u202D\u200C\u200E\u202B\u206D\u206D\u202E\u200B\u206E\u206D\u202D\u202A\u200F\u206E\u206B\u206A\u202E(SiticoneCheckBox);

		// Token: 0x0600095E RID: 2398
		static extern void \u200C\u202B\u202E\u200F\u206B\u202C\u200F\u202B\u206F\u206E\u206B\u206A\u202B\u206C\u202E\u200C\u206D\u206C\u206F\u206C\u202C\u206F\u206A\u206F\u202A\u200F\u200B\u206F\u206D\u200E\u206F\u206A\u202C\u206E\u202D\u200F\u202A\u200E\u200F\u206F\u202E(CheckBox, EventHandler);

		// Token: 0x0600095F RID: 2399
		static extern void \u206C\u200C\u202E\u206E\u206D\u202D\u200F\u202A\u202A\u200F\u206F\u202C\u202D\u200D\u206F\u202B\u206A\u200C\u206D\u202E\u206A\u206E\u206D\u202B\u200E\u206A\u202B\u200E\u202C\u200B\u206F\u202D\u206E\u200F\u200D\u202E\u202D\u200F\u202E\u200C\u202E(Control, bool);

		// Token: 0x06000960 RID: 2400
		static extern void \u206E\u206A\u206F\u202C\u200F\u202C\u202E\u202E\u206D\u206D\u206D\u206E\u200D\u200F\u202E\u200D\u202D\u206B\u202A\u200D\u202D\u202E\u200E\u202B\u200B\u200B\u200F\u202B\u206D\u200B\u206A\u206A\u202A\u206F\u206D\u206F\u200E\u200C\u206D\u200C\u202E(SiticoneButton, Color);

		// Token: 0x06000961 RID: 2401 RVA: 0x00008D7C File Offset: 0x00006F7C
		static void \u200E\u202B\u206B\u202C\u200F\u200E\u200B\u200D\u200C\u206D\u200E\u200B\u200C\u206D\u200C\u200E\u206C\u200B\u206B\u202C\u200E\u206A\u202E\u206E\u200B\u200B\u202A\u206E\u206F\u202D\u206A\u200D\u200C\u200F\u206F\u202B\u200D\u206F\u206F\u206F\u202E(ToolStripItem, Color)
		{
			/*
An exception occurred when decompiling this method (06000961)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::‎‫⁫‬‏‎​‍‌⁭‎​‌⁭‌‎⁬​⁫‬‎⁪‮⁮​​‪⁮⁯‭⁪‍‌‏⁯‫‍⁯⁯⁯‮(System.Windows.Forms.ToolStripItem,System.Drawing.Color)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000962 RID: 2402 RVA: 0x00008DBC File Offset: 0x00006FBC
		static Color \u202B\u200E\u206E\u206F\u200E\u200E\u202B\u202E\u200E\u202B\u206B\u206C\u206E\u200B\u200B\u202B\u206B\u206A\u202B\u206A\u206A\u206A\u200E\u206D\u202C\u206C\u200B\u206D\u202D\u202D\u202A\u200E\u200D\u200E\u202B\u202A\u206B\u206B\u206F\u206E\u202E()
		{
			/*
An exception occurred when decompiling this method (06000962)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Drawing.Color FPSMACROx.Form7::‫‎⁮⁯‎‎‫‮‎‫⁫⁬⁮​​‫⁫⁪‫⁪⁪⁪‎⁭‬⁬​⁭‭‭‪‎‍‎‫‪⁫⁫⁯⁮‮()

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000963 RID: 2403
		static extern void \u206A\u206C\u200F\u200B\u206A\u202C\u206C\u202E\u202B\u202B\u200D\u206F\u202B\u202B\u206F\u200C\u206C\u202D\u206B\u200F\u206A\u200B\u206D\u200B\u202C\u200F\u206C\u202C\u202A\u200F\u200C\u202E\u200E\u200E\u202B\u206E\u200C\u206A\u206B\u202D\u202E(ToolStripItem, Color);

		// Token: 0x06000964 RID: 2404
		static extern void \u202C\u200F\u206F\u200C\u200C\u200F\u202A\u206E\u206E\u206A\u206C\u202B\u202C\u206B\u200D\u202C\u202A\u202E\u202C\u202D\u200B\u206A\u206E\u206F\u202C\u202B\u202E\u200F\u202C\u206E\u200B\u206F\u200D\u206E\u206F\u206B\u202B\u200B\u206B\u206C\u202E(ToolStripItem, string);

		// Token: 0x06000965 RID: 2405
		static extern void \u200E\u202C\u202B\u202A\u202E\u200E\u206F\u206C\u202D\u202B\u200F\u200B\u206C\u200C\u202B\u206B\u200D\u206B\u206B\u206C\u200F\u200B\u200F\u202D\u206C\u202C\u202D\u202A\u206C\u206D\u200C\u200E\u200B\u206D\u200B\u200B\u202E\u206E\u202B\u200E\u202E(ToolStripItem, Size);

		// Token: 0x06000966 RID: 2406
		static extern void \u206E\u206B\u202A\u202C\u206B\u206F\u200B\u202C\u206A\u206B\u200F\u206A\u200F\u206B\u202D\u200B\u200F\u202C\u206E\u206F\u206D\u206A\u206A\u200C\u206C\u200C\u200C\u206F\u200D\u206A\u202C\u200C\u206F\u200C\u202D\u206F\u200D\u202C\u206A\u200D\u202E(ToolStripItem, string);

		// Token: 0x06000967 RID: 2407 RVA: 0x00008E04 File Offset: 0x00007004
		static void \u206E\u206B\u206D\u206A\u206E\u202E\u206D\u206F\u206D\u206A\u206E\u202B\u206A\u200B\u206F\u200D\u206F\u202E\u206C\u206E\u200B\u206D\u200E\u206E\u206A\u202A\u202A\u206C\u206E\u200C\u206A\u202D\u200B\u206C\u202C\u202A\u206B\u206D\u200C\u206F\u202E(ToolStripItem, EventHandler)
		{
			/*
An exception occurred when decompiling this method (06000967)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::⁮⁫⁭⁪⁮‮⁭⁯⁭⁪⁮‫⁪​⁯‍⁯‮⁬⁮​⁭‎⁮⁪‪‪⁬⁮‌⁪‭​⁬‬‪⁫⁭‌⁯‮(System.Windows.Forms.ToolStripItem,System.EventHandler)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000968 RID: 2408
		static extern ToolStripItemCollection \u206C\u202E\u202E\u206A\u200E\u206E\u202C\u200C\u200E\u200E\u206E\u200E\u206A\u200C\u206E\u206E\u200F\u200D\u206E\u206D\u206B\u206F\u202A\u206C\u200E\u206E\u206A\u206C\u206C\u206C\u200B\u200C\u202E\u200B\u200E\u206C\u206C\u200E\u202A\u200C\u202E(ToolStripDropDownItem);

		// Token: 0x06000969 RID: 2409 RVA: 0x00008E48 File Offset: 0x00007048
		static void \u200C\u202D\u206C\u200D\u206D\u206D\u200E\u202B\u206B\u200F\u206D\u206C\u200D\u206E\u206F\u202C\u206F\u206D\u200B\u206D\u200E\u206D\u202D\u206C\u206D\u206B\u202E\u206B\u202B\u200B\u206F\u200D\u200D\u200B\u202C\u206D\u200F\u206B\u202B\u202D\u202E(ToolStripItemCollection, ToolStripItem[])
		{
			/*
An exception occurred when decompiling this method (06000969)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::‌‭⁬‍⁭⁭‎‫⁫‏⁭⁬‍⁮⁯‬⁯⁭​⁭‎⁭‭⁬⁭⁫‮⁫‫​⁯‍‍​‬⁭‏⁫‫‭‮(System.Windows.Forms.ToolStripItemCollection,System.Windows.Forms.ToolStripItem[])

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600096A RID: 2410
		static extern void \u206E\u200B\u206A\u202B\u200C\u202D\u200D\u200F\u200B\u202D\u202D\u202B\u206E\u202C\u206B\u206E\u202B\u206D\u202A\u206D\u200C\u200B\u200E\u206F\u200D\u202B\u202C\u202D\u202B\u206A\u200F\u206E\u206B\u200B\u202B\u206A\u200E\u202E(ToolStripItem, Image);

		// Token: 0x0600096B RID: 2411
		static extern void \u206E\u202D\u202D\u200D\u202B\u202D\u206F\u202C\u200F\u206B\u206A\u202B\u202D\u202E\u202E\u200E\u202B\u202E\u202C\u206D\u202D\u202C\u206A\u202E\u206A\u206C\u202B\u200C\u200B\u202D\u202B\u200F\u200B\u200D\u202E\u200D\u200E\u202E\u206A\u206A\u202E(ToolStripItem, ContentAlignment);

		// Token: 0x0600096C RID: 2412
		static extern void \u202E\u206E\u202B\u200E\u200E\u206A\u202D\u202B\u200E\u200C\u202D\u206F\u206B\u200C\u202E\u206E\u200C\u200F\u200E\u200C\u200E\u200D\u202E\u206B\u202D\u202D\u202E\u200C\u202E\u200D\u206D\u202C\u200D\u206B\u200D\u206E\u200C\u206D\u200C\u206C\u202E(ToolStrip, Color);

		// Token: 0x0600096D RID: 2413
		static extern ToolStripItemCollection \u202E\u200F\u200F\u206E\u200B\u202E\u202B\u206E\u202C\u206B\u200D\u202C\u206F\u202E\u200B\u202E\u206D\u202C\u200E\u200C\u206E\u200C\u200F\u200F\u206F\u202C\u206A\u202E\u200C\u202E\u206B\u202B\u202E\u202E\u200E\u206E\u200F\u200B\u206A\u202C\u202E(ToolStrip);

		// Token: 0x0600096E RID: 2414
		static extern void \u202C\u202B\u206F\u202D\u200C\u202B\u200B\u200E\u206E\u200D\u206E\u206E\u206A\u200D\u206A\u206E\u200E\u206D\u206D\u202E\u200D\u206D\u206A\u200D\u202C\u202A\u200E\u202D\u202E\u202D\u200F\u202D\u200F\u200C\u200F\u206A\u200C\u202B\u200D\u206E\u202E(ToolStrip, ToolStripItemClickedEventHandler);

		// Token: 0x0600096F RID: 2415 RVA: 0x000078AC File Offset: 0x00005AAC
		static void \u206E\u202A\u206E\u200E\u200C\u200C\u200B\u202C\u200F\u200F\u206F\u206B\u200E\u206B\u206C\u206C\u202C\u206D\u202A\u206C\u200C\u202D\u200E\u206A\u206F\u200F\u206C\u200B\u202C\u206C\u206F\u206D\u202D\u206D\u206C\u206D\u202C\u200C\u202B\u200C\u202E(SiticoneDragControl, Control)
		{
			/*
An exception occurred when decompiling this method (0600096F)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::⁮‪⁮‎‌‌​‬‏‏⁯⁫‎⁫⁬⁬‬⁭‪⁬‌‭‎⁪⁯‏⁬​‬⁬⁯⁭‭⁭⁬⁭‬‌‫‌‮(Siticone.UI.WinForms.SiticoneDragControl,System.Windows.Forms.Control)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000970 RID: 2416
		static extern void \u200E\u200E\u202D\u200C\u202C\u206A\u206F\u202B\u200B\u206C\u202C\u206B\u200B\u206E\u202E\u202A\u202B\u200C\u206C\u202D\u200D\u206A\u206D\u206B\u206A\u206D\u202C\u202A\u202D\u206E\u206C\u202B\u206B\u206B\u202D\u202A\u202B\u202B\u202B\u202A\u202E(ContainerControl, SizeF);

		// Token: 0x06000971 RID: 2417
		static extern void \u200F\u200B\u202B\u200C\u206C\u206F\u200B\u200E\u200C\u200C\u202D\u206C\u206E\u206C\u200D\u200B\u200B\u202E\u206B\u202B\u206C\u200B\u206B\u200E\u200D\u200F\u206D\u200B\u206B\u202A\u202A\u200C\u206C\u202E\u206E\u200D\u206A\u202B\u200D\u202E\u202E(ContainerControl, AutoScaleMode);

		// Token: 0x06000972 RID: 2418
		static extern void \u206B\u200C\u206D\u202C\u206D\u202A\u206E\u200F\u200D\u202A\u200F\u200E\u206F\u206F\u206B\u206F\u200F\u200D\u200B\u202E\u200F\u202E\u200D\u206B\u200C\u206B\u200D\u200C\u200C\u206A\u202B\u200F\u206D\u200B\u200E\u206D\u202B\u202C\u202D\u202C\u202E(Form, Size);

		// Token: 0x06000973 RID: 2419
		static extern Control.ControlCollection \u200C\u206D\u206C\u200D\u202D\u206D\u206D\u200D\u200C\u202A\u206C\u202A\u200E\u206B\u202E\u206D\u202A\u206D\u202D\u206D\u200D\u206B\u206A\u206D\u200B\u202A\u206C\u200E\u202A\u202E\u206F\u206F\u206D\u202A\u202A\u202D\u200E\u202D\u200D\u200D\u202E(Control);

		// Token: 0x06000974 RID: 2420
		static extern void \u206C\u206B\u206E\u206C\u202D\u200C\u206A\u206E\u200F\u206F\u206F\u206C\u206F\u206C\u206C\u202B\u206E\u202B\u202E\u202A\u202D\u200E\u206F\u200D\u200C\u202E\u206C\u206B\u202D\u202C\u202E\u200E\u200E\u206C\u206C\u202E\u206E\u206F\u202A\u202B\u202E(Form, FormBorderStyle);

		// Token: 0x06000975 RID: 2421
		static extern object \u202E\u200E\u206E\u200F\u202E\u202E\u202C\u202C\u200D\u206D\u206A\u200F\u202A\u206F\u206A\u200E\u200F\u200F\u202C\u202C\u206A\u200E\u200F\u202B\u202B\u206C\u200D\u200E\u206F\u206E\u206C\u206A\u206C\u202A\u200B\u200D\u206A\u206F\u200C\u202D\u202E(ResourceManager, string);

		// Token: 0x06000976 RID: 2422 RVA: 0x0000835C File Offset: 0x0000655C
		static void \u202A\u206A\u206E\u206C\u200C\u206C\u206A\u202C\u202A\u206D\u206F\u206D\u200C\u202A\u202E\u206D\u206B\u200F\u206E\u206C\u206E\u202D\u206B\u206E\u200D\u202D\u202B\u206D\u206D\u202E\u200B\u206F\u202E\u206C\u200D\u206F\u206F\u202E\u202D\u206B\u202E(Form, Icon)
		{
			/*
An exception occurred when decompiling this method (06000976)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void FPSMACROx.Form7::‪⁪⁮⁬‌⁬⁪‬‪⁭⁯⁭‌‪‮⁭⁫‏⁮⁬⁮‭⁫⁮‍‭‫⁭⁭‮​⁯‮⁬‍⁯⁯‮‭⁫‮(System.Windows.Forms.Form,System.Drawing.Icon)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000977 RID: 2423
		static extern void \u200C\u200C\u200E\u200C\u200D\u206E\u202D\u202D\u200F\u206E\u206B\u202B\u202C\u206B\u206B\u202C\u206A\u200E\u206C\u202E\u202C\u202A\u200C\u200C\u202E\u200E\u200E\u206F\u206A\u202E\u200F\u206A\u200C\u200D\u202D\u206A\u200E\u200C\u202E\u206D\u202E(Control, string);

		// Token: 0x06000978 RID: 2424
		static extern void \u200D\u202B\u206B\u206B\u200B\u200C\u206A\u200E\u206A\u200F\u206F\u206D\u206F\u202A\u206C\u202D\u206C\u200D\u200C\u206D\u200C\u206E\u200D\u200E\u206A\u200B\u200D\u202C\u206C\u202D\u202A\u206A\u206E\u200F\u206C\u200F\u200F\u200D\u200D\u202A\u202E(Form, bool);

		// Token: 0x06000979 RID: 2425
		static extern void \u206E\u200D\u206A\u202D\u206C\u206E\u200B\u202B\u206B\u206C\u202D\u202B\u206D\u206F\u206C\u200B\u202A\u202B\u200F\u200C\u206D\u206D\u206A\u202B\u200F\u206A\u202E\u206D\u202A\u202D\u206F\u206F\u206B\u206A\u206E\u200F\u206C\u200B\u206D\u206E\u202E(Form, EventHandler);

		// Token: 0x0600097A RID: 2426
		static extern void \u200E\u206E\u200C\u206B\u206B\u202D\u200D\u200C\u206E\u202D\u200E\u200B\u202D\u206E\u206E\u206E\u206F\u202A\u200C\u206A\u202B\u200B\u206F\u206C\u200D\u202D\u206C\u202B\u206D\u206E\u200F\u206E\u200B\u200B\u206C\u206C\u206D\u206C\u200C\u206F\u202E(Form, EventHandler);

		// Token: 0x0600097B RID: 2427
		static extern void \u200F\u202D\u202C\u206F\u206B\u206E\u206B\u200F\u200F\u202D\u200E\u200F\u206E\u200F\u202D\u200C\u206A\u202E\u202D\u206B\u206A\u200E\u200D\u200C\u206F\u206A\u206B\u206C\u206E\u200B\u202C\u200C\u202E\u202B\u200F\u206C\u200B\u202A\u200E\u200C\u202E(Control, bool);

		// Token: 0x0600097C RID: 2428
		static extern void \u206E\u202E\u200C\u200C\u202A\u200B\u206B\u206B\u200B\u200E\u202A\u206C\u200F\u202E\u202D\u202B\u202B\u200B\u202A\u206B\u206F\u202D\u206D\u206B\u200D\u202A\u206B\u206D\u200D\u202D\u206D\u206D\u200F\u206B\u200D\u202E\u200C\u202B\u206A\u200E\u202E(Control);

		// Token: 0x0600097D RID: 2429
		static extern void \u206B\u200B\u202A\u202E\u202B\u202E\u202B\u200E\u206D\u206E\u206C\u206B\u200B\u206D\u206D\u202B\u206A\u206B\u200E\u200E\u200C\u202B\u202A\u200C\u200E\u200B\u200E\u202E\u200F\u200B\u202C\u202A\u200F\u206E\u202A\u202A\u200C\u200D\u202E\u202C\u202E(Control, bool);

		// Token: 0x0600097E RID: 2430
		static extern void \u202D\u206C\u206B\u202D\u200F\u206C\u200D\u206E\u206C\u200E\u202A\u206A\u206D\u206A\u200D\u200B\u206C\u206F\u202E\u206B\u200B\u206B\u202E\u200E\u200F\u206C\u206D\u206A\u200C\u200E\u200F\u200B\u206F\u206A\u202B\u200F\u206E\u206C\u200B\u206F\u202E(Control);

		// Token: 0x04000304 RID: 772
		public static api KeyAuthApp;

		// Token: 0x04000305 RID: 773
		public static string hasoooo;

		// Token: 0x04000306 RID: 774
		private new int Move;

		// Token: 0x04000307 RID: 775
		private int Mouse_X;

		// Token: 0x04000308 RID: 776
		private int Mouse_Y;

		// Token: 0x04000309 RID: 777
		private yapilar.INIKaydet ini;

		// Token: 0x0400030A RID: 778
		private string nullcuu;

		// Token: 0x0400030B RID: 779
		public static string usernameh1;

		// Token: 0x0400030C RID: 780
		private IContainer components;

		// Token: 0x0400030D RID: 781
		private SiticoneLabel SiticoneLabel1;

		// Token: 0x0400030E RID: 782
		private SiticoneTextBox Password;

		// Token: 0x0400030F RID: 783
		private SiticoneControlBox siticoneControlBox2;

		// Token: 0x04000310 RID: 784
		private SiticoneControlBox siticoneControlBox1;

		// Token: 0x04000311 RID: 785
		private Panel panel2;

		// Token: 0x04000312 RID: 786
		private Label label8;

		// Token: 0x04000313 RID: 787
		private Label label2;

		// Token: 0x04000314 RID: 788
		private SiticoneButton siticoneButton7;

		// Token: 0x04000315 RID: 789
		private SiticoneLabel siticoneLabel10;

		// Token: 0x04000316 RID: 790
		private SiticoneTextBox siticoneTextBox7;

		// Token: 0x04000317 RID: 791
		private SiticoneLabel siticoneLabel7;

		// Token: 0x04000318 RID: 792
		private SiticoneTextBox siticoneTextBox4;

		// Token: 0x04000319 RID: 793
		private SiticoneLabel siticoneLabel4;

		// Token: 0x0400031A RID: 794
		private SiticoneTextBox siticoneTextBox3;

		// Token: 0x0400031B RID: 795
		private SiticoneLabel siticoneLabel5;

		// Token: 0x0400031C RID: 796
		private SiticoneTextBox siticoneTextBox2;

		// Token: 0x0400031D RID: 797
		private Panel panel3;

		// Token: 0x0400031E RID: 798
		private SiticoneButton siticoneButton5;

		// Token: 0x0400031F RID: 799
		private SiticoneButton siticoneButton4;

		// Token: 0x04000320 RID: 800
		private SiticoneButton siticoneButton3;

		// Token: 0x04000321 RID: 801
		private Label label4;

		// Token: 0x04000322 RID: 802
		private Label label5;

		// Token: 0x04000323 RID: 803
		private Label label1;

		// Token: 0x04000324 RID: 804
		private Label label3;

		// Token: 0x04000325 RID: 805
		private SiticoneButton siticoneButton2;

		// Token: 0x04000326 RID: 806
		private Panel panel1;

		// Token: 0x04000327 RID: 807
		private SiticoneImageButton siticoneImageButton1;

		// Token: 0x04000328 RID: 808
		private CheckBox checkBox3;

		// Token: 0x04000329 RID: 809
		private CheckBox checkBox1;

		// Token: 0x0400032A RID: 810
		private Label label12;

		// Token: 0x0400032B RID: 811
		private Label label7;

		// Token: 0x0400032C RID: 812
		private SiticoneButton siticoneButton1;

		// Token: 0x0400032D RID: 813
		private SiticoneLabel siticoneLabel3;

		// Token: 0x0400032E RID: 814
		private SiticoneTextBox siticoneTextBox1;

		// Token: 0x0400032F RID: 815
		private SiticoneLabel SiticoneLabel2;

		// Token: 0x04000330 RID: 816
		private SiticoneTextBox Username;

		// Token: 0x04000331 RID: 817
		private ToolStripMenuItem keySatınAlToolStripMenuItem;

		// Token: 0x04000332 RID: 818
		private ToolStripMenuItem güncelleToolStripMenuItem1;

		// Token: 0x04000333 RID: 819
		private ToolStripMenuItem girişYapToolStripMenuItem;

		// Token: 0x04000334 RID: 820
		private ToolStripMenuItem kayıtOlToolStripMenuItem;

		// Token: 0x04000335 RID: 821
		private ToolStripMenuItem güncelleToolStripMenuItem;

		// Token: 0x04000336 RID: 822
		private MenuStrip menuStrip1;

		// Token: 0x04000337 RID: 823
		private SiticoneDragControl siticoneDragControl1;

		// Token: 0x04000338 RID: 824
		private SiticoneDragControl siticoneDragControl2;

		// Token: 0x04000339 RID: 825
		private SiticoneDragControl siticoneDragControl3;

		// Token: 0x0400033A RID: 826
		private SiticoneDragControl siticoneDragControl4;

		// Token: 0x0400033B RID: 827
		private SiticoneDragControl siticoneDragControl5;

		// Token: 0x0400033C RID: 828
		private SiticoneDragControl siticoneDragControl6;

		// Token: 0x0400033D RID: 829
		private SiticoneCheckBox siticoneCheckBox2;

		// Token: 0x0400033E RID: 830
		private Label label9;

		// Token: 0x0400033F RID: 831
		private Label label11;

		// Token: 0x04000340 RID: 832
		private Label label6;

		// Token: 0x04000341 RID: 833
		private SiticoneLabel siticoneLabel6;

		// Token: 0x04000342 RID: 834
		private SiticoneLabel siticoneLabel8;

		// Token: 0x04000343 RID: 835
		private Label label10;

		// Token: 0x04000344 RID: 836
		private SiticoneImageButton siticoneImageButton3;

		// Token: 0x04000345 RID: 837
		private SiticoneButton siticoneButton6;

		// Token: 0x04000346 RID: 838
		private SiticoneRadioButton siticoneRadioButton1;

		// Token: 0x04000347 RID: 839
		private SiticoneRadioButton siticoneRadioButton2;

		// Token: 0x04000348 RID: 840
		private SiticoneLabel siticoneLabel9;

		// Token: 0x02000063 RID: 99
		public static class AsyncHelper
		{
			// Token: 0x0600097F RID: 2431
			public static extern void FireAndForget(Action action);

			// Token: 0x06000980 RID: 2432
			static extern bool \u202C\u200F\u206F\u202E\u206A\u202E\u202C\u202B\u200B\u200E\u202B\u200F\u200B\u206B\u202C\u202D\u202E\u206F\u206C\u200F\u206C\u202A\u202C\u202E\u202D\u202E\u206D\u200F\u202A\u202A\u202C\u206C\u206F\u202D\u206A\u202E\u202C\u206C\u200E\u206F\u202E(WaitCallback);
		}
	}
}
