﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Security.Principal;

namespace DijitalCyrpto
{
	// Token: 0x02000011 RID: 17
	public partial class MouseCursorTracker : Form
	{
		private readonly PictureBox pictureBox;
		private Bitmap bitmap;
		private Point lastMousePosition;
		private readonly Image redDotImage;
		private const int WS_EX_TRANSPARENT = 0x20;
		private const int WS_EX_LAYERED = 0x80000;
		private const int GWL_EXSTYLE = -20;
		private bool isDisposed;

		// Token: 0x06000097 RID: 151
		[DllImport("user32.dll", SetLastError = true)]
		private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

		// Token: 0x06000098 RID: 152
		[DllImport("user32.dll")]
		private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

		// Token: 0x06000099 RID: 153 RVA: 0x000053F8 File Offset: 0x000035F8
		public MouseCursorTracker()
		{
			if (!IsAdministrator())
			{
				throw new UnauthorizedAccessException("Bu uygulama yönetici hakları gerektirir.");
			}

			try
			{
				pictureBox = new PictureBox();
				redDotImage = CreateRedDot(10, 10);
				InitializeComponent();
				InitializeTracker();
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Form başlatma hatası: {ex.Message}", "Hata",
					MessageBoxButtons.OK, MessageBoxIcon.Error);
				throw;
			}
		}

		private bool IsAdministrator()
		{
			using (WindowsIdentity identity = WindowsIdentity.GetCurrent())
			{
				WindowsPrincipal principal = new WindowsPrincipal(identity);
				return principal.IsInRole(WindowsBuiltInRole.Administrator);
			}
		}

		private void InitializeComponent()
		{
			try
			{
				this.SuspendLayout();
				// 
				// MouseCursorTracker
				// 
				this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
				this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
				this.ClientSize = new System.Drawing.Size(800, 600);
				this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
				this.Name = "MouseTracker";
				this.Text = "Mouse Tracker";
				this.WindowState = FormWindowState.Maximized;
				this.TopMost = true;
				this.TransparencyKey = Color.Black;
				this.BackColor = Color.Black;
				this.ResumeLayout(false);
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Form başlatılırken hata oluştu: {ex.Message}", "Hata", 
					MessageBoxButtons.OK, MessageBoxIcon.Error);
				throw;
			}
		}

		private void InitializeTracker()
		{
			try
			{
				// Initialize PictureBox
				pictureBox.Dock = DockStyle.Fill;
				pictureBox.BackColor = Color.Transparent;
				pictureBox.SizeMode = PictureBoxSizeMode.Normal;
				this.Controls.Add(pictureBox);

				// Initialize bitmap
				bitmap = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);
				pictureBox.Image = bitmap;

				// Load red dot image
				try
				{
					redDotImage = Image.FromFile("reddot.png");
				}
				catch
				{
					// Create a default red dot if image file is not found
					redDotImage = CreateRedDot(10, 10);
				}

				// Set up mouse tracking
				this.MouseMove += MouseCursorTracker_MouseMove;

				// Make form click-through
				MakeClickThrough();
			}
			catch (Exception ex)
			{
				MessageBox.Show($"İzleyici başlatılırken hata oluştu: {ex.Message}", "Hata", 
					MessageBoxButtons.OK, MessageBoxIcon.Error);
				throw;
			}
		}

		private void MakeClickThrough()
		{
			try
			{
				int exStyle = GetWindowLong(this.Handle, GWL_EXSTYLE);
				exStyle |= (WS_EX_TRANSPARENT | WS_EX_LAYERED);
				SetWindowLong(this.Handle, GWL_EXSTYLE, exStyle);
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Pencere özelliği ayarlanırken hata oluştu: {ex.Message}", "Hata", 
					MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private Bitmap CreateRedDot(int width, int height)
		{
			var dot = new Bitmap(width, height);
			using (var g = Graphics.FromImage(dot))
			{
				g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
				g.Clear(Color.Transparent);
				using (var brush = new SolidBrush(Color.Red))
				{
					g.FillEllipse(brush, 0, 0, width - 1, height - 1);
				}
			}
			return dot;
		}

		private void MouseCursorTracker_MouseMove(object sender, MouseEventArgs e)
		{
			if (isDisposed) return;

			try
			{
				Point currentPosition = this.PointToClient(Cursor.Position);

				if (IsValidPosition(currentPosition) && !currentPosition.Equals(lastMousePosition))
				{
					using (var g = Graphics.FromImage(bitmap))
					{
						g.Clear(Color.Transparent);
						g.DrawImage(redDotImage,
							currentPosition.X - redDotImage.Width / 2,
							currentPosition.Y - redDotImage.Height / 2,
							redDotImage.Width,
							redDotImage.Height);
					}

					pictureBox.Invalidate();
					lastMousePosition = currentPosition;
					
					// Koordinatları başlıkta göster
					this.Text = $"Fare Pozisyonu: X = {currentPosition.X}, Y = {currentPosition.Y}";
				}
			}
			catch (Exception ex)
			{
				// Hata loglanabilir
				System.Diagnostics.Debug.WriteLine($"Fare hareketi izlenirken hata: {ex.Message}");
			}
		}

		private bool IsValidPosition(Point position)
		{
			return position.X >= 0 && position.X < Screen.PrimaryScreen.Bounds.Width &&
				   position.Y >= 0 && position.Y < Screen.PrimaryScreen.Bounds.Height;
		}

		protected override void OnFormClosing(FormClosingEventArgs e)
		{
			try
			{
				base.OnFormClosing(e);
				CleanupResources();
			}
			catch (Exception ex)
			{
				System.Diagnostics.Debug.WriteLine($"Form kapatılırken hata: {ex.Message}");
			}
		}

		private void CleanupResources()
		{
			if (isDisposed) return;

			try
			{
				if (bitmap != null)
				{
					bitmap.Dispose();
					bitmap = null;
				}

				if (redDotImage != null)
				{
					redDotImage.Dispose();
				}

				isDisposed = true;
			}
			catch (Exception ex)
			{
				System.Diagnostics.Debug.WriteLine($"Kaynaklar temizlenirken hata: {ex.Message}");
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (!isDisposed && disposing)
			{
				CleanupResources();
			}
			base.Dispose(disposing);
		}
	}
}
