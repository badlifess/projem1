﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Resources;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Siticone.UI.WinForms;
using Siticone.UI.WinForms.Enums;
using Siticone.UI.WinForms.Suite;

namespace FPSMACROx
{
	public partial class Form2 : Form
	{
		private readonly SecurityManager securityManager;
		private bool isRunning;
		private bool isHotkeyPressed;
		private bool isMinimized;
		
		// UI Components
		private SiticoneImageCheckBox checkBox1;
		private SiticoneImageCheckBox checkBox2;
		private SiticoneImageCheckBox checkBox3;
		private SiticoneImageCheckBox checkBox4;
		private SiticoneImageButton button1;
		private SiticoneImageButton button2;
		private SiticoneControlBox controlBox1;
		private SiticoneControlBox controlBox2;
		private SiticoneControlBox controlBox3;
		private NotifyIcon notifyIcon;
		private SiticoneDragControl dragControl;

		public Form2()
		{
			InitializeComponent();
			InitializeSecurity();
			InitializeUI();
			InitializeEventHandlers();
		}

		private void InitializeSecurity()
		{
			securityManager = new SecurityManager();
			securityManager.CheckSecurity();
		}

		private void InitializeUI()
		{
			// Initialize and configure UI components
			InitializeCheckBoxes();
			InitializeButtons();
			InitializeControlBoxes();
			InitializeNotifyIcon();
			InitializeDragControl();
			
			// Set form properties
			this.FormBorderStyle = FormBorderStyle.None;
			this.StartPosition = FormStartPosition.CenterScreen;
			this.Size = new Size(800, 600);
		}

		private void InitializeEventHandlers()
		{
			this.Load += Form2_Load;
			this.FormClosed += Form2_FormClosed;
			this.LocationChanged += Form2_LocationChanged;
			this.MouseUp += Form2_MouseUp;
			this.Shown += Form2_Shown;
		}

		private void Form2_Load(object sender, EventArgs e)
		{
			try
			{
				securityManager.CheckSecurity();
				InitializeSettings();
			}
			catch (Exception ex)
			{
				securityManager.LogError("Form2_Load", ex);
				MessageBox.Show("An error occurred while loading the form.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void Form2_FormClosed(object sender, FormClosedEventArgs e)
		{
			try
			{
				CleanupResources();
			}
			catch (Exception ex)
			{
				securityManager.LogError("Form2_FormClosed", ex);
			}
		}

		private void CleanupResources()
		{
			if (notifyIcon != null)
			{
				notifyIcon.Dispose();
			}
			
			if (components != null)
			{
				components.Dispose();
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				CleanupResources();
			}
			base.Dispose(disposing);
		}

		// ... existing code ...
	}
}
