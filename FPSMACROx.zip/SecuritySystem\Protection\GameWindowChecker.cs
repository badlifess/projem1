using System;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace SecuritySystem.Protection
{
    public static class GameWindowChecker
    {
        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

        private static readonly string[] AllowedTitles = new string[]
        {
            "Valorant", "CS2", "CSGO", "Apex", "Rust", "Fortnite"
        };

        public static void Initialize()
        {
            try
            {
                if (IsGameWindowActive())
                {
                    Utils.Logger.Log("Oyun penceresi tespit edildi, güvenlik önlemleri artırılıyor...");
                    // Oyun tespit edildiğinde ek güvenlik önlemleri uygulanabilir
                    IncreaseSecurityMeasures();
                }
                Utils.Logger.Log("Oyun penceresi kontrolü başarılı");
            }
            catch (Exception ex)
            {
                Utils.Logger.Log($"Oyun penceresi kontrolü hatası: {ex.Message}");
            }
        }

        public static bool IsGameWindowActive()
        {
            const int nChars = 256;
            StringBuilder Buff = new StringBuilder(nChars);
            IntPtr handle = GetForegroundWindow();

            if (GetWindowText(handle, Buff, nChars) > 0)
            {
                string activeTitle = Buff.ToString();
                return AllowedTitles.Any(t => activeTitle.IndexOf(t, StringComparison.OrdinalIgnoreCase) >= 0);
            }

            return false;
        }

        private static void IncreaseSecurityMeasures()
        {
            try
            {
                // Oyun tespit edildiğinde ek güvenlik önlemleri
                ScreenProtection.Initialize();
                KeyboardProtection.Initialize();
                ProcessProtection.Initialize();
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        public static void Cleanup()
        {
            // Temizlik işlemleri gerekirse burada yapılabilir
        }
    }
} 