using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace FPSMACROx
{
    public static class CodeObfuscator
    {
        private static readonly Dictionary<string, string> termMap = new Dictionary<string, string>
        {
            { "aimbot", "X7K9P2M4" },
            { "colorbot", "Y3R8N1L5" },
            { "aim", "Z4S6T9V2" },
            { "target", "A8B5C3D7" },
            { "mouse", "E2F4G6H8" },
            { "color", "I1J3K5L7" },
            { "detection", "M9N2P4R6" },
            { "scan", "S8T1U3V5" },
            { "purple", "W7X9Y2Z4" },
            { "pixel", "A6B8C1D3" },
            { "screen", "E5F7G9H2" },
            { "capture", "I4J6K8L1" },
            { "macro", "M3N5P7R9" },
            { "bot", "S2T4U6V8" },
            { "cheat", "W1X3Y5Z7" },
            { "hack", "A9B2C4D6" },
            { "security", "E8F1G3H5" },
            { "vanguard", "I7J9K2L4" },
            { "process", "M6N8P1R3" },
            { "memory", "S5T7U9V2" },
            { "injection", "W4X6Y8Z1" },
            { "debug", "A3B5C7D9" },
            { "virtual", "E2F4G6H8" },
            { "machine", "I1J3K5L7" },
            { "bypass", "B9Y2P4S6" },
            { "valorant", "V8A3L5O7" },
            { "anticheat", "A7N2T4C6" },
            { "detection", "D9E2T4C6" },
            { "hook", "H8O2O4K6" },
            { "inject", "I7N2J4C6" },
            { "kernel", "K8E2R4N6" },
            { "driver", "D7R2I4V6" },
            { "signature", "S8I2G4N6" },
            { "pattern", "P7A2T4N6" },
            { "scan", "S6C2A4N6" },
            { "memory", "M5E2M4O6" },
            { "process", "P4R2O4C6" },
            { "thread", "T3H2R4E6" },
            { "module", "M2O2D4U6" },
            { "dll", "D1L2L4" },
            { "api", "A9P2I4" },
            { "win32", "W8I2N4" },
            { "ntdll", "N7T2D4" },
            { "kernel32", "K6E2R4" },
            { "user32", "U5S2E4" },
            { "gdi32", "G4D2I4" },
            { "advapi32", "A3D2V4" },
            { "shell32", "S2H2E4" },
            { "ole32", "O1L2E4" },
            { "comdlg32", "C9O2M4" },
            { "ws2_32", "W8S2_4" },
            { "iphlpapi", "I7P2H4" },
            { "psapi", "P6S2A4" },
            { "version", "V5E2R4" },
            { "shlwapi", "S4H2L4" },
            { "crypt32", "C3R2Y4" },
            { "wtsapi32", "W2T2S4" },
            { "netapi32", "N1E2T4" }
        };

        private static readonly Dictionary<string, string> reverseMap = new Dictionary<string, string>();

        static CodeObfuscator()
        {
            foreach (var pair in termMap)
            {
                reverseMap[pair.Value] = pair.Key;
            }
        }

        public static string Obfuscate(string input)
        {
            if (string.IsNullOrEmpty(input)) return input;

            string result = input;
            foreach (var pair in termMap)
            {
                result = result.Replace(pair.Key, pair.Value);
            }
            return result;
        }

        public static string Deobfuscate(string input)
        {
            if (string.IsNullOrEmpty(input)) return input;

            string result = input;
            foreach (var pair in reverseMap)
            {
                result = result.Replace(pair.Key, pair.Value);
            }
            return result;
        }

        public static string GenerateRandomTerm(string baseTerm)
        {
            if (string.IsNullOrEmpty(baseTerm)) return baseTerm;

            byte[] bytes = new byte[8];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(bytes);
            }

            StringBuilder sb = new StringBuilder();
            foreach (byte b in bytes)
            {
                sb.Append((char)('A' + (b % 26)));
            }

            return sb.ToString();
        }
    }
} 