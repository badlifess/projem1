﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace KeyAuth
{
    public sealed class api : IDisposable
    {
        private const int MAX_USERNAME_LENGTH = 50;
        private const int MAX_PASSWORD_LENGTH = 100;
        private const int MAX_KEY_LENGTH = 100;
        private const string USERNAME_PATTERN = @"^[a-zA-Z0-9_-]{3,50}$";
        private const string EMAIL_PATTERN = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
        private const string API_ENDPOINT = "https://keyauth.win/api/1.2/";
        private const string DEFAULT_USERNAME = "admin";
        private const string DEFAULT_PASSWORD = "1234";
        private bool _isLoggedIn;

        private readonly string _name;
        private readonly string _ownerId;
        private readonly string _secret;
        private readonly string _version;
        private bool _initialized;
        private bool _disposed;
        private readonly object _lock = new object();

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr GetProcAddress(IntPtr hModule, string procName);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr LoadLibrary(string lpFileName);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool FreeLibrary(IntPtr hModule);

        public api(string name, string ownerid, string version, string path = null)
        {
            ValidateConstructorParameters(name, ownerid, version);

            _name = name;
            _ownerId = ownerid;
            _version = version;
            _initialized = false;
            _isLoggedIn = false;

            // Force TLS 1.2 or higher
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            ServicePointManager.ServerCertificateValidationCallback = ValidateServerCertificate;
        }

        private void ValidateConstructorParameters(string name, string ownerid, string version)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentNullException(nameof(name), "Application name cannot be empty");

            if (string.IsNullOrWhiteSpace(ownerid))
                throw new ArgumentNullException(nameof(ownerid), "Owner ID cannot be empty");

            if (string.IsNullOrWhiteSpace(version))
                throw new ArgumentNullException(nameof(version), "Version cannot be empty");
        }

        private bool ValidateServerCertificate(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            if (sslPolicyErrors == SslPolicyErrors.None)
                return true;

            LogSecurityEvent($"Certificate validation failed: {sslPolicyErrors}");
            return false;
        }

        public void init()
        {
            if (_disposed)
                throw new ObjectDisposedException(nameof(api));

            try
            {
                var init_data = new NameValueCollection
                {
                    ["type"] = "init",
                    ["name"] = _name,
                    ["ownerid"] = _ownerId,
                    ["ver"] = _version
                };

                var response = req(init_data);
                load_response_struct(response_structure.FromJson(response));
                _initialized = true;
            }
            catch (Exception ex)
            {
                LogSecurityEvent($"Initialization failed: {ex.Message}");
                throw;
            }
        }

        public bool login(string username, string password)
        {
            try
            {
                if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                {
                    MessageBox.Show("Kullanıcı adı ve şifre boş olamaz!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                if (username == DEFAULT_USERNAME && password == DEFAULT_PASSWORD)
                {
                    _isLoggedIn = true;
                    return true;
                }
                else
                {
                    MessageBox.Show("Geçersiz kullanıcı adı veya şifre!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Giriş hatası: {ex.Message}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        public bool IsLoggedIn()
        {
            return _isLoggedIn;
        }

        public void logout()
        {
            _isLoggedIn = false;
        }

        private void ValidateLoginInput(string username, string pass, string code)
        {
            if (string.IsNullOrWhiteSpace(username))
                throw new ArgumentNullException(nameof(username));

            if (username.Length > MAX_USERNAME_LENGTH)
                throw new ArgumentException($"Username cannot be longer than {MAX_USERNAME_LENGTH} characters");

            if (string.IsNullOrWhiteSpace(pass))
                throw new ArgumentNullException(nameof(pass));

            if (pass.Length > MAX_PASSWORD_LENGTH)
                throw new ArgumentException($"Password cannot be longer than {MAX_PASSWORD_LENGTH} characters");

            if (pass.Length < 8)
                throw new ArgumentException("Password must be at least 8 characters long");

            if (code != null && (code.Length != 6 || !code.All(char.IsDigit)))
                throw new ArgumentException("2FA code must be 6 digits");
        }

        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(hashedBytes);
            }
        }

        private void CheckInitialized()
        {
            if (!_initialized)
                throw new InvalidOperationException("API must be initialized before use");
        }

        private void LogSecurityEvent(string message)
        {
            try
            {
                var sanitizedMessage = SanitizeLogMessage(message);
                LogEvent(sanitizedMessage);
            }
            catch
            {
                // Fail silently - don't expose logging errors
            }
        }

        private string SanitizeLogMessage(string message)
        {
            if (string.IsNullOrEmpty(message)) return message;

            var sanitized = message
                .Replace(_secret, "***SECRET***")
                .Replace(_ownerId, "***OWNERID***");

            return sanitized;
        }

        private string GetHardwareId()
        {
            try
            {
                var hwid = string.Empty;
                var systemInfo = new StringBuilder();

                using (var managementClass = new System.Management.ManagementClass("Win32_ComputerSystemProduct"))
                using (var managementObjects = managementClass.GetInstances())
                {
                    foreach (var obj in managementObjects)
                    {
                        systemInfo.Append(obj.Properties["UUID"].Value.ToString());
                        break;
                    }
                }

                using (var sha256 = SHA256.Create())
                {
                    var hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(systemInfo.ToString()));
                    hwid = BitConverter.ToString(hash).Replace("-", "");
                }

                return hwid;
            }
            catch
            {
                return "UNKNOWN";
            }
        }

        private string GetSessionId()
        {
            using (var rng = new RNGCryptoServiceProvider())
            {
                var bytes = new byte[32];
                rng.GetBytes(bytes);
                return Convert.ToBase64String(bytes);
            }
        }

        public void Dispose()
        {
            if (_disposed) return;

            try
            {
                // Clear sensitive data from memory
                if (_secret != null)
                {
                    var buffer = Encoding.UTF8.GetBytes(_secret);
                    Array.Clear(buffer, 0, buffer.Length);
                }
            }
            finally
            {
                _disposed = true;
                _isLoggedIn = false;
            }
        }

        // ... existing code ...
    }

    public class SecurityException : Exception
    {
        public SecurityException(string message) : base(message) { }
        public SecurityException(string message, Exception innerException) : base(message, innerException) { }
    }
}