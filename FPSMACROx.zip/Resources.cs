﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;

namespace FPSMACROx.Properties
{
    // Token: 0x02000076 RID: 118
    [CompilerGenerated]
    [DebuggerNonUserCode]
    [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "17.0.0.0")]
    internal class Resources
    {
        // Token: 0x060009EE RID: 2542
        internal Resources()
        {
            // Placeholder for constructor logic if needed
        }

        // Token: 0x17000081 RID: 129
        [EditorBrowsable(EditorBrowsableState.Advanced)]
        internal static ResourceManager ResourceManager
        {
            get
            {
                if (resourceMan == null)
                {
                    resourceMan = new ResourceManager("FPSMACROx.Properties.Resources", typeof(Resources).Assembly);
                }
                return resourceMan;
            }
        }

        // Token: 0x17000082 RID: 130
        [EditorBrowsable(EditorBrowsableState.Advanced)]
        internal static CultureInfo Culture
        {
            get => resourceCulture;
            set => resourceCulture = value;
        }

        // Token: 0x17000083 RID: 131
        internal static Bitmap _1 => (Bitmap)ResourceManager.GetObject("_1", resourceCulture);

        // Token: 0x17000084 RID: 132
        internal static Bitmap _17_172351_afterburner_crosshair_crosshair_png => (Bitmap)ResourceManager.GetObject("_17_172351_afterburner_crosshair_crosshair_png", resourceCulture);

        // Token: 0x17000085 RID: 133
        internal static Bitmap _17_172351_afterburner_crosshair_crosshair_png1 => (Bitmap)ResourceManager.GetObject("_17_172351_afterburner_crosshair_crosshair_png1", resourceCulture);

        // Token: 0x17000086 RID: 134
        internal static Bitmap _2
        {
            get
            {
                // Placeholder for logic
                return null;
            }
        }

        // Token: 0x17000087 RID: 135
        internal static Bitmap _26_265154_target_cross_hair_hd_png_download_removebg_preview => (Bitmap)ResourceManager.GetObject("_26_265154_target_cross_hair_hd_png_download_removebg_preview", resourceCulture);

        // Token: 0x17000088 RID: 136
        internal static Bitmap _333w => (Bitmap)ResourceManager.GetObject("_333w", resourceCulture);

        // Token: 0x17000089 RID: 137
        internal static Bitmap _4 => (Bitmap)ResourceManager.GetObject("_4", resourceCulture);

        // Token: 0x1700008A RID: 138
        internal static Bitmap _555 => (Bitmap)ResourceManager.GetObject("_555", resourceCulture);

        // Token: 0x1700008B RID: 139
        internal static Bitmap _66 => (Bitmap)ResourceManager.GetObject("_66", resourceCulture);

        // Token: 0x1700008C RID: 140
        internal static Bitmap Ads2323ız => (Bitmap)ResourceManager.GetObject("Ads2323ız", resourceCulture);

        // Token: 0x1700008D RID: 141
        internal static Bitmap Ads2323ız1
        {
            get
            {
                // Placeholder for logic
                return null;
            }
        }

        // Token: 0x1700008E RID: 142
        internal static Bitmap aim => (Bitmap)ResourceManager.GetObject("aim", resourceCulture);

        // Token: 0x1700008F RID: 143
        internal static Bitmap aim1
        {
            get
            {
                // Placeholder for logic
                return null;
            }
        }

        // Token: 0x17000090 RID: 144
        internal static Bitmap Başlıksız_1
        {
            get
            {
                // Placeholder for logic
                return null;
            }
        }

        // Token: 0x17000091 RID: 145
        internal static Bitmap Başlıksız_4
        {
            get
            {
                // Placeholder for logic
                return null;
            }
        }

        // Token: 0x17000092 RID: 146
        internal static Bitmap bomb => (Bitmap)ResourceManager.GetObject("bomb", resourceCulture);

        // Token: 0x17000093 RID: 147
        internal static Bitmap brmömmm
        {
            get
            {
                // Placeholder for logic
                return null;
            }
        }

        // Token: 0x17000094 RID: 148
        internal static Bitmap crosshair1 => (Bitmap)ResourceManager.GetObject("crosshair1", resourceCulture);

        // Token: 0x17000095 RID: 149
        internal static Bitmap dondurmaa
        {
            get
            {
                // Placeholder for logic
                return null;
            }
        }

        // Token: 0x17000096 RID: 150
        internal static Bitmap Ek_Açıklama_2024_03_23_121240 => (Bitmap)ResourceManager.GetObject("Ek_Açıklama_2024_03_23_121240", resourceCulture);

        // Token: 0x17000097 RID: 151
        internal static Bitmap Ek_Açıklama_2024_03_23_124940
        {
            get
            {
                // Placeholder for logic
                return null;
            }
        }

        // Token: 0x17000098 RID: 152
        internal static Bitmap Ek_Açıklama_2024_03_23_124940_removebg_preview
        {
            get
            {
                // Placeholder for logic
                return null;
            }
        }

        // Token: 0x17000099 RID: 153
        internal static Bitmap Ek_Açıklama_2024_11_03_052916_removebg_preview
        {
            get
            {
                // Placeholder for logic
                return null;
            }
        }

        // Token: 0x1700009A RID: 154
        internal static Bitmap Ek_Açıklama_2024_11_03_104847 => (Bitmap)ResourceManager.GetObject("Ek_Açıklama_2024_11_03_104847", resourceCulture);

        // Token: 0x1700009B RID: 155
        internal static Bitmap Ek_Açıklama_2024_11_04_033932 => (Bitmap)ResourceManager.GetObject("Ek_Açıklama_2024_11_04_033932", resourceCulture);

        // Token: 0x1700009C RID: 156
        internal static Bitmap harita1 => (Bitmap)ResourceManager.GetObject("harita1", resourceCulture);

        // Token: 0x1700009D RID: 157
        internal static Bitmap kayyy => (Bitmap)ResourceManager.GetObject("kayyy", resourceCulture);

        // Token: 0x1700009E RID: 158
        internal static Bitmap ok => (Bitmap)ResourceManager.GetObject("ok", resourceCulture);

        // Token: 0x1700009F RID: 159
        internal static Bitmap pngaaa_com_2290433 => (Bitmap)ResourceManager.GetObject("pngaaa_com_2290433", resourceCulture);

        // Token: 0x170000A0 RID: 160
        internal static Bitmap rmg12 => (Bitmap)ResourceManager.GetObject("rmg12", resourceCulture);

        // Token: 0x170000A1 RID: 161
        internal static Bitmap rmö => (Bitmap)ResourceManager.GetObject("rmö", resourceCulture);

        // Token: 0x170000A2 RID: 162
        internal static Bitmap sexx
        {
            get
            {
                // Placeholder for logic
                return null;
            }
        }

        // Token: 0x170000A3 RID: 163
        internal static Bitmap silah => (Bitmap)ResourceManager.GetObject("silah", resourceCulture);

        // Token: 0x170000A4 RID: 164
        internal static Bitmap silah2 => (Bitmap)ResourceManager.GetObject("silah2", resourceCulture);

        // Token: 0x170000A5 RID: 165
        internal static Bitmap sovvvvv => (Bitmap)ResourceManager.GetObject("sovvvvv", resourceCulture);

        // Token: 0x170000A6 RID: 166
        internal static Bitmap tattt => (Bitmap)ResourceManager.GetObject("tattt", resourceCulture);

        // Token: 0x170000A7 RID: 167
        internal static Bitmap viper => (Bitmap)ResourceManager.GetObject("viper", resourceCulture);

        // Token: 0x170000A8 RID: 168
        internal static Bitmap Viper_Artwork => (Bitmap)ResourceManager.GetObject("Viper_Artwork", resourceCulture);

        // Token: 0x170000A9 RID: 169
        internal static Bitmap vp => (Bitmap)ResourceManager.GetObject("vp", resourceCulture);

        private static ResourceManager resourceMan;
        private static CultureInfo resourceCulture;
    }
}