﻿using System;

/// <summary>
/// A custom attribute that might be used for metadata purposes.
/// </summary>
internal class ConfusedByAttribute : Attribute
{
    /// <summary>
    /// Constructor that accepts a message or identifier.
    /// </summary>
    /// <param name="message">A message or identifier for the attribute.</param>
    public ConfusedByAttribute(string message)
    {
        Message = message;
    }

    /// <summary>
    /// Gets the message or identifier associated with the attribute.
    /// </summary>
    public string Message { get; }
}