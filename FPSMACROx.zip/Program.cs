﻿using System;
using System.Windows.Forms;
using System.Security.Principal;
using System.Diagnostics;
using System.Threading;
using System.IO;

namespace FPSMACROx
{
    /// <summary>
    /// Entry point for the KeyAuth Windows Forms application.
    /// </summary>
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        private static void Main()
        {
            try
            {
                // Anti-detection sistemini başlat
                AntiDetection.Initialize();

                // Güvenlik kontrolleri
                if (!IsAdministrator())
                {
                    MessageBox.Show("Bu uygulama yönetici hakları gerektirir.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Anti-debug kontrolü
                if (IsDebuggerAttached())
                {
                    Environment.Exit(0);
                    return;
                }

                // Uygulama başlatma
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                
                // Güvenlik yöneticisini başlat
                SecurityManager.Instance.Initialize();
                
                // Ana formu başlat
                Application.Run(new Form1());
            }
            catch (Exception ex)
            {
                LogError(ex);
                MessageBox.Show("Uygulama başlatılırken bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static bool IsAdministrator()
        {
            using (WindowsIdentity identity = WindowsIdentity.GetCurrent())
            {
                WindowsPrincipal principal = new WindowsPrincipal(identity);
                return principal.IsInRole(WindowsBuiltInRole.Administrator);
            }
        }

        private static bool IsDebuggerAttached()
        {
            return Debugger.IsAttached;
        }

        private static void LogError(Exception ex)
        {
            try
            {
                string logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "error.log");
                File.AppendAllText(logPath, $"[{DateTime.Now}] {ex.Message}\n{ex.StackTrace}\n\n");
            }
            catch
            {
                // Log yazma hatası göz ardı edilir
            }
        }

        // Güvenli metodlar
        private static void InitializeSecurity()
        {
            try
            {
                // Güvenlik başlatma işlemleri
                SecurityManager.Instance.Initialize();
                AntiDetection.Initialize();
            }
            catch (Exception ex)
            {
                LogError(ex);
            }
        }

        private static void HandleSecurityViolation(string context)
        {
            try
            {
                LogError(new Exception($"Güvenlik ihlali: {context}"));
                Environment.Exit(0);
            }
            catch
            {
                Environment.Exit(0);
            }
        }

        private static void CleanupResources()
        {
            try
            {
                // Kaynakları temizle
                SecurityManager.Instance.Dispose();
            }
            catch { }
        }
    }

    /// <summary>
    /// Represents the main form for the application.
    /// Replace this with the actual main form implementation.
    /// </summary>
    public class MainForm : Form
    {
        public MainForm()
        {
            // Initialize the form
            Text = "KeyAuth Application";
            Width = 800;
            Height = 600;
        }
    }
}