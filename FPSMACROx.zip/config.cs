﻿using System;
using System.Windows.Forms;

namespace SecurityConfig
{
    /// <summary>
    /// Holds configuration settings for the application, including sensitivity, screen resolution, and control states.
    /// </summary>
    public static class Config
    {
        // Screen settings
        public static string Id;
        public static int FovX;
        public static int FovY;
        public static int ScreenWidth;
        public static int ScreenHeight;

        // Sensitivity settings
        public static double Sensitivity;
        public static double SensitivityX;
        public static double SensitivityY;

        // Smoothness and aim settings
        public static bool SmoothState;
        public static double Smooth;
        public static bool FlickActive;
        public static Keys FlickKey;
        public static bool SilentActive;
        public static Keys SilentKey;
        public static bool AimOnlyOnXAxis;
        public static bool AutoAttackEnabled;
        public static Keys AimKey;
        public static bool AutoFireState;
        public static double AimbotSmoothness;

        // Extra settings
        public static int Extras;
        public static bool CheckAutoFire;

        /// <summary>
        /// Calculates horizontal sensitivity based on user settings.
        /// </summary>
        /// <param name="sensitivity">The base sensitivity.</param>
        /// <param name="smooth">The smoothness factor.</param>
        /// <param name="fov">The field of view.</param>
        /// <returns>Calculated horizontal sensitivity.</returns>
        public static double CalculateSensitivityX(double sensitivity, double smooth, double fov)
        {
            try
            {
                // Example calculation logic for sensitivity
                return sensitivity * (1 + smooth / 100) * (90 / fov);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error calculating sensitivity X: {ex.Message}");
                return 0;
            }
        }

        /// <summary>
        /// Calculates vertical sensitivity based on user settings.
        /// </summary>
        /// <param name="sensitivity">The base sensitivity.</param>
        /// <param name="smooth">The smoothness factor.</param>
        /// <param name="fov">The field of view.</param>
        /// <returns>Calculated vertical sensitivity.</returns>
        public static double CalculateSensitivityY(double sensitivity, double smooth, double fov)
        {
            try
            {
                // Example calculation logic for sensitivity
                return sensitivity * (1 + smooth / 100) * (90 / fov);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error calculating sensitivity Y: {ex.Message}");
                return 0;
            }
        }
    }
}