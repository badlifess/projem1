﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DistanceMeter
{
	// Token: 0x0200002E RID: 46
	public partial class MeterForm : Form
	{
		// Token: 0x0600027C RID: 636
		[DllImport("user32.dll", SetLastError = true)]
		private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

		// Token: 0x0600027D RID: 637
		[DllImport("user32.dll")]
		private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

		// Token: 0x0600027E RID: 638
		public extern MeterForm();

		// Token: 0x0600027F RID: 639 RVA: 0x00006434 File Offset: 0x00004634
		private void HideBtn_Click(object sender, EventArgs e)
		{
			/*
An exception occurred when decompiling this method (0600027F)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void DistanceMeter.MeterForm::HideBtn_Click(System.Object,System.EventArgs)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000280 RID: 640
		private extern void ProjectileBtn_Click(object sender, EventArgs e);

		// Token: 0x06000281 RID: 641
		private extern void MoveBtn_Click(object sender, EventArgs e);

		// Token: 0x06000282 RID: 642
		private extern void MeterForm_Paint(object sender, PaintEventArgs e);

		// Token: 0x06000283 RID: 643
		public extern string osmanbey();

		// Token: 0x06000284 RID: 644
		private static extern double HesaplaMesafe2(Point nokta1, Point nokta2);

		// Token: 0x06000285 RID: 645
		private static extern int HesaplaMesafe(Point nokta1, Point nokta2);

		// Token: 0x06000286 RID: 646 RVA: 0x00006470 File Offset: 0x00004670
		private static Point FindSariRenkKoordinati(Bitmap bitmap)
		{
			/*
An exception occurred when decompiling this method (06000286)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Drawing.Point DistanceMeter.MeterForm::FindSariRenkKoordinati(System.Drawing.Bitmap)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000287 RID: 647 RVA: 0x000064A8 File Offset: 0x000046A8
		private static Point FindInsanSilüetiKoordinati(Bitmap bitmap)
		{
			/*
An exception occurred when decompiling this method (06000287)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Drawing.Point DistanceMeter.MeterForm::FindInsanSilüetiKoordinati(System.Drawing.Bitmap)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000288 RID: 648 RVA: 0x000064DC File Offset: 0x000046DC
		private void MeterForm_MouseClick(object sender, MouseEventArgs e)
		{
			/*
An exception occurred when decompiling this method (06000288)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void DistanceMeter.MeterForm::MeterForm_MouseClick(System.Object,System.Windows.Forms.MouseEventArgs)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000289 RID: 649
		private extern List<int> GetCurrentDistances();

		// Token: 0x0600028A RID: 650
		private extern void MeterForm_Load(object sender, EventArgs e);

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x0600028B RID: 651
		protected override extern CreateParams CreateParams { get; }

		// Token: 0x0600028C RID: 652 RVA: 0x00006528 File Offset: 0x00004728
		public static void yap2(double angleToSpike, double distanceToSpike)
		{
			/*
An exception occurred when decompiling this method (0600028C)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void DistanceMeter.MeterForm::yap2(System.Double,System.Double)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600028D RID: 653
		[return: TupleElementNames(new string[]
		{
			"distance",
			"angle"
		})]
		public static extern ValueTuple<double, double> CalculateDistanceToSpike(Point spikeCoords);

		// Token: 0x0600028E RID: 654
		public static extern bool IsColorMatch(Color pixelColor, Color targetColor, int tolerance);

		// Token: 0x0600028F RID: 655
		public static extern Point? FindSpike(Bitmap screenshot, Color targetColor);

		// Token: 0x06000290 RID: 656 RVA: 0x0000654C File Offset: 0x0000474C
		public static Task yap()
		{
			/*
An exception occurred when decompiling this method (06000290)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Threading.Tasks.Task DistanceMeter.MeterForm::yap()

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000294 RID: 660
		static extern PictureBox \u200B\u202E\u206B\u206B\u202C\u202A\u202C\u200F\u200D\u206B\u206C\u200E\u200F\u200C\u206C\u200B\u200D\u202E\u206A\u206B\u206F\u206D\u206A\u200F\u200B\u202A\u206D\u206F\u206C\u200E\u200E\u202E\u206E\u206A\u206F\u202D\u206C\u202C\u206C\u200C\u202E();

		// Token: 0x06000295 RID: 661
		static extern void \u206D\u200E\u206E\u202C\u202B\u200D\u202D\u206D\u202E\u206F\u202A\u206C\u206D\u200C\u206C\u200D\u206F\u206C\u206F\u206D\u200C\u202A\u200E\u206F\u206A\u202E\u206D\u202A\u200E\u206E\u200C\u202E\u202D\u200C\u202D\u206C\u206A\u206C\u200F\u206E\u202E(Form, FormBorderStyle);

		// Token: 0x06000296 RID: 662 RVA: 0x00005440 File Offset: 0x00003640
		static void \u206C\u206A\u206C\u206C\u202A\u206F\u202D\u202B\u200C\u206F\u200E\u200C\u206A\u202E\u200B\u202D\u200C\u206D\u200C\u206A\u202D\u202E\u206D\u202B\u200D\u206C\u200E\u206A\u206A\u202C\u202E\u206B\u200E\u200D\u200D\u206C\u202E\u202B\u206A\u206D\u202E(Form, FormWindowState)
		{
			/*
An exception occurred when decompiling this method (06000296)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void DistanceMeter.MeterForm::⁬⁪⁬⁬‪⁯‭‫‌⁯‎‌⁪‮​‭‌⁭‌⁪‭‮⁭‫‍⁬‎⁪⁪‬‮⁫‎‍‍⁬‮‫⁪⁭‮(System.Windows.Forms.Form,System.Windows.Forms.FormWindowState)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000297 RID: 663
		static extern void \u200D\u206C\u202B\u200C\u206B\u200F\u202B\u202E\u206F\u200C\u206E\u202A\u206A\u200C\u200F\u202E\u200F\u202C\u206A\u206D\u200F\u200F\u202B\u206F\u200E\u206E\u206D\u200D\u202A\u206C\u206B\u206D\u200C\u206D\u200E\u202D\u206C\u200B\u202A\u206D\u202E(Control, Color);

		// Token: 0x06000298 RID: 664 RVA: 0x00005464 File Offset: 0x00003664
		static void \u206F\u200E\u200C\u202A\u200E\u202A\u206F\u200E\u202C\u202B\u202D\u200D\u206E\u200E\u202C\u206A\u206D\u202A\u202E\u206C\u202C\u202D\u202C\u200E\u200E\u200C\u206C\u200E\u200E\u206B\u206F\u202E\u206D\u206E\u206F\u206F\u200D\u200B\u202B\u200F\u202E(Form, Color)
		{
			/*
An exception occurred when decompiling this method (06000298)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void DistanceMeter.MeterForm::⁯‎‌‪‎‪⁯‎‬‫‭‍⁮‎‬⁪⁭‪‮⁬‬‭‬‎‎‌⁬‎‎⁫⁯‮⁭⁮⁯⁯‍​‫‏‮(System.Windows.Forms.Form,System.Drawing.Color)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x06000299 RID: 665
		static extern void \u202E\u200B\u206B\u206D\u206C\u206E\u200F\u206E\u206F\u202D\u202B\u202B\u206A\u202D\u202A\u206B\u200E\u206E\u200C\u200E\u200E\u200D\u206F\u206F\u206A\u200E\u202A\u200E\u202D\u206E\u206E\u206C\u200E\u202E\u200C\u202E\u200E\u200D\u206F\u202D\u202E(Form, bool);

		// Token: 0x0600029A RID: 666
		static extern Button \u202C\u202C\u202E\u200E\u202B\u206C\u200C\u200F\u200E\u200C\u206D\u206E\u206F\u206E\u200E\u200C\u200D\u200F\u200D\u200B\u202D\u202B\u200F\u206D\u200B\u202E\u206D\u206D\u200D\u206F\u202C\u202B\u200F\u202A\u206A\u206A\u202C\u206E\u206F\u202D\u202E();

		// Token: 0x0600029B RID: 667 RVA: 0x00006564 File Offset: 0x00004764
		static void \u200C\u200F\u200D\u206A\u206E\u200E\u206A\u200F\u200C\u200F\u206E\u206A\u206E\u206B\u202C\u206C\u202C\u202C\u206A\u200F\u202D\u202C\u200D\u206A\u206C\u202E\u206D\u200C\u206E\u202B\u202E\u202D\u206C\u202C\u206C\u206D\u202D\u202B\u200B\u206C\u202E(Control, string)
		{
			/*
An exception occurred when decompiling this method (0600029B)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void DistanceMeter.MeterForm::‌‏‍⁪⁮‎⁪‏‌‏⁮⁪⁮⁫‬⁬‬‬⁪‏‭‬‍⁪⁬‮⁭‌⁮‫‮‭⁬‬⁬⁭‭‫​⁬‮(System.Windows.Forms.Control,System.String)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600029C RID: 668 RVA: 0x0000659C File Offset: 0x0000479C
		static void \u206C\u206C\u200D\u202E\u200B\u200C\u202C\u200B\u202D\u206F\u200E\u200C\u200D\u206E\u202A\u200B\u202E\u200F\u202B\u200F\u202C\u200F\u202D\u206A\u206B\u200D\u206F\u200D\u200B\u202C\u200B\u200C\u206B\u200F\u206B\u202A\u206F\u202E\u200D\u202D\u202E(Control, Point)
		{
			/*
An exception occurred when decompiling this method (0600029C)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Void DistanceMeter.MeterForm::⁬⁬‍‮​‌‬​‭⁯‎‌‍⁮‪​‮‏‫‏‬‏‭⁪⁫‍⁯‍​‬​‌⁫‏⁫‪⁯‮‍‭‮(System.Windows.Forms.Control,System.Drawing.Point)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x0600029D RID: 669
		static extern void \u206C\u206C\u200C\u200F\u206C\u202E\u200F\u206D\u200D\u206F\u202A\u206B\u202A\u202E\u200F\u206F\u206D\u202E\u206A\u202E\u206F\u206F\u206E\u206E\u206C\u200B\u200C\u200C\u206A\u206C\u202D\u206A\u200F\u200D\u206E\u202C\u206F\u202E\u200E\u206A\u202E(Control, Size);

		// Token: 0x0600029E RID: 670
		static extern void \u202B\u200B\u202C\u200D\u206D\u202A\u200D\u206A\u200E\u200B\u200D\u200D\u202A\u206F\u202A\u206A\u202A\u200D\u200B\u200B\u200E\u202C\u200C\u202C\u200F\u202B\u206B\u200F\u202B\u200D\u200C\u202B\u202C\u200D\u202C\u206E\u200D\u202D\u200E\u200E\u202E(Control, EventHandler);

		// Token: 0x0600029F RID: 671
		static extern void \u200B\u200D\u202A\u206E\u202B\u206C\u200D\u206B\u200B\u202C\u206A\u200C\u206B\u206C\u202D\u202C\u200C\u202D\u202A\u206C\u202E\u202E\u206A\u200E\u206C\u202A\u206E\u206B\u202E\u206F\u200E\u206E\u202D\u200F\u202E\u206F\u202E\u206A\u200C\u202D\u202E(Control, MouseEventHandler);

		// Token: 0x060002A0 RID: 672
		static extern void \u206A\u206D\u202A\u202E\u202A\u206E\u200C\u206C\u202E\u200B\u200B\u206F\u206C\u206A\u206C\u200E\u202C\u206E\u206D\u206B\u200E\u200C\u206C\u202C\u200D\u200C\u200D\u200F\u200C\u206C\u200D\u206F\u200D\u202C\u200E\u206A\u206B\u200F\u200F\u202D\u202E(Control, PaintEventHandler);

		// Token: 0x060002A1 RID: 673
		static extern void \u202E\u200D\u200B\u206F\u206F\u206A\u206A\u206A\u206E\u200E\u206B\u202E\u206B\u200E\u206B\u200C\u200D\u206E\u200E\u206A\u206D\u202B\u200F\u202B\u206B\u206A\u206A\u202D\u206D\u202B\u200F\u206D\u202A\u206E\u202D\u206D\u200E\u206B\u202C\u200C\u202E(Control);

		// Token: 0x060002A2 RID: 674
		static extern bool \u202A\u206A\u200C\u200B\u202D\u206B\u202E\u202A\u202A\u200C\u202D\u200D\u200B\u206B\u200E\u202C\u200B\u202D\u200D\u206F\u200B\u206A\u206E\u200B\u200D\u200B\u206F\u202C\u200F\u206E\u206B\u200C\u206E\u200E\u202E\u202E\u200C\u206C\u206A\u202E(string, string);

		// Token: 0x060002A3 RID: 675 RVA: 0x000065E0 File Offset: 0x000047E0
		static bool \u200D\u206C\u200F\u202C\u202E\u200D\u202C\u200C\u206B\u200D\u202D\u202D\u202D\u200F\u202D\u206E\u206F\u202A\u202A\u206D\u206B\u200E\u206A\u202D\u202B\u202E\u200F\u200B\u202B\u206C\u200E\u202D\u206D\u202E\u206F\u202B\u200B\u206D\u200D\u202E(IEnumerator)
		{
			/*
An exception occurred when decompiling this method (060002A3)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Boolean DistanceMeter.MeterForm::‍⁬‏‬‮‍‬‌⁫‍‭‭‭‏‭⁮⁯‪‪⁭⁫‎⁪‭‫‮‏​‫⁬‎‭⁭‮⁯‫​⁭‍‮(System.Collections.IEnumerator)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060002A4 RID: 676
		static extern void \u202D\u206C\u202D\u200F\u202B\u206D\u206E\u206B\u206E\u202C\u206D\u200F\u200C\u206B\u202A\u202A\u206D\u206D\u200C\u200C\u202B\u202A\u200D\u202B\u200C\u202B\u202B\u200B\u200F\u200C\u206D\u202C\u200F\u206A\u202B\u206F\u206A\u206D\u202D\u206C\u202E(IEnumerator);

		// Token: 0x060002A5 RID: 677
		static extern Screen \u206F\u200E\u202B\u206F\u206B\u206B\u200B\u200E\u206F\u202A\u206A\u200E\u206B\u202C\u202B\u202D\u200D\u206E\u206B\u206E\u200B\u200D\u202A\u202E\u200E\u200B\u206D\u200E\u200C\u206A\u200E\u202C\u202E\u202A\u206A\u200D\u202C\u200E\u206A\u200E\u202E();

		// Token: 0x060002A6 RID: 678
		static extern Rectangle \u202B\u206C\u202D\u200E\u206A\u200F\u202E\u202C\u200E\u202D\u200F\u202C\u202E\u200E\u200C\u202D\u200F\u202A\u206D\u200B\u206E\u200E\u206A\u200B\u206D\u206C\u206E\u206C\u206D\u202A\u202A\u200F\u200D\u202E\u200E\u206F\u206A\u206D\u206B\u206C\u202E(Screen);

		// Token: 0x060002A7 RID: 679
		static extern Bitmap \u200C\u200E\u206E\u206A\u206D\u202D\u206C\u200D\u206D\u206B\u206A\u206D\u206F\u200C\u200B\u206B\u200F\u200B\u206B\u206C\u206B\u200D\u200B\u200D\u202C\u206F\u206A\u202C\u206D\u202A\u206D\u206F\u206F\u206D\u202E\u206E\u202C\u202E\u206A\u202C\u202E(int, int);

		// Token: 0x060002A8 RID: 680
		static extern Graphics \u206D\u200B\u206C\u202B\u200C\u202E\u200F\u206E\u200B\u206B\u200F\u200C\u202E\u206C\u200F\u206B\u206E\u200D\u202B\u202A\u202B\u206A\u206F\u200C\u200D\u202E\u206B\u206B\u200B\u202B\u200F\u206E\u206E\u200C\u206A\u206A\u206B\u202B\u206D\u202B\u202E(Image);

		// Token: 0x060002A9 RID: 681
		static extern void \u200E\u200B\u206E\u200B\u200E\u200C\u200B\u206C\u206D\u200F\u200C\u200D\u200D\u202E\u206E\u202A\u200D\u206E\u206C\u202D\u206F\u206B\u206A\u206F\u200B\u202D\u202C\u200C\u202C\u200B\u200C\u206F\u200D\u202B\u206A\u200E\u206A\u206D\u202B\u202E(Graphics, int, int, int, int, Size, CopyPixelOperation);

		// Token: 0x060002AA RID: 682
		static extern void \u202C\u206B\u206A\u206D\u202D\u202D\u202A\u206C\u206E\u202D\u202B\u206C\u200B\u206A\u202B\u200C\u202E\u202C\u200C\u202D\u206D\u200B\u200C\u206A\u206C\u202C\u202B\u202B\u206A\u200D\u206E\u202B\u202D\u206C\u200D\u202A\u200B\u200E\u206D\u202A\u202E(IDisposable);

		// Token: 0x060002AB RID: 683
		static extern string \u206E\u200D\u202D\u202D\u202E\u206F\u200F\u206A\u206E\u206C\u206E\u206B\u202C\u206E\u200F\u200C\u200D\u202A\u202D\u202D\u202A\u200B\u206C\u202A\u206A\u206D\u202C\u200D\u200B\u206F\u206C\u202C\u202B\u202A\u206D\u200B\u202A\u202D\u200F\u202C\u202E(string, object);

		// Token: 0x060002AC RID: 684
		static extern double \u202D\u202A\u206A\u202E\u206F\u206B\u206E\u206D\u202E\u200C\u202B\u202E\u202E\u202E\u206E\u206D\u202E\u206A\u202C\u202D\u202C\u202B\u202D\u200C\u200B\u202D\u200E\u206B\u202E\u200E\u206D\u202E\u200C\u206E\u202C\u206E\u206A\u202D\u200E\u206A\u202E(double, double);

		// Token: 0x060002AD RID: 685 RVA: 0x0000661C File Offset: 0x0000481C
		static double \u200E\u202A\u200F\u206C\u202C\u202D\u202C\u200C\u206C\u202C\u202A\u200F\u206F\u206A\u202D\u202B\u202B\u202B\u200D\u202A\u206B\u206E\u200D\u200C\u200F\u200E\u202E\u200C\u200E\u202A\u206C\u202C\u202E\u200E\u202B\u202A\u206C\u206D\u202B\u202E\u202E(double)
		{
			/*
An exception occurred when decompiling this method (060002AD)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Double DistanceMeter.MeterForm::‎‪‏⁬‬‭‬‌⁬‬‪‏⁯⁪‭‫‫‫‍‪⁫⁮‍‌‏‎‮‌‎‪⁬‬‮‎‫‪⁬⁭‫‮‮(System.Double)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060002AE RID: 686 RVA: 0x00006668 File Offset: 0x00004868
		static double \u200F\u206D\u206B\u206F\u202B\u206F\u206A\u202B\u206C\u200B\u200F\u206C\u206F\u206A\u200C\u206F\u206C\u202A\u200F\u202C\u202A\u200C\u202A\u202A\u202E\u202B\u200E\u200C\u202E\u206F\u200C\u202A\u202B\u200B\u200F\u206E\u202E\u202C\u206F\u200C\u202E(double)
		{
			/*
An exception occurred when decompiling this method (060002AE)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Double DistanceMeter.MeterForm::‏⁭⁫⁯‫⁯⁪‫⁬​‏⁬⁯⁪‌⁯⁬‪‏‬‪‌‪‪‮‫‎‌‮⁯‌‪‫​‏⁮‮‬⁯‌‮(System.Double)

 ---> System.ArgumentOutOfRangeException: Non-negative number required. (Parameter 'length')
   at System.Array.Copy(Array sourceArray, Int32 sourceIndex, Array destinationArray, Int32 destinationIndex, Int32 length, Boolean reliable)
   at System.Array.Copy(Array sourceArray, Array destinationArray, Int32 length)
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 48
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060002AF RID: 687
		static extern Color \u202C\u206C\u200D\u200C\u206F\u200F\u202C\u206A\u202C\u200B\u202C\u206A\u200D\u206A\u202D\u202B\u206A\u200B\u202E\u202B\u206C\u206D\u200E\u206D\u200C\u206C\u206C\u202C\u200C\u200D\u202C\u202B\u202C\u206E\u206B\u206B\u202B\u202B\u202E\u202D\u202E(Bitmap, int, int);

		// Token: 0x060002B0 RID: 688
		static extern int \u206B\u206A\u206C\u202C\u206E\u200C\u206E\u200E\u206B\u200B\u206B\u200C\u202D\u206A\u200C\u206A\u202E\u206A\u206D\u202D\u200F\u200B\u202E\u202D\u202D\u206C\u206B\u200B\u206F\u200F\u206E\u206D\u206F\u206C\u200C\u206A\u200E\u200E\u206B\u200E\u202E(int);

		// Token: 0x060002B1 RID: 689
		static extern int \u206E\u206F\u202E\u200C\u200B\u206F\u206C\u202A\u200D\u206F\u206F\u202C\u200B\u206C\u206D\u202A\u202A\u200F\u202A\u206E\u206F\u202B\u206B\u202E\u200E\u206E\u206B\u202D\u200F\u200B\u200F\u206B\u202C\u200C\u202C\u200E\u200F\u200F\u206D\u202E\u202E(Image);

		// Token: 0x060002B2 RID: 690
		static extern int \u202C\u202E\u202A\u200C\u200E\u200F\u200D\u206F\u206C\u206F\u206B\u206C\u200B\u202C\u200E\u206F\u202B\u200B\u206E\u202D\u206A\u202A\u202C\u202E\u202B\u206C\u200E\u202B\u206A\u202C\u206E\u202E\u206C\u200E\u206A\u206D\u206B\u202A\u206E\u202E\u202E(Image);

		// Token: 0x060002B3 RID: 691
		static extern Exception \u202E\u206C\u206A\u200F\u202D\u200C\u200C\u202E\u206F\u202C\u200D\u200B\u206D\u206C\u202B\u200C\u200E\u202C\u202C\u206E\u206C\u200F\u200B\u200F\u202D\u202E\u202C\u202A\u206B\u206B\u206F\u200D\u200B\u202D\u200E\u206F\u202A\u200B\u206F\u206C\u202E(string);

		// Token: 0x060002B4 RID: 692
		static extern string \u200D\u206A\u202B\u202E\u202C\u202D\u202A\u202D\u206F\u202A\u202A\u200B\u206D\u206E\u206D\u206A\u200E\u202B\u200E\u202B\u202C\u202A\u206B\u202D\u200C\u200B\u200D\u200C\u202B\u206B\u206F\u206A\u200B\u200E\u206D\u200B\u200E\u202D\u200D\u206F\u202E(string, string);

		// Token: 0x060002B5 RID: 693
		extern IntPtr \u206A\u206D\u206D\u202D\u206A\u206A\u202C\u206F\u206B\u200B\u200D\u200C\u206D\u206D\u206E\u206C\u202B\u200C\u206A\u200D\u200F\u202E\u200F\u202E\u206B\u202D\u206B\u206F\u206E\u202A\u206A\u206E\u202B\u206F\u200F\u200D\u200E\u200C\u202A\u202B\u202E();

		// Token: 0x060002B6 RID: 694 RVA: 0x00006698 File Offset: 0x00004898
		static int \u200E\u202D\u202C\u206D\u202D\u200D\u200F\u206A\u202A\u202A\u206D\u206E\u200F\u206A\u200F\u202E\u200B\u200E\u200F\u206E\u206D\u206A\u206F\u206B\u200B\u200E\u202A\u200F\u202D\u206F\u202C\u202C\u206F\u206B\u206C\u202C\u202E\u202C\u202B\u202B\u202E(CreateParams)
		{
			/*
An exception occurred when decompiling this method (060002B6)

ICSharpCode.Decompiler.DecompilerException: Error decompiling System.Int32 DistanceMeter.MeterForm::‎‭‬⁭‭‍‏⁪‪‪⁭⁮‏⁪‏‮​‎‏⁮⁭⁪⁯⁫​‎‪‏‭⁯‬‬⁯⁫⁬‬‮‬‫‫‮(System.Windows.Forms.CreateParams)

 ---> System.OverflowException: Arithmetic operation resulted in an overflow.
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackSlot.ModifyStack(StackSlot[] stack, Int32 popCount, Int32 pushCount, ByteCode pushDefinition) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 47
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.StackAnalysis(MethodDef methodDef) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 387
   at ICSharpCode.Decompiler.ILAst.ILAstBuilder.Build(MethodDef methodDef, Boolean optimize, DecompilerContext context) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\ILAst\ILAstBuilder.cs:line 269
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(IEnumerable`1 parameters, MethodDebugInfoBuilder& builder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 112
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 88
   --- End of inner exception stack trace ---
   at ICSharpCode.Decompiler.Ast.AstMethodBodyBuilder.CreateMethodBody(MethodDef methodDef, DecompilerContext context, AutoPropertyProvider autoPropertyProvider, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, StringBuilder sb, MethodDebugInfoBuilder& stmtsBuilder) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstMethodBodyBuilder.cs:line 92
   at ICSharpCode.Decompiler.Ast.AstBuilder.AddMethodBody(EntityDeclaration methodNode, EntityDeclaration& updatedNode, MethodDef method, IEnumerable`1 parameters, Boolean valueParameterIsKeyword, MethodKind methodKind) in D:\a\dnSpy\dnSpy\Extensions\ILSpy.Decompiler\ICSharpCode.Decompiler\ICSharpCode.Decompiler\Ast\AstBuilder.cs:line 1533
*/;
		}

		// Token: 0x060002B7 RID: 695
		static extern void \u202B\u200D\u202E\u202A\u202C\u206B\u206E\u202C\u202C\u206C\u202C\u206A\u206F\u200E\u200D\u202D\u202C\u202A\u202A\u200F\u206D\u206F\u206B\u206F\u206F\u206A\u200C\u206F\u206A\u202E\u200E\u200C\u202C\u206D\u202E\u200F\u202A\u202B\u206F\u202C\u202E(CreateParams, int);

		// Token: 0x060002B8 RID: 696
		static extern double \u202B\u202B\u206E\u200E\u202D\u206E\u200F\u202E\u206D\u206D\u202C\u206E\u200E\u206B\u206A\u200E\u206D\u200C\u202D\u200F\u206B\u200D\u206F\u206A\u206A\u206B\u202E\u206F\u202D\u206C\u200E\u202E\u206E\u202B\u206F\u200F\u202D\u202C\u200D\u200D\u202E(double);

		// Token: 0x060002B9 RID: 697
		static extern void \u200C\u202C\u202C\u202A\u206D\u206F\u206B\u206A\u206C\u206F\u202E\u200C\u206E\u206B\u206A\u200F\u206A\u200D\u200D\u202E\u206B\u206A\u200E\u206F\u206D\u202D\u206E\u202A\u200D\u200E\u200F\u200E\u200D\u206D\u202E\u206C\u200B\u206C\u202C\u202B\u202E(string);

		// Token: 0x060002BA RID: 698
		static extern double \u206D\u200C\u200D\u206D\u206B\u202D\u202D\u200B\u202A\u206F\u200C\u206C\u206A\u202B\u200F\u206E\u200E\u206B\u202A\u206C\u202D\u200D\u200F\u200F\u206E\u200D\u202D\u202E\u200B\u202A\u200C\u206E\u206D\u206C\u200E\u206B\u200E\u202C\u200B\u202A\u202E(double, double);

		// Token: 0x060002BB RID: 699
		static extern int \u206B\u206C\u200B\u200B\u202E\u206D\u202D\u200F\u206B\u202D\u202D\u202D\u202A\u206B\u206A\u200C\u200E\u200F\u200B\u206E\u202B\u200D\u200F\u206A\u202A\u206B\u200F\u200F\u206D\u200F\u206F\u200D\u206B\u202C\u206F\u200B\u202D\u206B\u202E\u206D\u202E(int, int);

		// Token: 0x040000A8 RID: 168
		private const int WS_EX_TRANSPARENT = 32;

		// Token: 0x040000A9 RID: 169
		private const int WS_EX_LAYERED = 524288;

		// Token: 0x040000AA RID: 170
		private const uint WS_EX_CLICKTHROUGH = 32U;

		// Token: 0x040000AB RID: 171
		private const int GWL_EXSTYLE = -20;

		// Token: 0x040000AC RID: 172
		private bool isVisible;

		// Token: 0x040000AD RID: 173
		private string projectType;

		// Token: 0x040000AE RID: 174
		private string moveType;

		// Token: 0x040000AF RID: 175
		private readonly Button hideBtn;

		// Token: 0x040000B0 RID: 176
		private readonly Button projectileBtn;

		// Token: 0x040000B1 RID: 177
		private readonly Button moveBtn;

		// Token: 0x040000B2 RID: 178
		private IEnumerator<string> moveList;

		// Token: 0x040000B3 RID: 179
		private readonly Dictionary<string, List<int>> distances;

		// Token: 0x040000B4 RID: 180
		private PictureBox pictureBox;

		// Token: 0x040000B5 RID: 181
		private Point xCoordinate;

		// Token: 0x040000B6 RID: 182
		private string ALINANDEGER;

		// Token: 0x040000B7 RID: 183
		private static Color unplantedSpikeRgb;

		// Token: 0x040000B8 RID: 184
		private static double valorantSensitivity;

		// Token: 0x040000B9 RID: 185
		private static Point playerCoords;

		// Token: 0x040000BA RID: 186
		private static double mapDistanceMultiplier;

		// Token: 0x040000BB RID: 187
		private static double ascentMultiplier;

		// Token: 0x040000BC RID: 188
		private static double bindMultiplier;

		// Token: 0x040000BD RID: 189
		private static double breezeMultiplier;

		// Token: 0x040000BE RID: 190
		private static double fractureMultiplier;

		// Token: 0x040000BF RID: 191
		private static double havenMultiplier;

		// Token: 0x040000C0 RID: 192
		private static double iceboxMultiplier;

		// Token: 0x040000C1 RID: 193
		private static double lotusMultiplier;

		// Token: 0x040000C2 RID: 194
		private static double pearlMultiplier;

		// Token: 0x040000C3 RID: 195
		private static double splitMultiplier;

		// Token: 0x040000C4 RID: 196
		private static double sunsetMultiplier;

		// Token: 0x040000C5 RID: 197
		private static Color unplantedSpikeRgb2;

		// Token: 0x040000C6 RID: 198
		private static Color plantedSpikeRgb;

		// Token: 0x040000C7 RID: 199
		private static int tolerance;

		// Token: 0x040000C8 RID: 200
		private static string xFile;

		// Token: 0x040000C9 RID: 201
		private static string dotFile;

		// Token: 0x040000CA RID: 202
		private static string resultString;
	}
}
