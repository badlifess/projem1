﻿using System;
using System.Windows.Forms;
using System.Threading.Tasks;
using AntiCrack_DotNet;

namespace DijitalCyrpto
{
    internal static class MainFunction
    {
        private static SecurityManager securityManager;
        private static MouseController mouseController;
        private static bool isInitialized = false;
        private static bool isRunning = true;

        [STAThread]
        public static void Main(string[] args)
        {
            try
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);

                Initialize();

                if (!isInitialized)
                {
                    MessageBox.Show("Uygulama başlatılamadı.", "Hata", 
                                  MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Güvenlik izlemesini arka planda başlat
                Task.Run(() => MonitorSecurity());

                // Ana formu başlat
                Application.Run(new MouseCursorTracker());
            }
            catch (UnauthorizedAccessException ex)
            {
                MessageBox.Show("Bu uygulama yönetici hakları gerektirir.", "Yetki Hatası",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Beklenmeyen bir hata oluştu: {ex.Message}", "Hata",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                isRunning = false;
                Cleanup();
            }
        }

        private static void Initialize()
        {
            try
            {
                // Güvenlik yöneticisini başlat
                securityManager = SecurityManager.Instance;

                // Fare kontrolcüsünü başlat
                mouseController = MouseController.Instance;

                isInitialized = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Başlatma hatası: {ex.Message}", "Hata",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static async Task MonitorSecurity()
        {
            while (isRunning)
            {
                try
                {
                    // Periyodik güvenlik kontrolleri
                    await Task.Delay(1000); // Her saniye kontrol et
                    
                    if (securityManager == null)
                    {
                        isRunning = false;
                        break;
                    }
                }
                catch (Exception ex)
                {
                    // Güvenlik önlemleri gizli tutulmalı
                    System.Diagnostics.Debug.WriteLine($"Güvenlik izleme hatası: {ex.Message}");
                }
            }
        }

        private static void Cleanup()
        {
            try
            {
                if (mouseController != null)
                {
                    mouseController.Dispose();
                    mouseController = null;
                }

                if (securityManager != null)
                {
                    (securityManager as IDisposable)?.Dispose();
                    securityManager = null;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Temizleme hatası: {ex.Message}");
            }
        }
    }
}
