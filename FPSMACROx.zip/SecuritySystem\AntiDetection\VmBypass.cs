using System;
using System.Management;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace SecuritySystem.AntiDetection
{
    public static class VmBypass
    {
        private static readonly string[] VmSignatures = new[]
        {
            "VMware",
            "VBox",
            "VIRTUAL",
            "QEMU",
            "Virtual"
        };

        public static void Initialize()
        {
            try
            {
                CleanRegistryTraces();
                ModifyVmDrivers();
                CleanHardwareTraces();
                CleanMemoryTraces();

                Utils.Logger.Log("VM bypass başarıyla başlatıldı");
            }
            catch (Exception ex)
            {
                Utils.Logger.Log($"VM bypass hatası: {ex.Message}");
            }
        }

        private static void CleanRegistryTraces()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services", true))
                {
                    if (key == null) return;

                    foreach (string subKeyName in key.GetSubKeyNames())
                    {
                        if (IsVmSignature(subKeyName))
                        {
                            try
                            {
                                key.DeleteSubKeyTree(subKeyName);
                            }
                            catch
                            {
                                // Hata durumunda sessizce devam et
                            }
                        }
                    }
                }
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        private static void ModifyVmDrivers()
        {
            try
            {
                using (var searcher = new ManagementObjectSearcher("SELECT * FROM Win32_SystemDriver"))
                {
                    foreach (ManagementObject driver in searcher.Get())
                    {
                        string driverName = driver["Name"].ToString();
                        if (IsVmSignature(driverName))
                        {
                            try
                            {
                                driver["StartMode"] = "Disabled";
                                driver.Put();
                            }
                            catch
                            {
                                // Hata durumunda sessizce devam et
                            }
                        }
                    }
                }
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        private static void CleanHardwareTraces()
        {
            try
            {
                using (var searcher = new ManagementObjectSearcher("SELECT * FROM Win32_ComputerSystem"))
                {
                    foreach (ManagementObject system in searcher.Get())
                    {
                        string manufacturer = system["Manufacturer"].ToString();
                        string model = system["Model"].ToString();

                        if (IsVmSignature(manufacturer) || IsVmSignature(model))
                        {
                            try
                            {
                                system["Manufacturer"] = "Dell Inc.";
                                system["Model"] = "Precision 5550";
                                system.Put();
                            }
                            catch
                            {
                                // Hata durumunda sessizce devam et
                            }
                        }
                    }
                }
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        private static void CleanMemoryTraces()
        {
            try
            {
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        private static bool IsVmSignature(string value)
        {
            if (string.IsNullOrEmpty(value)) return false;
            
            foreach (string signature in VmSignatures)
            {
                if (value.Contains(signature))
                    return true;
            }
            
            return false;
        }
    }
} 