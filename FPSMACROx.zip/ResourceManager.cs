using System;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Security.Cryptography;

namespace FPSMACROx
{
    public class ResourceManager
    {
        private static readonly object _lock = new object();
        private static bool _isInitialized;

        public static void Initialize()
        {
            if (_isInitialized) return;

            lock (_lock)
            {
                if (_isInitialized) return;

                try
                {
                    // DLL dosyasını yükle
                    LoadDll();

                    // PDB dosyasını yükle
                    LoadPdb();

                    _isInitialized = true;
                }
                catch (Exception ex)
                {
                    // Hata durumunda sessizce devam et
                }
            }
        }

        private static void LoadDll()
        {
            try
            {
                string dllPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "dll.compressed");
                if (File.Exists(dllPath))
                {
                    byte[] compressedData = File.ReadAllBytes(dllPath);
                    byte[] decompressedData = Decompress(compressedData);
                    
                    // DLL'yi yükle
                    Assembly.Load(decompressedData);
                }
            }
            catch { }
        }

        private static void LoadPdb()
        {
            try
            {
                string pdbPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "pdb.compressed");
                if (File.Exists(pdbPath))
                {
                    byte[] compressedData = File.ReadAllBytes(pdbPath);
                    byte[] decompressedData = Decompress(compressedData);
                    
                    // PDB'yi yükle
                    // PDB yükleme işlemleri...
                }
            }
            catch { }
        }

        private static byte[] Decompress(byte[] data)
        {
            try
            {
                using (MemoryStream input = new MemoryStream(data))
                using (MemoryStream output = new MemoryStream())
                {
                    using (GZipStream decompressionStream = new GZipStream(input, CompressionMode.Decompress))
                    {
                        decompressionStream.CopyTo(output);
                    }
                    return output.ToArray();
                }
            }
            catch
            {
                return new byte[0];
            }
        }

        public static string CalculateFileHash(string filePath)
        {
            try
            {
                using (SHA256 sha256 = SHA256.Create())
                using (FileStream stream = File.OpenRead(filePath))
                {
                    byte[] hash = sha256.ComputeHash(stream);
                    return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
                }
            }
            catch
            {
                return string.Empty;
            }
        }
    }
} 