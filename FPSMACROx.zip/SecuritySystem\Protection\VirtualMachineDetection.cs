using System;
using System.Management;
using System.Runtime.InteropServices;

namespace SecuritySystem.Protection
{
    public static class VirtualMachineDetection
    {
        [DllImport("kernel32.dll")]
        private static extern IntPtr GetModuleHandle(string lpModuleName);

        public static void Initialize()
        {
            try
            {
                if (IsRunningInVM())
                {
                    Utils.Logger.Log("Sanal makine tespit edildi!");
                    Environment.Exit(0);
                }
                Utils.Logger.Log("Sanal makine kontrolü başarılı");
            }
            catch (Exception ex)
            {
                Utils.Logger.Log($"Sanal makine kontrolü hatası: {ex.Message}");
            }
        }

        private static bool IsRunningInVM()
        {
            try
            {
                // BIOS bilgilerini kontrol et
                using (var searcher = new ManagementObjectSearcher("Select * from Win32_BIOS"))
                {
                    foreach (var item in searcher.Get())
                    {
                        string bios = item["Manufacturer"].ToString().ToLower();
                        if (bios.Contains("vmware") || bios.Contains("virtualbox") || bios.Contains("qemu"))
                            return true;
                    }
                }

                // CPU bilgilerini kontrol et
                using (var searcher = new ManagementObjectSearcher("Select * from Win32_Processor"))
                {
                    foreach (var item in searcher.Get())
                    {
                        string cpu = item["Manufacturer"].ToString().ToLower();
                        if (cpu.Contains("vmware") || cpu.Contains("virtualbox") || cpu.Contains("qemu"))
                            return true;
                    }
                }

                // VMWare DLL'lerini kontrol et
                if (GetModuleHandle("vmGuestLib.dll") != IntPtr.Zero ||
                    GetModuleHandle("VBoxMouse.sys") != IntPtr.Zero ||
                    GetModuleHandle("VBoxGuest.sys") != IntPtr.Zero)
                {
                    return true;
                }

                return false;
            }
            catch
            {
                return false;
            }
        }
    }
} 