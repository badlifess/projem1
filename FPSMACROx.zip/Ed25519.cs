﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Numerics;
using System.Security.Cryptography;
using System.Linq;

namespace Cryptographic
{
    // Token: 0x02000031 RID: 49
    public class Ed25519
    {
        // Token: 0x060002D0 RID: 720
        private static byte[] ComputeHash(byte[] m)
        {
            using (SHA512 sha512 = SHA512.Create())
            {
                return sha512.ComputeHash(m);
            }
        }

        // Token: 0x060002D1 RID: 721
        private static BigInteger ExpMod(BigInteger number, BigInteger exponent, BigInteger modulo)
        {
            return BigInteger.ModPow(number, exponent, modulo);
        }

        // Token: 0x060002D2 RID: 722
        private static BigInteger Inv(BigInteger x)
        {
            return BigInteger.ModPow(x, Q - 2, Q); // Modular multiplicative inverse using Fermat's Little Theorem
        }

        // Token: 0x060002D3 RID: 723
        private static BigInteger RecoverX(BigInteger y)
        {
            // Placeholder implementation for recovering X from Y
            return BigInteger.Zero;
        }

        // Token: 0x060002D4 RID: 724
        private static Tuple<BigInteger, BigInteger> Edwards(BigInteger px, BigInteger py, BigInteger qx, BigInteger qy)
        {
            BigInteger x1y2 = (px * qy) % Q;
            BigInteger y1x2 = (py * qx) % Q;
            BigInteger dx1x2y1y2 = (D * px * qx * py * qy) % Q;

            BigInteger x3Num = (x1y2 + y1x2) % Q;
            BigInteger x3Den = (Un + dx1x2y1y2) % Q;
            BigInteger y3Num = (py * qy - px * qx) % Q;
            BigInteger y3Den = (Un - dx1x2y1y2) % Q;

            if (x3Den == 0 || y3Den == 0)
                throw new InvalidOperationException("Division by zero in Edwards addition");

            BigInteger x3 = (x3Num * Inv(x3Den)) % Q;
            BigInteger y3 = (y3Num * Inv(y3Den)) % Q;

            return Tuple.Create(x3, y3);
        }

        // Token: 0x060002D5 RID: 725
        private static Tuple<BigInteger, BigInteger> EdwardsSquare(BigInteger x, BigInteger y)
        {
            return Edwards(x, y, x, y);
        }

        // Token: 0x060002D6 RID: 726
        private static Tuple<BigInteger, BigInteger> ScalarMul(Tuple<BigInteger, BigInteger> point, BigInteger scalar)
        {
            if (scalar == 0)
                return Tuple.Create(BigInteger.Zero, BigInteger.One);

            Tuple<BigInteger, BigInteger> q = ScalarMul(point, scalar / 2);
            q = EdwardsSquare(q.Item1, q.Item2);

            if (scalar % 2 == 1)
                q = Edwards(q.Item1, q.Item2, point.Item1, point.Item2);

            return q;
        }

        // Token: 0x060002D7 RID: 727
        public static byte[] EncodeInt(BigInteger y)
        {
            return y.ToByteArray();
        }

        // Token: 0x060002D8 RID: 728
        public static byte[] EncodePoint(BigInteger x, BigInteger y)
        {
            byte[] encoded = new byte[32];
            byte[] temp = y.ToByteArray();
            int length = Math.Min(temp.Length, 32);
            Array.Copy(temp, 0, encoded, 0, length);
            
            if (x % 2 == 1)
                encoded[31] |= 0x80;
                
            return encoded;
        }

        // Token: 0x060002D9 RID: 729
        private static int GetBit(byte[] h, int i)
        {
            int byteIndex = i / 8;
            int bitIndex = i % 8;
            return (h[byteIndex] >> bitIndex) & 1;
        }

        // Token: 0x060002DA RID: 730
        public static byte[] PublicKey(byte[] signingKey)
        {
            if (signingKey == null || signingKey.Length != 32)
                throw new ArgumentException("Signing key must be 32 bytes");

            byte[] h = ComputeHash(signingKey);
            h[0] &= 248;
            h[31] &= 127;
            h[31] |= 64;

            BigInteger a = DecodeInt(h);
            Tuple<BigInteger, BigInteger> A = ScalarMul(B, a);

            return EncodePoint(A.Item1, A.Item2);
        }

        // Token: 0x060002DB RID: 731
        private static BigInteger HashInt(byte[] m)
        {
            byte[] hash = ComputeHash(m);
            return new BigInteger(hash);
        }

        // Token: 0x060002DC RID: 732
        public static byte[] Signature(byte[] message, byte[] signingKey, byte[] publicKey)
        {
            if (message == null) throw new ArgumentNullException(nameof(message));
            if (signingKey == null || signingKey.Length != 32) throw new ArgumentException("Invalid signing key", nameof(signingKey));
            if (publicKey == null || publicKey.Length != 32) throw new ArgumentException("Invalid public key", nameof(publicKey));

            byte[] h = ComputeHash(signingKey);
            h[0] &= 248;
            h[31] &= 127;
            h[31] |= 64;

            byte[] r = ComputeHash(h.Skip(32).Concat(message).ToArray());
            BigInteger rScalar = HashInt(r) % L;
            Tuple<BigInteger, BigInteger> R = ScalarMul(B, rScalar);
            byte[] encodedR = EncodePoint(R.Item1, R.Item2);

            byte[] k = ComputeHash(encodedR.Concat(publicKey).Concat(message).ToArray());
            BigInteger s = (HashInt(k) * DecodeInt(h) + rScalar) % L;

            byte[] signature = new byte[64];
            Array.Copy(encodedR, 0, signature, 0, 32);
            Array.Copy(EncodeInt(s), 0, signature, 32, 32);

            return signature;
        }

        // Token: 0x060002DD RID: 733
        private static bool IsOnCurve(BigInteger x, BigInteger y)
        {
            BigInteger xx = (x * x) % Q;
            BigInteger yy = (y * y) % Q;
            BigInteger dxxyy = (D * xx * yy) % Q;
            return (yy - xx - Un - dxxyy) % Q == 0;
        }

        // Token: 0x060002DE RID: 734
        private static BigInteger DecodeInt(byte[] s)
        {
            return new BigInteger(s);
        }

        // Token: 0x060002DF RID: 735
        private static Tuple<BigInteger, BigInteger> DecodePoint(byte[] pointBytes)
        {
            if (pointBytes == null || pointBytes.Length != 32)
                throw new ArgumentException("Invalid point encoding");

            bool xOdd = (pointBytes[31] & 0x80) != 0;
            pointBytes[31] &= 0x7F;

            BigInteger y = new BigInteger(pointBytes);
            if (y >= Q)
                throw new ArgumentException("Y coordinate is too large");

            BigInteger y2 = (y * y) % Q;
            BigInteger x2 = (y2 - Un) * Inv((Un + D * y2)) % Q;
            
            if (x2 == 0 && xOdd)
                throw new ArgumentException("Invalid point encoding");

            BigInteger x = RecoverX(x2);
            if ((x % 2 == 0) != !xOdd)
                x = Q - x;

            return Tuple.Create(x, y);
        }

        // Token: 0x060002E0 RID: 736
        public static bool CheckValid(byte[] signature, byte[] message, byte[] publicKey)
        {
            if (signature == null || signature.Length != 64) return false;
            if (message == null) return false;
            if (publicKey == null || publicKey.Length != 32) return false;

            try
            {
                byte[] R = new byte[32];
                Array.Copy(signature, 0, R, 0, 32);
                byte[] s = new byte[32];
                Array.Copy(signature, 32, s, 0, 32);

                Tuple<BigInteger, BigInteger> A = DecodePoint(publicKey);
                if (!IsOnCurve(A.Item1, A.Item2)) return false;

                byte[] h = ComputeHash(R.Concat(publicKey).Concat(message).ToArray());
                BigInteger k = HashInt(h) % L;

                Tuple<BigInteger, BigInteger> sB = ScalarMul(B, DecodeInt(s));
                Tuple<BigInteger, BigInteger> kA = ScalarMul(A, k);
                Tuple<BigInteger, BigInteger> R2 = Edwards(sB.Item1, sB.Item2, kA.Item1, -kA.Item2);

                return EncodePoint(R2.Item1, R2.Item2).SequenceEqual(R);
            }
            catch
            {
                return false;
            }
        }

        // Token: 0x060002E1 RID: 737
        public Ed25519()
        {
            // Constructor placeholder
        }

        // Token: 0x040000D2 RID: 210
        private static readonly Dictionary<BigInteger, BigInteger> InverseCache = new Dictionary<BigInteger, BigInteger>();

        // Token: 0x040000D3 RID: 211
        private const int BitLength = 256;

        // Token: 0x040000D4 RID: 212
        private static readonly BigInteger TwoPowBitLengthMinusTwo = BigInteger.Pow(2, BitLength - 2);

        // Token: 0x040000D5 RID: 213
        private static readonly BigInteger[] TwoPowCache = new BigInteger[BitLength];

        // Token: 0x040000D6 RID: 214
        private static readonly BigInteger Q = BigInteger.Parse("7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFED", System.Globalization.NumberStyles.HexNumber);

        // Token: 0x040000D7 RID: 215
        private static readonly BigInteger Qm2 = Q - 2;

        // Token: 0x040000D8 RID: 216
        private static readonly BigInteger Qp3 = Q + 3;

        // Token: 0x040000D9 RID: 217
        private static readonly BigInteger L = BigInteger.Parse("1000000000000000000000000000000013", System.Globalization.NumberStyles.HexNumber);

        // Token: 0x040000DA RID: 218
        private static readonly BigInteger D = BigInteger.Parse("-121665 / 121666 mod Q", System.Globalization.NumberStyles.AllowLeadingSign);

        // Token: 0x040000DB RID: 219
        private static readonly BigInteger I = BigInteger.ModPow(2, (Q - 1) / 4, Q);

        // Token: 0x040000DC RID: 220
        private static readonly BigInteger By = BigInteger.Parse("4 / 5 mod Q", System.Globalization.NumberStyles.AllowLeadingSign);

        // Token: 0x040000DD RID: 221
        private static readonly BigInteger Bx = BigInteger.ModPow(By * By - 1, (Q + 3) / 8, Q);

        // Token: 0x040000DE RID: 222
        private static readonly Tuple<BigInteger, BigInteger> B = Tuple.Create(Bx, By);

        // Token: 0x040000DF RID: 223
        private static readonly BigInteger Un = BigInteger.One;

        // Token: 0x040000E0 RID: 224
        private static readonly BigInteger Two = BigInteger.One + BigInteger.One;

        // Token: 0x040000E1 RID: 225
        private static readonly BigInteger Eight = Two * Two * Two;
    }
}