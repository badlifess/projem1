using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;

namespace FPSMACROx
{
    public class GameController : IDisposable
    {
        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        private static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

        [StructLayout(LayoutKind.Sequential)]
        private struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        private readonly object captureLock = new object();
        private bool isRunning;
        private Thread captureThread;
        private Rectangle gameWindow;
        private Color targetColor;
        private int tolerance;
        private int scanRadius;
        private float smoothness;
        private float prediction;

        public GameController()
        {
            isRunning = false;
            targetColor = Color.Purple;
            tolerance = 10;
            scanRadius = 50;
            smoothness = 0.5f;
            prediction = 0.5f;
        }

        public void Start()
        {
            if (!isRunning)
            {
                lock (captureLock)
                {
                    if (!isRunning)
                    {
                        isRunning = true;
                        captureThread = new Thread(CaptureLoop)
                        {
                            IsBackground = true
                        };
                        captureThread.Start();
                    }
                }
            }
        }

        public void Stop()
        {
            if (isRunning)
            {
                lock (captureLock)
                {
                    if (isRunning)
                    {
                        isRunning = false;
                        captureThread?.Join();
                    }
                }
            }
        }

        private void CaptureLoop()
        {
            while (isRunning)
            {
                try
                {
                    UpdateGameWindow();
                    if (gameWindow.Width > 0 && gameWindow.Height > 0)
                    {
                        using (var bitmap = CaptureScreen())
                        {
                            ProcessImage(bitmap);
                        }
                    }
                    Thread.Sleep(1);
                }
                catch (Exception)
                {
                    // Hata durumunda sessizce devam et
                }
            }
        }

        private void UpdateGameWindow()
        {
            try
            {
                IntPtr hWnd = GetForegroundWindow();
                if (hWnd != IntPtr.Zero)
                {
                    RECT rect;
                    if (GetWindowRect(hWnd, out rect))
                    {
                        gameWindow = new Rectangle(
                            rect.Left,
                            rect.Top,
                            rect.Right - rect.Left,
                            rect.Bottom - rect.Top
                        );
                    }
                }
            }
            catch (Exception)
            {
                // Hata durumunda sessizce devam et
            }
        }

        private Bitmap CaptureScreen()
        {
            try
            {
                var bitmap = new Bitmap(gameWindow.Width, gameWindow.Height, PixelFormat.Format32bppArgb);
                using (var graphics = Graphics.FromImage(bitmap))
                {
                    graphics.CopyFromScreen(gameWindow.Left, gameWindow.Top, 0, 0, gameWindow.Size);
                }
                return bitmap;
            }
            catch (Exception)
            {
                return new Bitmap(1, 1);
            }
        }

        private void ProcessImage(Bitmap bitmap)
        {
            try
            {
                var centerX = bitmap.Width / 2;
                var centerY = bitmap.Height / 2;

                for (int y = centerY - scanRadius; y < centerY + scanRadius; y++)
                {
                    for (int x = centerX - scanRadius; x < centerX + scanRadius; x++)
                    {
                        if (x >= 0 && x < bitmap.Width && y >= 0 && y < bitmap.Height)
                        {
                            var pixel = bitmap.GetPixel(x, y);
                            if (IsColorMatch(pixel, targetColor))
                            {
                                // Renk eşleşmesi bulundu, işlem yap
                                return;
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                // Hata durumunda sessizce devam et
            }
        }

        private bool IsColorMatch(Color color1, Color color2)
        {
            try
            {
                return Math.Abs(color1.R - color2.R) <= tolerance &&
                       Math.Abs(color1.G - color2.G) <= tolerance &&
                       Math.Abs(color1.B - color2.B) <= tolerance;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public void SetTargetColor(Color color)
        {
            targetColor = color;
        }

        public void SetTolerance(int value)
        {
            tolerance = value;
        }

        public void SetScanRadius(int value)
        {
            scanRadius = value;
        }

        public void SetSmoothness(float value)
        {
            smoothness = value;
        }

        public void SetPrediction(float value)
        {
            prediction = value;
        }

        public void Dispose()
        {
            Stop();
        }
    }
} 