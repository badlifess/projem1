using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace FPSMACROx
{
    public class E5F7G9H2
    {
        [DllImport("user32.dll")]
        private static extern IntPtr GetDesktopWindow();

        [DllImport("user32.dll")]
        private static extern IntPtr GetWindowDC(IntPtr hWnd);

        [DllImport("gdi32.dll")]
        private static extern IntPtr CreateCompatibleDC(IntPtr hDC);

        [DllImport("gdi32.dll")]
        private static extern IntPtr CreateCompatibleBitmap(IntPtr hDC, int nWidth, int nHeight);

        [DllImport("gdi32.dll")]
        private static extern IntPtr SelectObject(IntPtr hDC, IntPtr hObject);

        [DllImport("gdi32.dll")]
        private static extern bool BitBlt(IntPtr hObject, int nXDest, int nYDest, int nWidth, int nHeight, IntPtr hObjectSource, int nXSrc, int nYSrc, int dwRop);

        [DllImport("gdi32.dll")]
        private static extern IntPtr DeleteObject(IntPtr hObject);

        [DllImport("gdi32.dll")]
        private static extern IntPtr DeleteDC(IntPtr hDC);

        [DllImport("user32.dll")]
        private static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);

        private const int SRCCOPY = 0x00CC0020;

        public async Task<Bitmap> CaptureScreenAsync()
        {
            return await Task.Run(() =>
            {
                try
                {
                    IntPtr hWnd = GetDesktopWindow();
                    IntPtr hDC = GetWindowDC(hWnd);
                    IntPtr hMemDC = CreateCompatibleDC(hDC);

                    int width = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width;
                    int height = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height;

                    IntPtr hBitmap = CreateCompatibleBitmap(hDC, width, height);
                    IntPtr hOld = SelectObject(hMemDC, hBitmap);

                    BitBlt(hMemDC, 0, 0, width, height, hDC, 0, 0, SRCCOPY);

                    Bitmap bitmap = Image.FromHbitmap(hBitmap);

                    SelectObject(hMemDC, hOld);
                    DeleteObject(hBitmap);
                    DeleteDC(hMemDC);
                    ReleaseDC(hWnd, hDC);

                    return bitmap;
                }
                catch
                {
                    return null;
                }
            });
        }
    }
} 