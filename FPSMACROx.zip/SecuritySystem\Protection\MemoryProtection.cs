using System;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace SecuritySystem.Protection
{
    public static class MemoryProtection
    {
        [DllImport("kernel32.dll")]
        private static extern bool VirtualProtect(IntPtr lpAddress, uint dwSize, uint flNewProtect, out uint lpflOldProtect);

        [DllImport("kernel32.dll")]
        private static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport("kernel32.dll")]
        private static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

        private const uint PAGE_EXECUTE_READWRITE = 0x40;
        private const uint PAGE_EXECUTE_READ = 0x20;

        public static void Initialize()
        {
            try
            {
                ProtectProcessMemory();
                ProtectModuleMemory();
                PreventMemoryScanning();
                ObfuscateMemoryRegions();

                Utils.Logger.Log("Bellek koruması başarıyla başlatıldı");
            }
            catch (Exception ex)
            {
                Utils.Logger.Log($"Bellek koruma hatası: {ex.Message}");
            }
        }

        private static void ProtectProcessMemory()
        {
            try
            {
                Process currentProcess = Process.GetCurrentProcess();
                foreach (ProcessModule module in currentProcess.Modules)
                {
                    VirtualProtect(module.BaseAddress, (uint)module.ModuleMemorySize, PAGE_EXECUTE_READWRITE, out uint _);
                }
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        private static void ProtectModuleMemory()
        {
            try
            {
                IntPtr moduleHandle = GetModuleHandle(null);
                if (moduleHandle != IntPtr.Zero)
                {
                    VirtualProtect(moduleHandle, 0x1000, PAGE_EXECUTE_READ, out uint _);
                }
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        private static void PreventMemoryScanning()
        {
            try
            {
                Process currentProcess = Process.GetCurrentProcess();
                currentProcess.MaxWorkingSet = (IntPtr)((long)currentProcess.MaxWorkingSet + 0x100000);
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        private static void ObfuscateMemoryRegions()
        {
            try
            {
                Random random = new Random();
                byte[] junkData = new byte[0x1000];
                random.NextBytes(junkData);

                IntPtr address = Marshal.AllocHGlobal(0x1000);
                Marshal.Copy(junkData, 0, address, junkData.Length);
                VirtualProtect(address, 0x1000, PAGE_EXECUTE_READWRITE, out uint _);
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }

        public static void Cleanup()
        {
            try
            {
                Process currentProcess = Process.GetCurrentProcess();
                currentProcess.MaxWorkingSet = (IntPtr)((long)currentProcess.MaxWorkingSet - 0x100000);
            }
            catch
            {
                // Hata durumunda sessizce devam et
            }
        }
    }
} 