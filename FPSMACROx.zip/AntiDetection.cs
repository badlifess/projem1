using System;
using System.Diagnostics;
using System.Management;
using System.Runtime.InteropServices;
using System.Security.Principal;

namespace FPSMACROx
{
    public class AntiDetection
    {
        #region P/Invoke Declarations
        [DllImport("kernel32.dll")]
        private static extern IntPtr OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);

        [DllImport("kernel32.dll")]
        private static extern bool CloseHandle(IntPtr hObject);

        [DllImport("ntdll.dll")]
        private static extern int NtSetInformationProcess(IntPtr processHandle, int processInformationClass, 
            ref int processInformation, int processInformationLength);

        [DllImport("kernel32.dll")]
        private static extern bool VirtualProtect(IntPtr lpAddress, uint dwSize, uint flNewProtect, out uint lpflOldProtect);

        [DllImport("kernel32.dll")]
        private static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        private static extern IntPtr GetCommandLine();
        #endregion

        private static readonly object _lock = new object();
        private static bool _isInitialized;

        public static void Initialize()
        {
            if (_isInitialized) return;

            lock (_lock)
            {
                if (_isInitialized) return;

                try
                {
                    // Anti-Cheat koruması
                    HideFromAntiCheat();

                    // Debugger koruması
                    PreventDebugging();

                    // Sanal makine koruması
                    if (IsRunningInVM())
                    {
                        Environment.Exit(0);
                    }

                    // İşlem gizleme
                    HideProcess();

                    // Bellek koruması
                    ProtectMemory();

                    // İşlem adı değiştirme
                    ChangeProcessName();

                    _isInitialized = true;
                }
                catch (Exception ex)
                {
                    // Hata durumunda sessizce devam et
                }
            }
        }

        private static void HideFromAntiCheat()
        {
            try
            {
                // Anti-cheat işlemlerini tespit et ve engelle
                var processes = Process.GetProcesses();
                foreach (var process in processes)
                {
                    string processName = process.ProcessName.ToLower();
                    if (processName.Contains("battleeye") || 
                        processName.Contains("easyanticheat") || 
                        processName.Contains("punkbuster"))
                    {
                        // Anti-cheat işlemini engelle
                        process.Kill();
                    }
                }
            }
            catch { }
        }

        private static void PreventDebugging()
        {
            try
            {
                if (Debugger.IsAttached || IsDebuggerPresent())
                {
                    Environment.Exit(0);
                }
            }
            catch { }
        }

        private static bool IsRunningInVM()
        {
            try
            {
                using (var searcher = new ManagementObjectSearcher("Select * from Win32_ComputerSystem"))
                {
                    using (var items = searcher.Get())
                    {
                        foreach (var item in items)
                        {
                            string manufacturer = item["Manufacturer"].ToString().ToLower();
                            if ((manufacturer == "microsoft corporation" && 
                                item["Model"].ToString().ToUpperInvariant().Contains("VIRTUAL")) ||
                                manufacturer.Contains("vmware") ||
                                item["Model"].ToString() == "VirtualBox")
                            {
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        private static void HideProcess()
        {
            try
            {
                Process currentProcess = Process.GetCurrentProcess();
                IntPtr handle = OpenProcess(0x1F0FFF, false, currentProcess.Id);
                
                int isHidden = 1;
                NtSetInformationProcess(handle, 0x1D, ref isHidden, sizeof(int));
                
                CloseHandle(handle);
            }
            catch { }
        }

        private static void ProtectMemory()
        {
            try
            {
                IntPtr baseAddress = AppDomain.CurrentDomain.BaseAddress;
                uint oldProtect;
                VirtualProtect(baseAddress, 0x1000, 0x40, out oldProtect);
            }
            catch { }
        }

        private static void ChangeProcessName()
        {
            try
            {
                // İşlem adını değiştir
                Process currentProcess = Process.GetCurrentProcess();
                // İşlem adı değiştirme işlemleri...
            }
            catch { }
        }

        [DllImport("kernel32.dll")]
        private static extern bool IsDebuggerPresent();
    }
} 