﻿using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Telegram.Bot;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;

namespace FPSMACROx
{
    /// <summary>
    /// Handles Telegram bot operations, including receiving updates and managing bot lifecycle.
    /// </summary>
    public class TelegramBotHandler
    {
        private readonly TelegramBotClient _botClient;
        private readonly CancellationTokenSource _cts;

        /// <summary>
        /// Initializes a new instance of the <see cref="TelegramBotHandler"/> class.
        /// </summary>
        /// <param name="botToken">The token for the Telegram bot.</param>
        public TelegramBotHandler(string botToken)
        {
            if (string.IsNullOrWhiteSpace(botToken))
            {
                throw new ArgumentException("Bot token cannot be null or whitespace.", nameof(botToken));
            }

            _botClient = new TelegramBotClient(botToken);
            _cts = new CancellationTokenSource();
        }

        /// <summary>
        /// Starts the Telegram bot and begins listening for updates.
        /// </summary>
        public void Start()
        {
            Console.WriteLine("Starting Telegram bot...");

            var receiverOptions = new ReceiverOptions
            {
                AllowedUpdates = Array.Empty<UpdateType>() // Allow all update types
            };

            _botClient.StartReceiving(
                HandleUpdateAsync,
                HandleErrorAsync,
                receiverOptions,
                _cts.Token
            );

            Console.WriteLine("Telegram bot started.");
        }

        /// <summary>
        /// Stops the Telegram bot and cancels all operations.
        /// </summary>
        public void Stop()
        {
            Console.WriteLine("Stopping Telegram bot...");
            _cts.Cancel();
            Console.WriteLine("Telegram bot stopped.");
        }

        /// <summary>
        /// Asynchronously handles incoming updates from Telegram.
        /// </summary>
        /// <param name="botClient">The bot client instance.</param>
        /// <param name="update">The update received from Telegram.</param>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        private async Task HandleUpdateAsync(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
        {
            try
            {
                if (update.Type == UpdateType.Message && update.Message?.Text != null)
                {
                    Console.WriteLine($"Received a message from {update.Message.Chat.Id}: {update.Message.Text}");

                    // Example: Echo the received message
                    await botClient.SendTextMessageAsync(
                        chatId: update.Message.Chat.Id,
                        text: $"You said: {update.Message.Text}",
                        cancellationToken: cancellationToken
                    );
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error handling update: {ex.Message}");
            }
        }

        /// <summary>
        /// Handles errors that occur during bot operations.
        /// </summary>
        /// <param name="botClient">The bot client instance.</param>
        /// <param name="exception">The exception that occurred.</param>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        private Task HandleErrorAsync(ITelegramBotClient botClient, Exception exception, CancellationToken cancellationToken)
        {
            Console.WriteLine($"Telegram bot error: {exception.Message}");
            return Task.CompletedTask;
        }
    }
}