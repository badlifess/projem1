﻿namespace FPSMACROx
{
	// Token: 0x02000042 RID: 66
	public partial class Form1 : global::System.Windows.Forms.Form
	{
	}
}
