﻿using System;
using System.Runtime.InteropServices;
using System.Text;

/// <summary>
/// A utility class for reading and writing to INI files.
/// </summary>
public class INIKaydet
{
    private readonly string _dosyaYolu;

    /// <summary>
    /// Initializes a new instance of the <see cref="INIKaydet"/> class.
    /// </summary>
    /// <param name="dosyaYolu">The path to the INI file.</param>
    public INIKaydet(string dosyaYolu)
    {
        _dosyaYolu = dosyaYolu ?? throw new ArgumentNullException(nameof(dosyaYolu));
    }

    /// <summary>
    /// Writes a value to the INI file.
    /// </summary>
    /// <param name="bolum">The section in the INI file.</param>
    /// <param name="ayarAdi">The key name.</param>
    /// <param name="deger">The value to write.</param>
    /// <returns>Returns 0 if the operation fails, otherwise a nonzero value.</returns>
    public long Yaz(string bolum, string ayarAdi, string deger)
    {
        if (string.IsNullOrEmpty(bolum)) throw new ArgumentNullException(nameof(bolum));
        if (string.IsNullOrEmpty(ayarAdi)) throw new ArgumentNullException(nameof(ayarAdi));

        return WritePrivateProfileString(bolum, ayarAdi, deger, _dosyaYolu);
    }

    /// <summary>
    /// Reads a value from the INI file.
    /// </summary>
    /// <param name="bolum">The section in the INI file.</param>
    /// <param name="ayarAdi">The key name.</param>
    /// <returns>The value read from the INI file, or an empty string if the key does not exist.</returns>
    public string Oku(string bolum, string ayarAdi)
    {
        if (string.IsNullOrEmpty(bolum)) throw new ArgumentNullException(nameof(bolum));
        if (string.IsNullOrEmpty(ayarAdi)) throw new ArgumentNullException(nameof(ayarAdi));

        var retVal = new StringBuilder(1024);
        GetPrivateProfileString(bolum, ayarAdi, string.Empty, retVal, retVal.Capacity, _dosyaYolu);
        return retVal.ToString();
    }

    [DllImport("kernel32", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

    [DllImport("kernel32", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);
}