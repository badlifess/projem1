﻿using System;
using System.Runtime.InteropServices;

namespace AntiCrack_DotNet
{
	// Token: 0x02000085 RID: 133
	internal sealed class Structs
	{
		// Token: 0x06000B3A RID: 2874
		public extern Structs();

		// Token: 0x02000086 RID: 134
		public struct CONTEXT
		{
			// Token: 0x040003FB RID: 1019
			public uint P1Home;

			// Token: 0x040003FC RID: 1020
			public uint P2Home;

			// Token: 0x040003FD RID: 1021
			public uint P3Home;

			// Token: 0x040003FE RID: 1022
			public uint P4Home;

			// Token: 0x040003FF RID: 1023
			public uint P5Home;

			// Token: 0x04000400 RID: 1024
			public uint P6Home;

			// Token: 0x04000401 RID: 1025
			public long ContextFlags;

			// Token: 0x04000402 RID: 1026
			public uint Dr0;

			// Token: 0x04000403 RID: 1027
			public uint Dr1;

			// Token: 0x04000404 RID: 1028
			public uint Dr2;

			// Token: 0x04000405 RID: 1029
			public uint Dr3;

			// Token: 0x04000406 RID: 1030
			public uint Dr4;

			// Token: 0x04000407 RID: 1031
			public uint Dr5;

			// Token: 0x04000408 RID: 1032
			public uint Dr6;

			// Token: 0x04000409 RID: 1033
			public uint Dr7;
		}

		// Token: 0x02000087 RID: 135
		public struct PROCESS_MITIGATION_BINARY_SIGNATURE_POLICY
		{
			// Token: 0x0400040A RID: 1034
			public uint MicrosoftSignedOnly;
		}

		// Token: 0x02000088 RID: 136
		[StructLayout(LayoutKind.Explicit)]
		public struct SYSTEM_CODEINTEGRITY_INFORMATION
		{
			// Token: 0x0400040B RID: 1035
			[FieldOffset(0)]
			public ulong Length;

			// Token: 0x0400040C RID: 1036
			[FieldOffset(4)]
			public uint CodeIntegrityOptions;
		}

		// Token: 0x02000089 RID: 137
		public struct PROCESS_BASIC_INFORMATION
		{
			// Token: 0x0400040D RID: 1037
			internal IntPtr Reserved1;

			// Token: 0x0400040E RID: 1038
			internal IntPtr PebBaseAddress;

			// Token: 0x0400040F RID: 1039
			internal IntPtr Reserved2_0;

			// Token: 0x04000410 RID: 1040
			internal IntPtr Reserved2_1;

			// Token: 0x04000411 RID: 1041
			internal IntPtr UniqueProcessId;

			// Token: 0x04000412 RID: 1042
			internal IntPtr InheritedFromUniqueProcessId;
		}

		// Token: 0x0200008A RID: 138
		public struct SYSTEM_KERNEL_DEBUGGER_INFORMATION
		{
			// Token: 0x04000413 RID: 1043
			[MarshalAs(UnmanagedType.U1)]
			public bool KernelDebuggerEnabled;

			// Token: 0x04000414 RID: 1044
			[MarshalAs(UnmanagedType.U1)]
			public bool KernelDebuggerNotPresent;
		}

		// Token: 0x0200008B RID: 139
		public struct UNICODE_STRING
		{
			// Token: 0x04000415 RID: 1045
			public ushort Length;

			// Token: 0x04000416 RID: 1046
			public ushort MaximumLength;

			// Token: 0x04000417 RID: 1047
			public IntPtr Buffer;
		}

		// Token: 0x0200008C RID: 140
		public struct ANSI_STRING
		{
			// Token: 0x04000418 RID: 1048
			public short Length;

			// Token: 0x04000419 RID: 1049
			public short MaximumLength;

			// Token: 0x0400041A RID: 1050
			public string Buffer;
		}

		// Token: 0x0200008D RID: 141
		public struct SYSTEM_SECUREBOOT_INFORMATION
		{
			// Token: 0x0400041B RID: 1051
			public bool SecureBootEnabled;

			// Token: 0x0400041C RID: 1052
			public bool SecureBootCapable;
		}

		// Token: 0x0200008E RID: 142
		public struct SYSTEM_INFO
		{
			// Token: 0x0400041D RID: 1053
			public ushort ProcessorArchitecture;

			// Token: 0x0400041E RID: 1054
			private ushort Reserved;

			// Token: 0x0400041F RID: 1055
			public uint PageSize;

			// Token: 0x04000420 RID: 1056
			public IntPtr MinimumApplicationAddress;

			// Token: 0x04000421 RID: 1057
			public IntPtr MaximumApplicationAddress;

			// Token: 0x04000422 RID: 1058
			public IntPtr ActiveProcessorMask;

			// Token: 0x04000423 RID: 1059
			public uint NumberOfProcessors;

			// Token: 0x04000424 RID: 1060
			public uint ProcessorType;

			// Token: 0x04000425 RID: 1061
			public uint AllocationGranularity;

			// Token: 0x04000426 RID: 1062
			public ushort ProcessorLevel;

			// Token: 0x04000427 RID: 1063
			public ushort ProcessorRevision;
		}
	}
}
