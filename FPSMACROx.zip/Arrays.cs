﻿using System;

namespace Cryptographic
{
    /// <summary>
    /// Provides utility methods for array operations.
    /// </summary>
    internal static class ArrayUtilities
    {
        /// <summary>
        /// Copies a range of elements from the original array into a new array.
        /// </summary>
        /// <param name="original">The original byte array.</param>
        /// <param name="from">The starting index of the range to copy (inclusive).</param>
        /// <param name="to">The ending index of the range to copy (exclusive).</param>
        /// <returns>A new byte array containing the specified range of elements.</returns>
        public static byte[] CopyOfRange(byte[] original, int from, int to)
        {
            if (original == null)
            {
                throw new ArgumentNullException(nameof(original), "The original array cannot be null.");
            }

            if (from < 0 || to > original.Length || from > to)
            {
                throw new ArgumentOutOfRangeException("Invalid range specified for array copy.");
            }

            byte[] result = new byte[to - from];
            Array.Copy(original, from, result, 0, to - from);
            return result;
        }

        /// <summary>
        /// Copies a range of elements from one array to another.
        /// </summary>
        /// <param name="sourceArray">The source array.</param>
        /// <param name="sourceIndex">The starting index in the source array.</param>
        /// <param name="destinationArray">The destination array.</param>
        /// <param name="destinationIndex">The starting index in the destination array.</param>
        /// <param name="length">The number of elements to copy.</param>
        public static void CopyRange(Array sourceArray, int sourceIndex, Array destinationArray, int destinationIndex, int length)
        {
            if (sourceArray == null)
            {
                throw new ArgumentNullException(nameof(sourceArray), "The source array cannot be null.");
            }

            if (destinationArray == null)
            {
                throw new ArgumentNullException(nameof(destinationArray), "The destination array cannot be null.");
            }

            if (sourceIndex < 0 || destinationIndex < 0 || length < 0)
            {
                throw new ArgumentOutOfRangeException("Indices and length must be non-negative.");
            }

            Array.Copy(sourceArray, sourceIndex, destinationArray, destinationIndex, length);
        }
    }
}