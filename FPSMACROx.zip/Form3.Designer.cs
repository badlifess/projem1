﻿namespace FPSMACROx
{
	// Token: 0x02000041 RID: 65
	public partial class Form3 : global::System.Windows.Forms.Form
	{
	}
}
