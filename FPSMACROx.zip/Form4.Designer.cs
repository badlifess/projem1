﻿namespace FPSMACROx
{
	// Token: 0x0200003F RID: 63
	public partial class Form4 : global::System.Windows.Forms.Form
	{
	}
}
