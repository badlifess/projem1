﻿using System;

namespace CanetisRadar
{
    /// <summary>
    /// Manages and stores various log messages for the application.
    /// </summary>
    internal class LogManager
    {
        // User-related logs
        public static string UserLog1;
        public static string UserLog2;
        public static string UserLog3;
        public static string UserLog4;
        public static string UserLog5;
        public static string UserLog6;

        // Test-related logs
        public static string TestLog1;
        public static string TestLog2;
        public static string TestLog3;

        // System-related logs
        public static string SystemDate;
        public static string NetworkIP;
    }
}