﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;

namespace KeyAuth
{
    /// <summary>
    /// A utility class for JSON serialization and deserialization.
    /// </summary>
    public class JsonWrapper
    {
        private readonly DataContractJsonSerializer _serializer;
        private readonly object _currentObject;

        /// <summary>
        /// Initializes a new instance of the <see cref="JsonWrapper"/> class.
        /// </summary>
        /// <param name="objectToWorkWith">The object to serialize or deserialize.</param>
        public JsonWrapper(object objectToWorkWith)
        {
            if (objectToWorkWith == null)
            {
                throw new ArgumentNullException(nameof(objectToWorkWith));
            }

            _currentObject = objectToWorkWith;
            _serializer = new DataContractJsonSerializer(objectToWorkWith.GetType());
        }

        /// <summary>
        /// Checks if a type is serializable.
        /// </summary>
        /// <param name="typeToCheck">The type to check.</param>
        /// <returns>True if the type is serializable; otherwise, false.</returns>
        public static bool IsSerializable(Type typeToCheck)
        {
            return typeToCheck.IsSerializable || typeToCheck.IsDefined(typeof(DataContractAttribute), true);
        }

        /// <summary>
        /// Deserializes a JSON string into an object.
        /// </summary>
        /// <param name="json">The JSON string.</param>
        /// <returns>The deserialized object.</returns>
        public object StringToObject(string json)
        {
            using (var memoryStream = new MemoryStream(Encoding.UTF8.GetBytes(json)))
            {
                return _serializer.ReadObject(memoryStream);
            }
        }

        /// <summary>
        /// Deserializes a JSON string into a generic type.
        /// </summary>
        /// <typeparam name="T">The type to deserialize into.</typeparam>
        /// <param name="json">The JSON string.</param>
        /// <returns>The deserialized object of type T.</returns>
        public T StringToGeneric<T>(string json)
        {
            var serializer = new DataContractJsonSerializer(typeof(T));
            using (var memoryStream = new MemoryStream(Encoding.UTF8.GetBytes(json)))
            {
                return (T)serializer.ReadObject(memoryStream);
            }
        }

        /// <summary>
        /// Serializes the current object to a JSON string.
        /// </summary>
        /// <returns>The JSON string representation of the current object.</returns>
        public string ObjectToString()
        {
            using (var memoryStream = new MemoryStream())
            {
                _serializer.WriteObject(memoryStream, _currentObject);
                return Encoding.UTF8.GetString(memoryStream.ToArray());
            }
        }

        /// <summary>
        /// Helper method to convert a byte array to a string.
        /// </summary>
        /// <param name="bytes">The byte array.</param>
        /// <returns>The string representation of the byte array.</returns>
        public static string ByteArrayToString(byte[] bytes)
        {
            return Encoding.UTF8.GetString(bytes);
        }

        /// <summary>
        /// Helper method to convert a string to a byte array.
        /// </summary>
        /// <param name="str">The string to convert.</param>
        /// <returns>The byte array representation of the string.</returns>
        public static byte[] StringToByteArray(string str)
        {
            return Encoding.UTF8.GetBytes(str);
        }
    }
}