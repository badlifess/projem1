using System;
using System.Drawing;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;

namespace FPSMACROx
{
    public class X7K9P2M4
    {
        private readonly E5F7G9H2 X7K9P2M4;
        private readonly E2F4G6H8 Y3R8N1L5;
        private readonly E8F1G3H5 I7J9K2L4;
        private volatile bool isRunning;
        private CancellationTokenSource cancellationTokenSource;
        private readonly object lockObject = new object();
        private Color targetColor = Color.Purple;
        private int colorTolerance = 10;
        private int scanRadius = 100;
        private float smoothnessFactor = 0.5f;
        private float predictionFactor = 0.3f;
        private readonly List<Point> targetHistory = new List<Point>();
        private const int MAX_HISTORY = 10;

        public X7K9P2M4()
        {
            X7K9P2M4 = new E5F7G9H2();
            Y3R8N1L5 = new E2F4G6H8();
            I7J9K2L4 = E8F1G3H5.Instance;
        }

        public void Start()
        {
            if (!isRunning)
            {
                lock (lockObject)
                {
                    if (!isRunning)
                    {
                        isRunning = true;
                        cancellationTokenSource = new CancellationTokenSource();
                        Task.Run(() => ProcessLoop(cancellationTokenSource.Token));
                    }
                }
            }
        }

        public void Stop()
        {
            if (isRunning)
            {
                lock (lockObject)
                {
                    if (isRunning)
                    {
                        isRunning = false;
                        cancellationTokenSource?.Cancel();
                        cancellationTokenSource?.Dispose();
                        cancellationTokenSource = null;
                    }
                }
            }
        }

        private async Task ProcessLoop(CancellationToken cancellationToken)
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                try
                {
                    await ProcessFrame();
                    await Task.Delay(1, cancellationToken);
                }
                catch (OperationCanceledException)
                {
                    break;
                }
                catch (Exception)
                {
                    // Log error silently
                }
            }
        }

        private async Task ProcessFrame()
        {
            var screen = await X7K9P2M4.CaptureScreenAsync();
            var target = await FindTargetAsync(screen);
            
            if (target.HasValue)
            {
                await MoveToTargetAsync(target.Value);
            }
        }

        private async Task<Point?> FindTargetAsync(Bitmap screen)
        {
            return await Task.Run(() =>
            {
                try
                {
                    for (int x = 0; x < screen.Width; x++)
                    {
                        for (int y = 0; y < screen.Height; y++)
                        {
                            var pixel = screen.GetPixel(x, y);
                            if (IsColorMatch(pixel, targetColor))
                            {
                                return new Point(x, y);
                            }
                        }
                    }
                    return null;
                }
                catch
                {
                    return null;
                }
            });
        }

        private bool IsColorMatch(Color pixel, Color target)
        {
            return Math.Abs(pixel.R - target.R) <= colorTolerance &&
                   Math.Abs(pixel.G - target.G) <= colorTolerance &&
                   Math.Abs(pixel.B - target.B) <= colorTolerance;
        }

        private async Task MoveToTargetAsync(Point target)
        {
            var currentPos = Y3R8N1L5.GetCurrentPosition();
            var moveVector = CalculateMoveVector(currentPos, target);
            await Y3R8N1L5.MoveMouseAsync(moveVector);
        }

        private Point CalculateMoveVector(Point current, Point target)
        {
            var dx = target.X - current.X;
            var dy = target.Y - current.Y;
            
            // Apply smoothing
            dx = (int)(dx * smoothnessFactor);
            dy = (int)(dy * smoothnessFactor);
            
            // Apply prediction
            if (targetHistory.Count > 0)
            {
                var lastTarget = targetHistory.Last();
                var predictedDx = target.X - lastTarget.X;
                var predictedDy = target.Y - lastTarget.Y;
                
                dx += (int)(predictedDx * predictionFactor);
                dy += (int)(predictedDy * predictionFactor);
            }
            
            // Update history
            targetHistory.Add(target);
            if (targetHistory.Count > MAX_HISTORY)
            {
                targetHistory.RemoveAt(0);
            }
            
            return new Point(dx, dy);
        }

        public void SetTargetColor(Color color)
        {
            targetColor = color;
        }

        public void SetColorTolerance(int tolerance)
        {
            colorTolerance = tolerance;
        }

        public void SetScanRadius(int radius)
        {
            scanRadius = radius;
        }

        public void SetSmoothnessFactor(float factor)
        {
            smoothnessFactor = factor;
        }

        public void SetPredictionFactor(float factor)
        {
            predictionFactor = factor;
        }
    }
} 