﻿using System;
using System.Runtime.InteropServices;

namespace FPSMACROx
{
    /// <summary>
    /// Provides a managed wrapper for User32 and Kernel32 WinAPI functions related to mouse hooks and window management.
    /// </summary>
    public static class User32
    {
        // Constants for hook types and mouse events
        public const int WH_MOUSE_LL = 14; // Low-level mouse hook ID
        public const int WM_RBUTTONDOWN = 0x0204; // Right mouse button down
        public const int WM_RBUTTONUP = 0x0205; // Right mouse button up

        /// <summary>
        /// Sets a Windows hook procedure.
        /// </summary>
        /// <param name="idHook">The type of hook to install.</param>
        /// <param name="lpfn">A pointer to the hook procedure.</param>
        /// <param name="hMod">A handle to the DLL containing the hook procedure.</param>
        /// <param name="dwThreadId">The thread ID to associate with the hook.</param>
        /// <returns>A handle to the installed hook procedure.</returns>
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern IntPtr SetWindowsHookEx(int idHook, LowLevelMouseProc lpfn, IntPtr hMod, uint dwThreadId);

        /// <summary>
        /// Removes a hook procedure installed by <see cref="SetWindowsHookEx"/>.
        /// </summary>
        /// <param name="hhk">A handle to the hook to remove.</param>
        /// <returns>True if the hook was successfully removed; otherwise, false.</returns>
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool UnhookWindowsHookEx(IntPtr hhk);

        /// <summary>
        /// Passes the hook information to the next hook procedure in the chain.
        /// </summary>
        /// <param name="hhk">A handle to the current hook.</param>
        /// <param name="nCode">The hook code.</param>
        /// <param name="wParam">The message identifier.</param>
        /// <param name="lParam">A pointer to the hook-specific data.</param>
        /// <returns>A handle returned by the next hook procedure in the chain.</returns>
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

        /// <summary>
        /// Retrieves a module handle for the specified module.
        /// </summary>
        /// <param name="lpModuleName">The name of the module.</param>
        /// <returns>A handle to the specified module.</returns>
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern IntPtr GetModuleHandle(string lpModuleName);

        /// <summary>
        /// Brings the specified window to the foreground.
        /// </summary>
        /// <param name="hWnd">A handle to the window to bring to the foreground.</param>
        /// <returns>True if the operation was successful; otherwise, false.</returns>
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetForegroundWindow(IntPtr hWnd);

        /// <summary>
        /// Represents a low-level mouse hook procedure.
        /// </summary>
        /// <param name="nCode">The hook code.</param>
        /// <param name="wParam">The message identifier.</param>
        /// <param name="lParam">A pointer to the hook-specific data.</param>
        /// <returns>A handle returned by the next hook procedure in the chain.</returns>
        public delegate IntPtr LowLevelMouseProc(int nCode, IntPtr wParam, IntPtr lParam);

        /// <summary>
        /// Represents a point in 2D space.
        /// </summary>
        public struct POINT
        {
            public int x; // The X-coordinate of the point
            public int y; // The Y-coordinate of the point
        }

        /// <summary>
        /// Contains information about a low-level mouse input event.
        /// </summary>
        public struct MSLLHOOKSTRUCT
        {
            public POINT pt; // The screen coordinates of the mouse pointer
            public uint mouseData; // Additional mouse data
            public uint flags; // Event-injected flags
            public uint time; // The time stamp for the event
            public IntPtr dwExtraInfo; // Additional information associated with the event
        }
    }
}