using System;
using System.Security.Cryptography;
using System.Text;

namespace SecuritySystem.Protection
{
    public static class NetworkEncryption
    {
        private static readonly byte[] Key = Encoding.UTF8.GetBytes("YourSecretKey1234567890123456789012");
        private static readonly byte[] IV = Encoding.UTF8.GetBytes("YourIV1234567890");

        public static void Initialize()
        {
            try
            {
                Utils.Logger.Log("Ağ şifreleme başarıyla başlatıldı");
            }
            catch (Exception ex)
            {
                Utils.Logger.Log($"Ağ şifreleme hatası: {ex.Message}");
            }
        }

        public static string Encrypt(string plainText)
        {
            try
            {
                using (Aes aes = Aes.Create())
                {
                    aes.Key = Key;
                    aes.IV = IV;

                    ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                    using (MemoryStream msEncrypt = new MemoryStream())
                    {
                        using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                        {
                            using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                            {
                                swEncrypt.Write(plainText);
                            }
                        }
                        return Convert.ToBase64String(msEncrypt.ToArray());
                    }
                }
            }
            catch
            {
                return plainText;
            }
        }

        public static string Decrypt(string cipherText)
        {
            try
            {
                using (Aes aes = Aes.Create())
                {
                    aes.Key = Key;
                    aes.IV = IV;

                    ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                    using (MemoryStream msDecrypt = new MemoryStream(Convert.FromBase64String(cipherText)))
                    {
                        using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                        {
                            using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                            {
                                return srDecrypt.ReadToEnd();
                            }
                        }
                    }
                }
            }
            catch
            {
                return cipherText;
            }
        }

        public static void Cleanup()
        {
            // Temizlik işlemleri gerekirse burada yapılabilir
        }
    }
} 