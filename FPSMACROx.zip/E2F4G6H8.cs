using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace FPSMACROx
{
    public class E2F4G6H8
    {
        [DllImport("user32.dll")]
        private static extern void mouse_event(int dwFlags, int dx, int dy, int dwData, int dwExtraInfo);

        [DllImport("user32.dll")]
        private static extern bool GetCursorPos(out Point lpPoint);

        private const int MOUSEEVENTF_MOVE = 0x0001;
        private const int MOUSEEVENTF_LEFTDOWN = 0x0002;
        private const int MOUSEEVENTF_LEFTUP = 0x0004;
        private const int MOUSEEVENTF_RIGHTDOWN = 0x0008;
        private const int MOUSEEVENTF_RIGHTUP = 0x0010;
        private const int MOUSEEVENTF_MIDDLEDOWN = 0x0020;
        private const int MOUSEEVENTF_MIDDLEUP = 0x0040;
        private const int MOUSEEVENTF_ABSOLUTE = 0x8000;

        public Point GetCurrentPosition()
        {
            GetCursorPos(out Point point);
            return point;
        }

        public async Task MoveMouseAsync(Point moveVector)
        {
            await Task.Run(() =>
            {
                try
                {
                    mouse_event(MOUSEEVENTF_MOVE, moveVector.X, moveVector.Y, 0, 0);
                }
                catch
                {
                    // Log error silently
                }
            });
        }

        public async Task ClickAsync()
        {
            await Task.Run(() =>
            {
                try
                {
                    mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
                    mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
                }
                catch
                {
                    // Log error silently
                }
            });
        }

        public async Task RightClickAsync()
        {
            await Task.Run(() =>
            {
                try
                {
                    mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0);
                    mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0);
                }
                catch
                {
                    // Log error silently
                }
            });
        }
    }
} 