﻿using System;

/// <summary>
/// This class is generated and processed by Fody.
/// It contains metadata about the Fody and Costura versions used.
/// </summary>
internal class DijitalCyrpto_ProcessedByFody
{
    /// <summary>
    /// The version of Fody used to process this assembly.
    /// </summary>
    internal const string FodyVersion = "6.5.5.0";

    /// <summary>
    /// The version of the Costura package used for embedding dependencies.
    /// </summary>
    internal const string Costura = "5.7.0";
}